<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 #------------------------------------    
    # Author: Bdtask Ltd
    # Author link: https://www.bdtask.com/
    # Dynamic style php file
    # Developed by :Isahaq
    #------------------------------------    

class Sampling extends MX_Controller {

    public function __construct()
    {
        parent::__construct();
  //error_reporting(E_ALL);
//ini_set('display_errors', '1');
        $this->load->model(array(
            'Sampling_model')); 
        if (! $this->session->userdata('isLogIn'))
            redirect('login');
          
    }
    
    function index() {
        
		
		
		
		$data['title']             = display('sample_list');
        $data['module']            = "sampling";
        $data['page']              = "sample_list"; 
        //echo "===============";
		///$data["customer_dropdown"] = $this->Sampling_model->customer_dropdown();
        
		
		
	   $data['all_samples']      = $this->Sampling_model->allsamples(); 
      
	   
		echo modules::run('template/layout', $data);
    }

    public function sample_list() 
    {
    $data['title']             = display('sample_list'); 
    $config["base_url"]        = base_url('sample_list');
    $config["total_rows"]      = $this->Sampling_model->count_sample();
	$config["per_page"]        = 10;
    $config["uri_segment"]     = 2;
    $config["last_link"]       = "Last"; 
    $config["first_link"]      = "First"; 
    $config['next_link']       = 'Next';
    $config['prev_link']       = 'Prev';  
    $config['full_tag_open']   = "<ul class='pagination col-xs pull-right'>";
    $config['full_tag_close']  = "</ul>";
    $config['num_tag_open']    = '<li>';
    $config['num_tag_close']   = '</li>';
    $config['cur_tag_open']    = "<li class='disabled'><li class='active'><a href='#'>";
    $config['cur_tag_close']   = "<span class='sr-only'></span></a></li>";
    $config['next_tag_open']   = "<li>";
    $config['next_tag_close']  = "</li>";
    $config['prev_tag_open']   = "<li>";
    $config['prev_tagl_close'] = "</li>";
    $config['first_tag_open']  = "<li>";
    $config['first_tagl_close']= "</li>";
    $config['last_tag_open']   = "<li>";
    $config['last_tagl_close'] = "</li>";
	$this->pagination->initialize($config);
	
    $page                      = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
    $data["samples"]           = $this->Sampling_model->sample_listdata($config["per_page"], $page);
	
	$data["links"]             = $this->pagination->create_links();
    $data['samplelists']          = $this->Sampling_model->sample_order_list();
	
	$data['clients'] = $this->Sampling_model->allclients(); 			
	$data['brands'] = $this->Sampling_model->allbrands(); 
	$data['sample_po_no_id']=$this->input->post('sample_po_no_id');
	$data['clientid']=$this->input->post('client');	
	$data['brandid']=$this->input->post('brand');
	
	$data['start']=$this->input->post('from_date');
	
	$data['end']=$this->input->post('to_date');

    $data['customer_name']     = '';
    $data['customer_id']       = '';
    $data['address']           ='';
    $data['module']            = "sampling";      
    $data['page']              = "sample_list"; 
	
	
	
    echo Modules::run('template/layout', $data); 
    }





    public function bdtask_CheckCustomerList(){
        $postData = $this->input->post();
        $data     = $this->customer_model->getCustomerList($postData);
        
        echo json_encode($data);
       
    }

     public function bdtask_credit_customer() {
        $data['title']             = display('credit_customer');
        $data['module']            = "customer";
        $data['page']              = "credit_customer"; 
        $data["customer_dropdown"] = $this->customer_model->bdtask_credit_customer_dropdown();
        $data['all_customer']      = $this->customer_model->bdtask_all_credit_customer(); 
        echo modules::run('template/layout', $data);
    }

     public function bdtask_CheckCreditCustomerList(){

        $postData = $this->input->post();
        $data = $this->customer_model->getCreditCustomerList($postData);
        echo json_encode($data);
    } 

    //Paid Customer list. The customer who will pay 100%.
    public function bdtask_paid_customer() {
        $data['title']             = display('paid_customer');
        $data['module']            = "customer";
        $data['page']              = "paid_customer"; 
        $data["customer_dropdown"] = $this->customer_model->bdtask_paid_customer_dropdown();
        $data['all_customer']      = $this->customer_model->bdtask_all_paid_customer(); 
        echo modules::run('template/layout', $data);
        
    }
    
     public function bdtask_CheckPaidCustomerList(){
        // GET data
        $postData = $this->input->post();
        $data = $this->customer_model->bdtask_getPaidCustomerList($postData);
        echo json_encode($data);
    } 


  public function bdtask_form($id = null)
    {
        $data['title'] = display('add_sample');
        #-------------------------------#
       // $this->form_validation->set_rules('sample_po_no','sample P.O No','required|max_length[200]');
        $this->form_validation->set_rules('po_date', 'P.O Date') ;
		//$this->form_validation->set_rules('client','client','required|max_length[200]');
        //if(empty($id)){
        //$this->form_validation->set_rules('customer_email',display('email'),'max_length[100]|valid_email|is_unique[customer_information.customer_email]');
    //}else{
      //  $this->form_validation->set_rules('customer_email',display('email'),'max_length[100]|valid_email');
    //}
        //$this->form_validation->set_rules('contact',display('contact'),'max_length[200]');
        //$this->form_validation->set_rules('phone',display('phone'),'max_length[20]');
        //$this->form_validation->set_rules('city',display('city'),'max_length[100]'); 
        //$this->form_validation->set_rules('state',display('state'),'max_length[100]');
        //$this->form_validation->set_rules('zip',display('zip'),'max_length[30]');
        //$this->form_validation->set_rules('country',display('country'),'max_length[100]');  
        //$this->form_validation->set_rules('customer_address',display('customer_address'),'max_length[255]');
        //$this->form_validation->set_rules('address2',display('address2'),'max_length[255]'); 
        #-------------------------------#


/*
        $data['customer'] = (object)$postData = [
            'customer_id'      => $this->input->post('customer_id',true),
            'customer_name'    => $this->input->post('customer_name',true),
            'customer_mobile'  => $this->input->post('customer_mobile', true),
            'customer_email'   => $this->input->post('customer_email', true),
            'email_address'    => $this->input->post('email_address', true),
            'contact'          => $this->input->post('contact', true),
            'phone'            => $this->input->post('phone', true),
            'fax'              => $this->input->post('fax', true), 
            'city'             => $this->input->post('city', true) ,
            'state'            => $this->input->post('state', true) ,
            'zip'              => $this->input->post('zip', true) ,
            'country'          => $this->input->post('country', true) ,
            'customer_address' => $this->input->post('customer_address', true) ,
            'address2'         => $this->input->post('address2', true) ,
            'status'           => 1,
            'create_by'        => $this->session->userdata('id') ,
            
        ]; 
		
		*/
		
		
		
		
	$postData = [
            'sample_id'  => $this->input->post('sample_id',true),
			'sample_po_no'  => $this->input->post('sample_po_no',true),
			'po_date'  => $this->input->post('po_date',true),
			'client'  => $this->input->post('client',true),
			'season'  => $this->input->post('season',true),
			'receiver_contact'  => $this->input->post('receiver_contact',true),
			'receiver_emial'  => $this->input->post('receiver_emial',true),
			'create_date'=> date('Y-m-d H:i:s'),
			'brand_id'=>$this->input->post('brand',true),
			'create_by'=> $this->session->userdata('id')
            
        ]; 
		
		
		
		
        #-------------------------------#
        if ($this->form_validation->run() === true) {
            #if empty $id then insert data
            if (empty($postData['sample_id'])) {
              $tmp_sample_id=  $this->Sampling_model->create($postData);
				if ($tmp_sample_id) {
				
								
					$this -> db -> where('sample_id', $tmp_sample_id	);
					$this -> db -> delete('tov_sampling_information');

				
				$countsize = count($this->input->post('model'));
			
				for ($i=0; $i<$countsize ; $i++) 
				{
					$data['tov_sampling_information'] = (object)$postData2 = [
					'sample_id'=>$tmp_sample_id,
					
					's_no'=>$this->input->post('sno')[$i],
					'model'=>$this->input->post('model')[$i],
					'material_description'=>$this->input->post('material_description')[$i],
					'colors'=>$this->input->post('colors')[$i],
					'uom'=>$this->input->post('uom')[$i],
					'order_date'=>$this->input->post('order_date')[$i],
					'qty'=>$this->input->post('qty')[$i],
					'status'=>0,
					'sample_po_no'=>$this->input->post('sample_po_no',true),
					'create_date'=> date('Y-m-d H:i:s'),
					'create_by'=> $this->session->userdata('id')
					]; 
				
					$this->Sampling_model->create_sampling_information($postData2,$tmp_sample_id);
					
				}
				
				
            
        
					
					
					
					
					
					
                    #set success message
                       // $info['msg']    = display('save_successfully');
                        //$info['status'] = 1;
                        
                        redirect('sample_list');
                } else {
                    #set exception message
                        $info['msg']    = display('please_try_again');
                        $info['status'] = 0;
                }
            } else {
                
               
                
                
                if ($this->Sampling_model->update($postData)) {
					
									
				//$this -> db -> where('sample_id', $postData['sample_id']	);
				///$this -> db -> delete('tov_sampling_information');

					$countsize = count($this->input->post('model'));
			
			
				for ($i=0; $i<$countsize ; $i++) 
				{
					$postData2 = [
					'brand_sample_id'=>$this->input->post('brand_sample_id')[$i],
					'sample_id'=>$postData['sample_id'],
					's_no'=>$this->input->post('sno')[$i],
					'model'=>$this->input->post('model')[$i],
					'material_description'=>$this->input->post('material_description')[$i],
					'colors'=>$this->input->post('colors')[$i],
					'uom'=>$this->input->post('uom')[$i],
					'order_date'=>$this->input->post('order_date')[$i],
					'qty'=>$this->input->post('qty')[$i],
					'status'=>0,
					'sample_po_no'=>$this->input->post('sample_po_no',true),
					'create_date'=> date('Y-m-d H:i:s'),
					'create_by'=> $this->session->userdata('id')
					]; 
				
				
					
					 if (empty(trim($postData2['brand_sample_id']))) 
					 {
				        	$this->Sampling_model->create_sampling_information($postData2,$postData['sample_id']);	     
					 }
					 else
					 {
					     
					     
					     $this->Sampling_model->update_sampling_information($postData2);	  
					     
					 }
					
				}
				
					
                    #set success message
                    //$info['msg']    = display('update_successfully');
                    //$info['status'] = 1;
                    
                    redirect('sample_list');
                    
                } else {
                    #set exception message
                    $info['msg']    = display('please_try_again');
                    $info['status'] = 0;
                } 
            }
 
            echo json_encode($info);

        } else { 
            
			
			
			if(empty($this->input->post('customer_name',true))){
	
			if(!empty($id)){
            $data['title']    = display('edit_sample');
            $data['sample'] = $this->Sampling_model->singledata($id);  
            $data['sample_information'] = $this->Sampling_model->sampling_information($id); 
			
		
			$data['sample_id']=$id;
			}
			else
			{
				
			
			$data['sample_id']="";	
			}	
            $data['module']   = "sampling";  
            $data['page']     = "form";  
			$data['clients'] = $this->Sampling_model->allclients(); 			
			$data['brands'] = $this->Sampling_model->allbrands(); 			
			
			
			
            echo Modules::run('template/layout', $data); 
        }else{

          $info['msg']    = validation_errors();
          $info['status'] = 0;
           echo json_encode($info);
        }
        } 
    }
///////////////////////////////////////////////////////////

public function dispatch_form($sample_id = null)
    {
		
		
        $data['title'] = 'Add Dispatch';
        #-------------------------------#
        $this->form_validation->set_rules('purchase_order_no','Purchase Order No','required|max_length[100]');
        
		$this->form_validation->set_rules('dispatch_date', 'Dispatch Date') ;
		$this->form_validation->set_rules('shade_no','Shade No','required|max_length[50]');
		$this->form_validation->set_rules('challan_no','Challan No','required|max_length[50]');
			
        
		
		
	
		
		$postData = [
		'dispatch_id' => $this->input->post('dispatch_id',true),
		'sample_id'=> $this->input->post('sample_id',true),
		'brand_sample_id'=>$this->input->post('brand_sample_id',true),
		'sample_po_no'=> $this->input->post('sample_po_no',true),
		'shade_no'=> $this->input->post('shade_no',true),
		'challan_no'=> $this->input->post('challan_no',true),
		'dispatch_date'=> $this->input->post('dispatch_date',true),
		'purchase_order_no'=> $this->input->post('purchase_order_no',true),
		'create_by'=> date('Y-m-d H:i:s'),
		'create_date'=> $this->session->userdata('id')
		];
		
		
		
		
		//print_r($postData);
	//exit;
		//echo "=========".  strlen( trim($postData['dispatch_id']));
		//exit;
        #-------------------------------#
        if ($this->form_validation->run() === true) {
            #if empty $id then insert data
            if (empty(trim($postData['dispatch_id']))) {
              $tmp_dispatch_id=  $this->Sampling_model->create_dispatch($postData);
				if ($tmp_dispatch_id) {
				
					
				
				
            
        
					
					
					
					
					
					
                    #set success message
                        //$info['msg']    = display('save_successfully');
                        //$info['status'] = 1;
                        
                        redirect('sampling_list');
                        
                } else {
                    #set exception message
                        $info['msg']    = display('please_try_again');
                        $info['status'] = 0;
                }
            } else {
                if ($this->Sampling_model->update_dispatch($postData)) {
					//print_r($postData);
                    #set success message
                    //$info['msg']    = display('update_successfully');
                    
                    //$info['status'] = 1;
                    
                    redirect('sampling_list');
                    
                } else {
                    #set exception message
                    $info['msg']    = display('please_try_again');
                    $info['status'] = 0;
                } 
            }
 
            echo json_encode($info);

        } else { 
            
			
			
		
	
			
            //$data['title']    = display('edit_sample');
            //$data['sample_informations'] = $this->Sampling_model->sampling_information($sample_id);
			$data['sample'] = $this->Sampling_model->singledata($sample_id);  
			
			//$data['singledispatch'] = $this->Sampling_model->singledispatch($sample_id); 
			
			$data['material_descriptions'] = $this->Sampling_model->samplingInformation_materialDescription($sample_id);
			
			
			$data['sample_id']=$sample_id;	
			$data['dispatch_id']=$dispatch_id;	
			
            $data['module']   = "sampling";  
            $data['page']     = "add_dispatch";  
			
			//print_r($data);
			//exit;
			
            echo Modules::run('template/layout', $data); 
        
        } 
    }







public function dispatch_approval_form($dispatch_id = null,$reditect_action=0)
    {

        $data['title'] = 'Add Approval';
        #-------------------------------#
        $this->form_validation->set_rules('approved_status','Approved status','required|max_length[100]');
        
		//$this->form_validation->set_rules('dispatch_date', 'Dispatch Date') ;
		//$this->form_validation->set_rules('shade_no','Shade No','required|max_length[50]');
		//$this->form_validation->set_rules('challan_no','Challan No','required|max_length[50]');
			
        
		
		
	$postData = [
		'dispatch_id' => $this->input->post('dispatch_id',true),
		'status'=> $this->input->post('approved_status',true),
		'description'=>$this->input->post('description',true)
		];
	
		
		
		
	
		//echo "=========".  strlen( trim($postData['dispatch_id']));
		//exit;
        #-------------------------------#
        if ($this->form_validation->run() === true) {
            #if empty $id then insert data
            if (!empty(trim($postData['dispatch_id']))) {
				
				
				
				//print_r($postData);
	//exit;
             
               // if ($this->Sampling_model->update_dispatch($postData)) {
				
				 if ($this->Sampling_model->update_approvel_dispatch($postData)) {
				
				
					
					#set success message
                    //$info['msg']    = display('update_successfully');
                    //$info['status'] = 1;
					 echo "<script>alert('Your Status has been Updated  successfully');</script>"; 
					 
					 
					///if($reditect_action==0) 
					///{ 
					 
					 
					 
					 
					     redirect('http://'.$this->session->userdata('pendancy_report_geturl'));     
					 
					 
					
					 
					 //redirect('dispatch_approval_form/'.$postData['dispatch_id'], 'refresh');
					///}
					//elseif($reditect_action==1)
					///{
					    
					    
					//}
					 
                } else {
                    #set exception message
                    $info['msg']    = display('please_try_again');
                    $info['status'] = 0;
                } 
            }
 
            echo json_encode($info);

        } else { 
            
			
			
		
	
			
            //$data['title']    = display('edit_sample');
            //$data['sample_informations'] = $this->Sampling_model->sampling_information($sample_id);
			//$data['sample'] = $this->Sampling_model->singledata($sample_id);  
			
			//$data['singledispatch'] = $this->Sampling_model->singledispatch($sample_id); 
			
			//$data['material_descriptions'] = $this->Sampling_model->samplingInformation_materialDescription($sample_id);
			
			 $data['dispatch_details']          = $this->Sampling_model->dispatch_details($dispatch_id);
			
			$data['dispatch_id']=$dispatch_id;	
			
            $data['module']   = "sampling";  
            $data['page']     = "add_dispatch_approval.php";  
			
			//print_r($data);
			//exit;
			
            echo Modules::run('template/layout', $data); 
        
        } 
    }




	function ajaxget_material_description_color()
	{
		
		$material_description=$this->input->post('material_description');
		$sampleid=$this->input->post('sampleid');
		
		
		$color_data= $this->db->select('*')
			->from('tov_sampling_information')
			->where('material_description', $material_description)
			->where('sample_id', $sampleid)
			
			->get()
			->result();
			
			
			$string_list='';
			foreach($color_data as $row  )
			{
		
			$string_list.='<option value="'.$row->brand_sample_id.'">'.$row->colors.'</option>';
		
			}	
			
			echo $string_list;
			
		
		
		
	}



	function ajaxget_dispatch($brand_sample_id="") 
	{
		
		$dispatch=$this->Sampling_model->dispatch_detailswithpurchase_order($brand_sample_id);
		echo $dispatch->dispatch_id.'||'.$dispatch->shade_no.'||'.$dispatch->dispatch_date.'||'.$dispatch->challan_no;
	}



		function randomToken($length = 4, $result='') 
		{

			for($i = 0; $i < $length; $i++) {

				$case = mt_rand(0, 1);
				switch($case){

					case 0:
						$data = mt_rand(0, 9);
						break;
					case 1:
						$alpha = range('a','z');
						$item = mt_rand(0, 25);

						$data = strtoupper($alpha[$item]);
						break;
				}

				$result .= $data;
			}

			return $result;
	}

    public function bdtask_delete($id) {
        if ($this->customer_model->delete($id)) {
            echo display('delete_successfully');
        } else {
            display('please_try_again');
        }
    }

    public function customer_search($id){
       $data["customers"] = $this->customer_model->individual_info($id);
        $this->load->view('customer_search', $data);
    }
	
	
	public function dispatch_approvel_data() {
    $data['title']             = 'Dispatch List'; 
    $config["base_url"]        = base_url('dispatch_list');
    $config["total_rows"]      = $this->Sampling_model->count_dispatch();
    
	$config["per_page"]        = 10;
    $config["uri_segment"]     = 2;
    $config["last_link"]       = "Last"; 
    $config["first_link"]      = "First"; 
    $config['next_link']       = 'Next';
    $config['prev_link']       = 'Prev';  
    $config['full_tag_open']   = "<ul class='pagination col-xs pull-right'>";
    $config['full_tag_close']  = "</ul>";
    $config['num_tag_open']    = '<li>';
    $config['num_tag_close']   = '</li>';
    $config['cur_tag_open']    = "<li class='disabled'><li class='active'><a href='#'>";
    $config['cur_tag_close']   = "<span class='sr-only'></span></a></li>";
    $config['next_tag_open']   = "<li>";
    $config['next_tag_close']  = "</li>";
    $config['prev_tag_open']   = "<li>";
    $config['prev_tagl_close'] = "</li>";
    $config['first_tag_open']  = "<li>";
    $config['first_tagl_close']= "</li>";
    $config['last_tag_open']   = "<li>";
    $config['last_tagl_close'] = "</li>";
	$this->pagination->initialize($config);
    $page                      = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
    $data["dispatchs"]           = $this->Sampling_model->dispatch_listdata($config["per_page"], $page);
	$data["links"]             = $this->pagination->create_links();
    //$data['sampling_information']          = $this->Sampling_model->sampling_information_list();
	
	
	
    $data['customer_name']     = '';
    $data['customer_id']       = '';
    $data['address']           ='';
    $data['module']            = "sampling";      
    $data['page']              = "dispatch_approval_data_list"; 
	
    echo Modules::run('template/layout', $data); 
    }

	
	
	
	
	
public function dispatch_approvel_list() {
    $data['title']             = 'Dispatch List'; 
    $config["base_url"]        = base_url('dispatch_list');
    $config["total_rows"]      = $this->Sampling_model->count_dispatch();
	$config["per_page"]        = 20;
    $config["uri_segment"]     = 2;
    $config["last_link"]       = "Last"; 
    $config["first_link"]      = "First"; 
    $config['next_link']       = 'Next';
    $config['prev_link']       = 'Prev';  
    $config['full_tag_open']   = "<ul class='pagination col-xs pull-right'>";
    $config['full_tag_close']  = "</ul>";
    $config['num_tag_open']    = '<li>';
    $config['num_tag_close']   = '</li>';
    $config['cur_tag_open']    = "<li class='disabled'><li class='active'><a href='#'>";
    $config['cur_tag_close']   = "<span class='sr-only'></span></a></li>";
    $config['next_tag_open']   = "<li>";
    $config['next_tag_close']  = "</li>";
    $config['prev_tag_open']   = "<li>";
    $config['prev_tagl_close'] = "</li>";
    $config['first_tag_open']  = "<li>";
    $config['first_tagl_close']= "</li>";
    $config['last_tag_open']   = "<li>";
    $config['last_tagl_close'] = "</li>";
	$this->pagination->initialize($config);
    $page                      = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
    $data["dispatchs"]           = $this->Sampling_model->dispatch_listdata($config["per_page"], $page);
	$data["links"]             = $this->pagination->create_links();
    $data['sampling_information']          = $this->Sampling_model->sampling_information_list();
	
	
	
    $data['customer_name']     = '';
    $data['customer_id']       = '';
    $data['address']           ='';
    $data['module']            = "sampling";      
    $data['page']              = "dispatch_list"; 
	
    echo Modules::run('template/layout', $data); 
    }



public function sampling_list() {
	
	//ini_set('display_startup_errors', 1);
//ini_set('display_errors', 1);
    $data['title']             = 'sample List'; 
    $config["base_url"]        = base_url('sampling_list');
    $config["total_rows"]      = $this->Sampling_model->count_sample();
	$config["per_page"]        = 10;
    $config["uri_segment"]     = 2;
    $config["last_link"]       = "Last"; 
    $config["first_link"]      = "First"; 
    $config['next_link']       = 'Next';
    $config['prev_link']       = 'Prev';  
    $config['full_tag_open']   = "<ul class='pagination col-xs pull-right'>";
    $config['full_tag_close']  = "</ul>";
    $config['num_tag_open']    = '<li>';
    $config['num_tag_close']   = '</li>';
    $config['cur_tag_open']    = "<li class='disabled'><li class='active'><a href='#'>";
    $config['cur_tag_close']   = "<span class='sr-only'></span></a></li>";
    $config['next_tag_open']   = "<li>";
    $config['next_tag_close']  = "</li>";
    $config['prev_tag_open']   = "<li>";
    $config['prev_tagl_close'] = "</li>";
    $config['first_tag_open']  = "<li>";
    $config['first_tagl_close']= "</li>";
    $config['last_tag_open']   = "<li>";
    $config['last_tagl_close'] = "</li>";
	$this->pagination->initialize($config);
    $page                      = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
    $data["samples"]           = $this->Sampling_model->sample_listdata($config["per_page"], $page);
	
	$data["links"]             = $this->pagination->create_links();
    $data['samplelists']          = $this->Sampling_model->sample_order_list();
	
	$data['clients'] = $this->Sampling_model->allclients(); 			
	$data['brands'] = $this->Sampling_model->allbrands(); 
	$data['sample_po_no_id']=$this->input->post('sample_po_no_id');
	$data['clientid']=$this->input->post('client');	
	$data['brandid']=$this->input->post('brand');
	
	
    $data['customer_name']     = '';
    $data['customer_id']       = '';
    $data['address']           ='';
    $data['module']            = "sampling";      
    $data['page']              = "sample_listdata"; 
	
	
	
    echo Modules::run('template/layout', $data); 
    }






public function sampling_information_list() {
	
	//ini_set('display_startup_errors', 1);
//ini_set('display_errors', 1);
    $data['title']             = 'Sample Information List'; 
    $config["base_url"]        = base_url('sampling_information_list');
    $config["total_rows"]      = $this->Sampling_model->count_sample_informatiom_list();
    
  	$config["per_page"]        = 25;
    $config["uri_segment"]     = 2;
    $config["last_link"]       = "Last"; 
    $config["first_link"]      = "First"; 
    $config['next_link']       = 'Next';
    $config['prev_link']       = 'Prev';  
    $config['full_tag_open']   = "<ul class='pagination col-xs pull-right'>";
    $config['full_tag_close']  = "</ul>";
    $config['num_tag_open']    = '<li>';
    $config['num_tag_close']   = '</li>';
    $config['cur_tag_open']    = "<li class='disabled'><li class='active'><a href='#'>";
    $config['cur_tag_close']   = "<span class='sr-only'></span></a></li>";
    $config['next_tag_open']   = "<li>";
    $config['next_tag_close']  = "</li>";
    $config['prev_tag_open']   = "<li>";
    $config['prev_tagl_close'] = "</li>";
    $config['first_tag_open']  = "<li>";
    $config['first_tagl_close']= "</li>";
    $config['last_tag_open']   = "<li>";
    $config['last_tagl_close'] = "</li>";
	$this->pagination->initialize($config);
    $page                      = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
    $data["samples_infodata"]           = $this->Sampling_model->sample_informatiom_listdata($config["per_page"], $page);
	
    //echo $this->db->last_query();
    //exit;
	
	
	$data["links"]             = $this->pagination->create_links();
    $data['samplelists']          = $this->Sampling_model->sample_order_list();
	
	//$data['clients'] = $this->Sampling_model->allclients(); 			
	//$data['brands'] = $this->Sampling_model->allbrands(); 
	//$data['sample_po_no_id']=$this->input->post('sample_po_no_id');
	//$data['clientid']=$this->input->post('client');	
	//$data['brandid']=$this->input->post('brand');
	
	
	$data['sample_po_no_id']=$this->input->post('sample_po_no_id');
	$data['colors']=$this->input->post('colors');	
	$data['material_description']=$this->input->post('material_description');
	$data['start']=$this->input->post('from_date');
	$data['end']=$this->input->post('to_date');
	
	
	
    $data['customer_name']     = '';
    $data['customer_id']       = '';
    $data['address']           ='';
    $data['module']            = "sampling";      
    $data['page']              = "sample_informatiom_listdata"; 
	
	
	
    echo Modules::run('template/layout', $data); 
    }





public function add_dispatch_form($brand_sample_id = null,$reditrct_action=0)
    {
		
	
        $data['title'] = 'Add Dispatch';
        #-------------------------------#
        ///$this->form_validation->set_rules('purchase_order_no','Purchase Order No','required|max_length[100]');
        
		$this->form_validation->set_rules('dispatch_date', 'Dispatch Date') ;
		$this->form_validation->set_rules('shade_no','Shade No','required|max_length[50]');
		$this->form_validation->set_rules('challan_no','Challan No','required|max_length[50]');
			
        
		
		
	
		
		$postData = [
		'dispatch_id' => $this->input->post('dispatch_id',true),
		'sample_id'=> 0,
		'brand_sample_id'=>$this->input->post('brand_sample_id',true),
		'sample_po_no'=> $this->input->post('sample_po_no',true),
		'shade_no'=> $this->input->post('shade_no',true),
		'challan_no'=> $this->input->post('challan_no',true),
		'dispatch_date'=> $this->input->post('dispatch_date',true),
		'create_by'=> $this->session->userdata('id'),
		'approval_pending'=>$this->input->post('approval_pending'),
		'create_date'=> date('Y-m-d H:i:s')
		];
		
		
		
		
		//print_r($postData);
	//exit;
		//echo "=========".  strlen( trim($postData['dispatch_id']));
		//exit;
        #-------------------------------#
        if ($this->form_validation->run() === true) {
            #if empty $id then insert data
            if (empty(trim($postData['dispatch_id']))) {
              $tmp_dispatch_id=  $this->Sampling_model->create_dispatch($postData);
				if ($tmp_dispatch_id) {
				
					
				
				
            
        
					
					
					
					
					
					
                    #set success message
                        //$info['msg']    = display('save_successfully');
                        //$info['status'] = 1;
                        if($reditrct_action==0)
                        {
                        redirect('sampling_information_list');
                        }
                        elseif($reditrct_action==1)
                        {
                           
                           redirect('http://'.$this->session->userdata('pendancy_report_geturl')); 
                           
                           // redirect('pendancy_report');
                        }
                } else {
                    #set exception message
                        $info['msg']    = display('please_try_again');
                        $info['status'] = 0;
                }
            } else {
                if ($this->Sampling_model->update_dispatch($postData)) {
					//print_r($postData);
                    #set success message
                    //$info['msg']    = display('update_successfully');
                    
                    //$info['status'] = 1;
                    
                    //redirect('sampling_information_list');
                    
                     if($reditrct_action==0)
                        {
                        redirect('sampling_information_list');
                        }
                        elseif($reditrct_action==1)
                        {
                            //redirect('pendancy_report');
                            
                             redirect('http://'.$this->session->userdata('pendancy_report_geturl')); 
                        }
                    
                    
                    
                } else {
                    #set exception message
                    $info['msg']    = display('please_try_again');
                    $info['status'] = 0;
                } 
            }
 
            echo json_encode($info);

        } else { 
            
			
			
		
	
			
            //$data['title']    = display('edit_sample');
            //$data['sample_informations'] = $this->Sampling_model->sampling_information($sample_id);
			$data['sampleinfo'] = $this->Sampling_model->sampling_information_details($brand_sample_id);  
			
			//print_r($data['sampleinfo']);
			//exit;
			
			$data['singledispatch'] = $this->Sampling_model->singledispatch($brand_sample_id); 
			
			//print_r($data['singledispatch']);
			
			
			///$data['material_descriptions'] = $this->Sampling_model->samplingInformation_materialDescription($sample_id);
			
			
			$data['brand_sample_id']=$brand_sample_id;	
			$data['dispatch_id']=$dispatch_id;	
			
            $data['module']   = "sampling";  
            $data['page']     = "add_dispatch_form";  
			
			//print_r($data);
			//exit;
			
            echo Modules::run('template/layout', $data); 
        
        } 
    }
















    public function bdtask_customer_ledger() {
    $data['title']             = display('customer_ledger'); 
    $config["base_url"]        = base_url('customer_ledger');
    //$config["total_rows"]      = $this->customer_model->count_customer_ledger();
    $config["per_page"]        = 10;
    $config["uri_segment"]     = 20;
    $config["last_link"]       = "Last"; 
    $config["first_link"]      = "First"; 
    $config['next_link']       = 'Next';
    $config['prev_link']       = 'Prev';  
    $config['full_tag_open']   = "<ul class='pagination col-xs pull-right'>";
    $config['full_tag_close']  = "</ul>";
    $config['num_tag_open']    = '<li>';
    $config['num_tag_close']   = '</li>';
    $config['cur_tag_open']    = "<li class='disabled'><li class='active'><a href='#'>";
    $config['cur_tag_close']   = "<span class='sr-only'></span></a></li>";
    $config['next_tag_open']   = "<li>";
    $config['next_tag_close']  = "</li>";
    $config['prev_tag_open']   = "<li>";
    $config['prev_tagl_close'] = "</li>";
    $config['first_tag_open']  = "<li>";
    $config['first_tagl_close']= "</li>";
    $config['last_tag_open']   = "<li>";
    $config['last_tagl_close'] = "</li>";
    $this->pagination->initialize($config);
    $page                      = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
    $data["ledgers"]           = $this->customer_model->customer_ledgerdata($config["per_page"], $page);
    $data["links"]             = $this->pagination->create_links();
    $data['customer']          = $this->customer_model->customer_list_ledger();
    $data['customer_name']     = '';
    $data['customer_id']       = '';
    $data['address']           ='';
    $data['module']            = "customer";
    $data['page']              = "customer_ledger";   
    echo Modules::run('template/layout', $data); 
    }

    public function bdtask_customer_ledgerData() {
    $start                 = $this->input->post('from_date',true);
    $end                   = $this->input->post('to_date',true);
    $customer_id           = $this->input->post('customer_id',true);
    $customer_detail       = $this->customer_model->customer_personal_data($customer_id);
    $data['title']         = display('customer_ledger');
    $data['customer']      = $this->customer_model->customer_list_ledger();
    $data["ledgers"]       = $this->customer_model->customerledger_searchdata($customer_id, $start, $end);
    $data['customer_name'] = $customer_detail[0]['customer_name'];
    $data['customer_id']   = $customer_id;
    $data['address']       = $customer_detail[0]['customer_address'];
    $data['module']        = "customer";
    $data["links"]         = '';
    $data['page']          = "customer_ledger";   
    echo Modules::run('template/layout', $data); 
    }


    public function bdtask_customer_advance() {
    $data['title']        = display('customer_advance');    
    $data['customer_list']= $this->customer_model->customer_list_advance();
    $data['module']       = "customer";
    $data['page']         = "customer_advance";   
    echo Modules::run('template/layout', $data); 
    }

      public function insert_customer_advance(){
        $advance_type = $this->input->post('type',TRUE);
        if($advance_type ==1){
            $dr = $this->input->post('amount',TRUE);
            $tp = 'd';
        }else{
            $cr = $this->input->post('amount',TRUE);
            $tp = 'c';
        }
            $createby      = $this->session->userdata('id');
            $createdate    = date('Y-m-d H:i:s');
            $transaction_id= $this->customer_model->generator(10);
            $customer_id   = $this->input->post('customer_id',TRUE);
            $cusifo        = $this->db->select('*')->from('customer_information')->where('customer_id',$customer_id)->get()->row();
            $headn         = $customer_id.'-'.$cusifo->customer_name;
            $coainfo       = $this->db->select('*')->from('acc_coa')->where('customer_id',$customer_id)->get()->row();
    $customer_headcode = $coainfo->HeadCode;
              
                   $customer_accledger = array(
      'VNo'            =>  $transaction_id,
      'Vtype'          =>  'Advance',
      'VDate'          =>  date("Y-m-d"),
      'COAID'          =>  $customer_headcode,
      'Narration'      =>  'Customer Advance For  '.$cusifo->customer_name,
      'Debit'          =>  (!empty($dr)?$dr:0),
      'Credit'         =>  (!empty($cr)?$cr:0),
      'IsPosted'       => 1,
      'CreateBy'       => $this->session->userdata('id'),
      'CreateDate'     => date('Y-m-d H:i:s'),
      'IsAppove'       => 1
    );
                         $cc = array(
      'VNo'            =>  $transaction_id,
      'Vtype'          =>  'Advance',
      'VDate'          =>  date("Y-m-d"),
      'COAID'          =>  111000001,
      'Narration'      =>  'Cash in Hand  For '.$cusifo->customer_name.' Advance',
      'Debit'          =>  (!empty($dr)?$dr:0),
      'Credit'         =>  (!empty($cr)?$cr:0),
      'IsPosted'       =>  1,
      'CreateBy'       =>  $this->session->userdata('id'),
      'CreateDate'     =>  date('Y-m-d H:i:s'),
      'IsAppove'       =>  1
    ); 
                  
       $this->db->insert('acc_transaction',$customer_accledger);
       $this->db->insert('acc_transaction',$cc);
       redirect(base_url('advance_receipt/'.$transaction_id.'/'.$customer_id));

  }

  //customer_advance_receipt
   public function customer_advancercpt($receiptid=null,$customer_id=null) {
    $data['title']         = display('advance_receipt'); 
    $customer_id           = $this->uri->segment(3);
    $receiptdata           = $this->customer_model->advance_details($receiptid,$customer_id);
    $customer_details      = $this->customer_model->customer_personal_data($customer_id);
    $data['details']       = $receiptdata;
    $data['customer_name'] = $customer_details[0]['customer_name'];
    $data['receipt_no']    = $receiptdata[0]['VNo'];
    $data['address']       = $customer_details[0]['customer_address'];
    $data['mobile']        = $customer_details[0]['customer_mobile'];
    $data['module']        = "customer";
    $data['page']          = "customer_advance_receipt";   
    echo Modules::run('template/layout', $data); 
    }
    
    
    
    
     public function bulk_uplade_sample(){
        $data['title']         = 'Add Sample CSV';
        $data['module']        = "sampling";
        $data['page']          = "add_sample_csv"; 
        echo modules::run('template/layout', $data);
    }


     public function bulk_uplade_dispatch($sample_id=0){
        $data['title']         = 'Add Sample Dispatch CSV';
        $data['module']        = "sampling";
        $data['page']          = "add_sample_dispatch_csv";
        $data['sample_data']=  $this->Sampling_model->singledata($sample_id);
        
        
        echo modules::run('template/layout', $data);
    }


    public function upload_sample_csv_old()
    {
        $filename = $_FILES['upload_csv_file']['name'];  
        
        $basenameAndExtension = explode('.', $filename);
        $ext = end($basenameAndExtension);
        if($ext == 'csv'){
        $count=0;
        $fp = fopen($_FILES['upload_csv_file']['tmp_name'],'r') or die("can't open file");

        if (($handle = fopen($_FILES['upload_csv_file']['tmp_name'], 'r')) !== FALSE)
        {
       $i=0;
         //$this->db->trans_begin();
         while($csv_line = fgetcsv($fp,1024))
         {
            
           // echo "===========".$i;
            
            if($i==1)
            {
                
                  $brand_name=$csv_line[0];
                  $client_name=$csv_line[2];
                 
                    $array_brand=  $this->Sampling_model->brands_details($brand_name);
                if(!empty($array_brand))
                {
                $brand_id= $array_brand[0]->id;
                
                 
                }
                else
                {
                    $message = "This Brand does not match your records";
                    echo "<script type='text/javascript'>alert('$message');</script>";
                    exit;
                    
                }
                 
                $array_client=  $this->Sampling_model->client_details($client_name);
                
                 if(!empty($array_client))
                {
                $client_id=   $array_client[0]->id;
                
                 
                }
                else
                {
                    //$message = "This Client does not match your records";
                    //echo "<script type='text/javascript'>alert('$message/'//);</script>";
                    //exit;
                    $client_id=0;
                }


                //$sample_po_no = $csv_line[1];
                $sample_po_no =(!empty($csv_line[1])?$csv_line[1]:'');
               $postData = [
			'sample_po_no'  =>(!empty($csv_line[1])?$csv_line[1]:'') ,
			'po_date'  => (!empty($csv_line[4])?$csv_line[4]: date('Y-m-d')) ,
			'client'  => $client_id,
			'season'  => (!empty($csv_line[5])?$csv_line[5]:'') ,
			'receiver_contact'  =>(!empty($csv_line[3])?$csv_line[3]:'') ,
			'receiver_emial'  => (!empty($csv_line[6])?$csv_line[6]:'') ,
			'create_date'=> date('Y-m-d H:i:s'),
			'brand_id'=>$brand_id,
			'create_by'=> $this->session->userdata('id')
        ]; 
		
        $tmp_sample_id=  $this->Sampling_model->create($postData);  
        //echo $this->db->last_query();
        }
                
           
          // exit;
           
             //   echo "================".$tmp_sample_id;
                
        if (!empty($tmp_sample_id) and $i>2) 
        {
			
				$postData2 = [
					'sample_id'=>$tmp_sample_id,
					's_no'=>(!empty($csv_line[0])?$csv_line[0]:0),
					'model'=>(!empty($csv_line[1])?$csv_line[1]:''),
					'material_description'=>(!empty($csv_line[2])?$csv_line[2]:''),
					'colors'=>(!empty($csv_line[3])?$csv_line[3]:''),
					'uom'=>(!empty($csv_line[4])?$csv_line[4]:''),
					'order_date'=>(!empty($csv_line[5])?$csv_line[5]:date('Y-m-d')),
					'qty'=>(!empty($csv_line[6])?$csv_line[6]:''),
					'status'=>0,
					'sample_po_no'=>$sample_po_no,
					'create_date'=> date('Y-m-d H:i:s'),
					'create_by'=> $this->session->userdata('id')
					]; 
				//print_r($postData2);
				$this->Sampling_model->create_sampling_information($postData2);
				//echo $this->db->last_query();
					
			
				
        }	
                    
           
                
                
               
           $i++;    
         }
        
            redirect('sample_list');    
         
         //$this->db->trans_complete ();
         
    }
      }
      
     
    }
    
    
    
    
    
     public function upload_sample_csv()
    {
        
        	//ini_set('display_startup_errors', 1);
        //ini_set('display_errors', 1);
        $filename = $_FILES['upload_csv_file']['name'];  
        
        
     
        
        
        $basenameAndExtension = explode('.', $filename);
        
      
        
        $ext = end($basenameAndExtension);
        
        
        
        if($ext == 'csv' or $ext == 'CSV' ){
        $count=0;
        $fp = fopen($_FILES['upload_csv_file']['tmp_name'],'r') or die("can't open file");

        if (($handle = fopen($_FILES['upload_csv_file']['tmp_name'], 'r')) !== FALSE)
        {
       $i=0;
         //$this->db->trans_begin();
         while($csv_line = fgetcsv($fp,1024))
         {
            
            //echo "===========".$i."<br>";
            
            if($i==1)
            {
                
                 $sample_po_no =(!empty($csv_line[2])?$csv_line[2]:'');
 ;
                 //$order_date=date("Y-m-d", strtotime($order_date) );
                  $order_date=(!empty($csv_line[5])?$csv_line[5]: date('d/m/Y')) ;
                
				 $tmpdate = explode('/', $order_date);
				$order_date = $tmpdate[2].'-'.$tmpdate[1].'-'.$tmpdate[0];
                 
                 
                 
            }
            elseif($i==2)
            {
                 $receiver_name=(!empty($csv_line[2])?$csv_line[2]:'') ;
                 $receiver_contact= (!empty($csv_line[5])?$csv_line[5]:'') ;
                
            }
            elseif($i==3)
            {
                 $brand_name=(!empty($csv_line[2])?$csv_line[2]:'');
                 
                 
                    $array_brand=  $this->Sampling_model->brands_details($brand_name);
                if(!empty($array_brand))
                {
                $brand_id= $array_brand[0]->id;
                
                 
                }
                else
                {
                    //$message = "This Brand does not match your records";
                    //echo "<script type='text/javascript'>alert('$message');</script>";
                    //exit;
                     $brand_id=0;
                }
                $receiver_emial=(!empty($csv_line[5])?$csv_line[5]:'');  
                
            }
             elseif($i==4)
             {
                  $client_name=(!empty($csv_line[2])?$csv_line[2]:'');
                $array_client=  $this->Sampling_model->client_details($client_name);
                
                 if(!empty($array_client))
                {
                $client_id=   $array_client[0]->id;
                
                 
                }
                else
                {
                    //$message = "This Client does not match your records";
                    //echo "<script type='text/javascript'>alert('$message');</script>";
                    //exit;
                    $client_id=0;
                    
                }
                
                 $season=(!empty($csv_line[5])?$csv_line[5]:'') ;
                 
             
                 
                 
               $postData = [
			'sample_po_no'  =>$sample_po_no ,
			'po_date'  => $order_date ,
			'client'  => $client_id,
			'receiver_name'=>$receiver_name,
			'season'  => $season ,
			'receiver_contact'  =>$receiver_contact ,
			'receiver_emial'  => $receiver_emial ,
			'create_date'=> date('Y-m-d H:i:s'),
			'brand_id'=>$brand_id,
			'create_by'=> $this->session->userdata('id')
        ]; 
		
		
		//print_r($postData);
		//exit;
		
		
        $tmp_sample_id=  $this->Sampling_model->create($postData);  
        //echo $this->db->last_query();
                 
                 
                 
                 
                 
                 
                 
             }
                 

      
                
           
          // exit;
           
             //   echo "================".$tmp_sample_id;
                
        if (!empty($tmp_sample_id) and $i>8) 
        {
			
				
			if(!empty($csv_line[0]) and !empty($csv_line[1]) )
			{
			
                
                ///$order_date=date("Y-m-d", strtotime($order_date) );
                
                
                $order_date=(!empty($csv_line[1])?$csv_line[1]: date('d/m/Y')) ;
               
				$tmpdate = explode('/', $order_date);
				$order_date = $tmpdate[2].'-'.$tmpdate[1].'-'.$tmpdate[0];
                
                
                
				
				$postData2 = [
					'sample_id'=>$tmp_sample_id,
					's_no'=>(!empty($csv_line[0])?$csv_line[0]:0),
					'model'=>(!empty($csv_line[2])?$csv_line[2]:''),
					'material_description'=>(!empty($csv_line[3])?$csv_line[3]:''),
					'colors'=>(!empty($csv_line[4])?$csv_line[4]:''),
					'uom'=>(!empty($csv_line[6])?$csv_line[6]:''),
					'order_date'=>$order_date,
					'qty'=>(!empty($csv_line[5])?$csv_line[5]:''),
					'status'=>0,
					'sample_po_no'=>$sample_po_no,
					'create_date'=> date('Y-m-d H:i:s'),
					'create_by'=> $this->session->userdata('id')
					]; 
				//print_r($postData2);
				$this->Sampling_model->create_sampling_information($postData2);
				//echo $this->db->last_query();
					
			}
				
        }	
                    
           
                
                
               
           $i++;    
         }
        
            redirect('sample_list');    
         
         //$this->db->trans_complete ();
         
    }
      }
      
     
    }
    
    public function upload_sample_dispatch_csv($sample_id=0)
    {
        
        	ini_set('display_startup_errors', 1);
            ini_set('display_errors', 1);
        
        ////////////////////////////////////
        
         $filename = $_FILES['upload_csv_file']['name'];  
        
        $basenameAndExtension = explode('.', $filename);
        $ext = end($basenameAndExtension);
        if($ext == 'csv' or $ext == 'CSV'){
        $count=0;
        $fp = fopen($_FILES['upload_csv_file']['tmp_name'],'r') or die("can't open file");

        if (($handle = fopen($_FILES['upload_csv_file']['tmp_name'], 'r')) !== FALSE)
        {
       $i=0;
         //$this->db->trans_begin();
         while($csv_line = fgetcsv($fp,1024))
         {
            
            if($i>0)
            {
              
            if(!empty($csv_line[4]))
            {
              
                if(!empty($csv_line[6]) and !empty($csv_line[8]))
                {
              
                               $artical_no =(!empty($csv_line[2])?$csv_line[2]:'');
                               $material =(!empty($csv_line[3])?$csv_line[3]:'');
                               $colour_with_code=(!empty($csv_line[4])?$csv_line[4]:''); 
                               
                            $this->db->select('tov_sampling_information.*');
                            $this->db->from('tov_sampling_information');
                            
                            $this->db->where(array('model' => $artical_no , 'material_description' => $material, 'colors' =>  $colour_with_code,'sample_id'=>$sample_id));
                            
                            $query = $this->db->get();
                            $sample_info="";
                            if ($query->num_rows() > 0) {
                            $sample_info=  $query->result_array();
                            }
                       
                     
                       
                        $dispatch_date=(!empty($csv_line[7])?$csv_line[7]: date('d/m/Y')) ;
                       
        				$tmpdate = explode('/', $dispatch_date);
        				$dispatch_date = $tmpdate[2].'-'.$tmpdate[1].'-'.$tmpdate[0];
                           
                        
                                       $postData = [
                    		
                    		'sample_id'=> 0,
                    		'brand_sample_id'=>$sample_info[0]['brand_sample_id'],
                    		'sample_po_no'=>(!empty($sample_info[0]['sample_po_no'])?$sample_info[0]['sample_po_no']:'') ,
                    		'shade_no'=> (!empty($csv_line[6])?$csv_line[6]:''),
                    		'challan_no'=>(!empty($csv_line[8])?$csv_line[8]:''),
                    		'dispatch_date'=> $dispatch_date,
                    		'create_by'=> $this->session->userdata('id'),
                    		'approval_pending'=>0,
                    		'create_date'=> date('Y-m-d H:i:s')
                    		];
                    		
                    	
                    	
                    	
                    	  $this->db->select('tov_dispatch.*');
                            $this->db->from('tov_dispatch');
                            
                            $this->db->where(array('brand_sample_id' => $sample_info[0]['brand_sample_id'] ));
                            
                            $query = $this->db->get();
                            $sample_info="";
                            if ($query->num_rows() == 0) {
                            ///$sample_info=  $query->result_array();
                            $tmp_dispatch_id=  $this->Sampling_model->create_dispatch($postData);
                            }
                    	    
                    	//$postData=[];
                }                  
            }      
                   
                   
                   
                    
                    ///echo $this->db->last_query();
                    
                    ////echo "=================ratnesh";
                    ///print_r($sample_info);
                    
                    
           
            } 
           
                 
          $i++;        
        }
           redirect('pendancy_report');      

      }
      
        
        
        
        
        
        
        
        
        
        ////////////////////////////////////////
    }    
    }
    
    public function sample_order_info_1111111111($id=0)
    {
            $data['title']    = 'Sample Order Info';
            $data['sample'] = $this->Sampling_model->singledata($id);  
            $data['sample_information'] = $this->Sampling_model->sampling_information($id); 
			$data['sample_id']=$id;
            $data['module']   = "sampling";  
            $data['page']     = "sample_order_info";  
			$data['clients'] = $this->Sampling_model->allclients(); 			
			$data['brands'] = $this->Sampling_model->allbrands(); 			
            echo Modules::run('template/layout', $data); 
        
        
    }
    
    
    
    
    public function pendancy_report() {
        
        
        if(!empty($this->input->post('csv')))
		{
			
			$brand_id=0;
			$client_id=0;
			if(!empty($this->input->get('brand_id')))
			{
				$brand_id=$this->input->get('brand_id');
			}	
		    
			if(!empty($this->input->get('client_id')))
			{
				$client_id=$this->input->get('client_id');
			}	
			
			
		    $receiver_name=$this->input->get('receiver_name');
		    
			$receiver_name=str_replace(" ","_",$receiver_name);
			
			$season=$this->input->post('season');
			redirect('export_data/'.$client_id.'/'.$brand_id.'/'.$receiver_name.'/'.$season);    
			die();
		}	
        
        $this->session->set_userdata('pendancy_report_geturl', $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
       
	//echo "===========".$this->session->userdata('pendancy_report_geturl');
	//exit;
	//ini_set('display_startup_errors', 1);
///ini_set('display_errors', 1);

    $data['title']             = 'Pendancy Report'; 
    $config["base_url"]        = base_url('pendancy_report');
    $config["total_rows"]      = $this->Sampling_model->count_pendancy_report_list();

	$config["per_page"]        = 50;
    $config["uri_segment"]     = 2;
    $config["last_link"]       = "Last"; 
    $config["first_link"]      = "First"; 
    $config['next_link']       = 'Next';
    $config['prev_link']       = 'Prev';  
    $config['full_tag_open']   = "<ul class='pagination col-xs pull-right'>";
    $config['full_tag_close']  = "</ul>";
    $config['num_tag_open']    = '<li>';
    $config['num_tag_close']   = '</li>';
    $config['cur_tag_open']    = "<li class='disabled'><li class='active'><a href='#'>";
    $config['cur_tag_close']   = "<span class='sr-only'></span></a></li>";
    $config['next_tag_open']   = "<li>";
    $config['next_tag_close']  = "</li>";
    $config['prev_tag_open']   = "<li>";
    $config['prev_tagl_close'] = "</li>";
    $config['first_tag_open']  = "<li>";
    $config['first_tagl_close']= "</li>";
    $config['last_tag_open']   = "<li>";
    $config['last_tagl_close'] = "</li>";
	$this->pagination->initialize($config);
    $page                      = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
    $data["samples_infodata"]           = $this->Sampling_model->pendancy_report_listdata($config["per_page"], $page);
	
    //echo $this->db->last_query();
    //exit;
	
	
	$data["links"]             = $this->pagination->create_links();
    $data['samplelists']          = $this->Sampling_model->sample_order_list();
	
	
	
	
	$data['clients'] = $this->Sampling_model->allclients(); 			
	$data['brands'] = $this->Sampling_model->allbrands(); 

	
		$data['brand_id']=$this->input->get('brand_id');
		$data['client_id']=$this->input->get('client_id');
	    $data['receiver_name']=$this->input->get('receiver_name');
		$data['season']=$this->input->get('season');
	
	
	//$data['sample_po_no_id']=$this->input->post('sample_po_no_id');
	//$data['colors']=$this->input->post('colors');	
	//$data['material_description']=$this->input->post('material_description');
	//$data['start']=$this->input->post('from_date');
	//$data['end']=$this->input->post('to_date');
	
	
	
    $data['customer_name']     = '';
    $data['customer_id']       = '';
    $data['address']           ='';
    $data['module']            = "sampling";      
    $data['page']              = "pendancy_report_listdata"; 
	
	
	
    echo Modules::run('template/layout', $data); 
    }



    function ajaxget_sampling_data()
	{
		$brand_sample_id=$this->input->post('brand_sample_id');
		
		//$brand_sample_id=51;
		
		//ini_set('display_startup_errors', 1);
        ///ini_set('display_errors', 1);
		
		///$brand_sample_id=52;
		$sampling_data= $this->Sampling_model->showall_sampledata($brand_sample_id); 	
		
		foreach($sampling_data as $row)
		{
		    
		    $brand_name=$this->db->select('tov_brands.brand_name')
								->from('tov_brands')
								->where('id', $row['brand_id'])
								->get()
								->row();

		    
			$client_name=$this->db->select('tov_client.client_name')
			->from('tov_client')
			->where('id', $row['client'])
			->get()
			->row();
			
			$tmpdata  = $this->db->select('*')
                        ->from('tov_tmp_dispatch')
                        ->where('dispatch_id',$row['dispatchID'])
                        ->where('brand_sample_id',$row['brand_sample_id'])
                        ->order_by('id','asc')
                        ->get()
                        ->result_array();
			
			//echo $this->db->last_query();
			//print_r($tmpdata);
			
			
			
		    $sample_order_string.="";
		    $sample_order_string.='<div class="row">
				     <div class="col-sm-4">
                        <div class="form-group row">
                            <label for="supplier_sss" class="col-sm-4 col-form-label">Order No
                            
                            </label>
							<div class="col-sm-6">'.
                          $row['sample_po_no'].'
							</div>	
                            
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="form-group row">
                            <label for="date" class="col-sm-4 col-form-label">Order Date 
                               
                            </label>
                            <div class="col-sm-8">'.
                              date("d-m-Y", strtotime( $row['po_date']) ) .'
                            </div>
                        </div>
                    </div>
                    
                     <div class="col-sm-4">
                        <div class="form-group row">
                            <label for="date" class="col-sm-4 col-form-label">Season
                               
                            </label>
                            <div class="col-sm-8">'.
                               $row['season'].'
                            </div>
                        </div>
                    </div>
                </div>


                <div class="row">
                    <div class="col-sm-4">
                        <div class="form-group row">
                            <label for="chalan_no" class="col-sm-4 col-form-label">Brand
                               
                            </label>
                            <div class="col-sm-6">'.
                               
							$brand_name->brand_name.'
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-4">
                        <div class="form-group row">
                            <label for="adress" class="col-sm-4 col-form-label">Receiver Name
                            </label>
                            <div class="col-sm-8">'.
                               $row['receiver_name'].'
                            </div>
                        </div>
                    </div>
                </div>
				
				
				
				
				
				
                <div class="row">
                    
                     <div class="col-sm-4">
                        <div class="form-group row">
                            <label for="adress" class="col-sm-4 col-form-label">Client
                            </label>
                            <div class="col-sm-8">'.
                                $client_name->client_name.'
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-sm-4">
                        <div class="form-group row">
                            <label for="chalan_no" class="col-sm-4 col-form-label">Receiver Email
                               
                            </label>
                            <div class="col-sm-6">'.
                                
						  $row['receiver_emial'].'
							
                            </div>
                        </div>
                    </div>

                   
                    
                    
                     <div class="col-sm-4">
                        <div class="form-group row">
                            <label for="adress" class="col-sm-4 col-form-label">Receiver Mobile
                            </label>
                            <div class="col-sm-8">'.
                               $row['receiver_contact'].'
                            </div>
                        </div>
                    </div>
                </div>
                
    
                <div class="row">
                    <div class="col-sm-4">
                        <div class="form-group row">
                            <label for="chalan_no" class="col-sm-4 col-form-label">Model
                               
                            </label>
                            <div class="col-sm-6">'.
						$row['model'].'
                            </div>
                        </div>
                    </div>
                    
                     <div class="col-sm-4">
                        <div class="form-group row">
                            <label for="chalan_no" class="col-sm-4 col-form-label">Material Description
                               
                            </label>
                            <div class="col-sm-6">'.
                                
						$row['material_description'].'
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-4">
                        <div class="form-group row">
                            <label for="adress" class="col-sm-4 col-form-label">Color
                            </label>
                            <div class="col-sm-8">'.
                               $row['colors'].'
                            </div>
                        </div>
                    </div>
                </div><br>';
                
                
                $sample_order_string.='<div class="table-responsive">
                    <table class="table table-bordered table-hover" id="purchaseTable">
                        <thead>
                            <tr>
                                <th class="text-center" >S. No</th>
                                <th class="text-center">Shade No</th>
								<th class="text-center">Challan No</th>
								 <th class="text-center">Dispatch Date</th>
								 <th class="text-center">Status</th>
                            </tr>
                        </thead>';
						
						
                        
					
                            
                   
                
                
                
		     $ii=1;
		    if(count($tmpdata)>0)
		    {
		       
		        foreach($tmpdata as $row1)
		        {
		           $approvel_status="";
           
                    if(!empty($row1['dispatchID']) and $row1['approvel_status']==0)
                    {
                         $approvel_status="Sent for Approval";
                         
                    }
                    elseif($row1['approval_pending']==1 )
                    {
                        $approvel_status="Pending for Approvel";
                       
                    }
                    
                    elseif($row1['approvel_status']==0)
                    {
                        $approvel_status="Pending";
                        
                   
                    }
                    elseif($row1['approvel_status']==1)
                    {
                        $approvel_status="Approved";
                    
                      
                    }
                    elseif($row1['approvel_status']==2)
                    {
                        $approvel_status="Redo";
                     
        
                    }

		           
		           
		            
		         $sample_order_string.='<tr>
                    <td class="wt">'.$ii.'</td>
    
                    <td class="wt">'.$row1['shade_no'].'</td>
    
                    <td class="wt">'.$row1['challan_no'].'</id>   
    
                    <td class="wt">'.date("d-m-Y", strtotime( $row1['dispatch_date']) ).'</td>
    
                    <td class="wt">'.$approvel_status.'</td>
                </tr>';   
		            
		            
		         $ii++ ;  
		        }
		        
		         $ii++;
		         
		 
		         
		    }
		    
		 
		    
		    
		    $approvel_status="";
            $td_color="";
            if(!empty($row['dispatchID']) and $row['approvel_status']==0)
            {
                 $approvel_status="Sent for Approval";
                 $td_color="style='background-color:#e9d9aa;'";
            }
            elseif($row['approvel_status']==2 and $row['approval_pending']==1 )
            {
                $approvel_status="Pending for Approvel";
                $td_color="style='background-color:#ffc107;'"; 
            }
            
            elseif($row['approvel_status']==0)
            {
                $approvel_status="Pending";
                
                $td_color="style='background-color:#ed909a;'";
                
            }
            elseif($row['approvel_status']==1)
            {
                $approvel_status="Approved";
            
                $td_color="style='background-color:#5de57c;'";
            }
            elseif($row['approvel_status']==2)
            {
                $approvel_status="Redo";
                $td_color="style='background-color:#ffc107;'";

            }

		    
		   
		    
		    $sample_order_string.='<tr>
                
                <td '. $td_color.' class="wt">'.$ii.'</td>
    
                <td '. $td_color.' class="wt">'.$row['shade_no'].'</td>
    
                <td '. $td_color.' class="wt">'.$row['challan_no'].'</id>   
    
                <td '. $td_color.' class="wt">'.date("d-m-Y", strtotime( $row['dispatch_date']) ).'</td>
    
                <td '. $td_color.' class="wt">'.$approvel_status.'</td>
        </tr>';
		    
		    
		    
		 $sample_order_string.='</table>
        </div>';
		    
		    
		    ///echo "==========**". count($tmpdata);
		    
		    
		    
		    //print_r($tmpdata);
		    
		    
		}
		
		
		
		echo $sample_order_string;
	}

    
     function export_data($client_id=0,$brand_id,$receiver_name="",$season="")
	{
		
		//ini_set('display_startup_errors', 1);
        //ini_set('display_errors', 1);
		
		$receiver_name=str_replace("_"," ",$receiver_name);
		
		
		 $delimiter = ","; 
    $filename = "members-data_" . date('Y-m-d') . ".csv"; 
     
    // Create a file pointer 
    $f = fopen('php://memory', 'w'); 
     
    // Set column headers 
    $fields = array('Order Date', 'Model/Article', 'Material Description','Color','QTY', 'Status','Shade No','Challan No','Dispatch Date'); 
    fputcsv($f, $fields, $delimiter); 
		
		
		
		
		
		//fputcsv($output, ['Order Date', 'Model/Article', 'Material Description','Color','QTY','Approval', 'Status,Shade No']);


		    
	
		
		//$this->db->select('tov_sample_order.*');
        //$this->db->from('tov_sample_order');
		
		 $this->db->select('SI.order_date,SI.model,SI.material_description,SI.colors,SI.qty, SI.uom,SI.status,D.dispatch_id as dispatchID,D.shade_no,D.challan_no,D.dispatch_date,D.status as approvel_status,D.approval_pending ');
        
		
		//$this->db->select('SI.*,SO.sample_id as sample_id,SO.sample_po_no as sample_order,D.dispatch_id as dispatchID ,D.shade_no,D.shade_no,D.challan_no,D.status as approvel_status,D.approval_pending ');
		
		$this->db->from('tov_sampling_information SI');
		$this->db->join('tov_sample_order SO','SI.sample_id=SO.sample_id','left');
		$this->db->join('tov_dispatch D','SI.brand_sample_id=D.brand_sample_id','left');
		
		
		if(!empty(trim($brand_id)))
		{
			$this->db->where(array('SO.brand_id' => $brand_id));
		}
		
		if(!empty(trim($client_id)))
		{
			$this->db->where(array( 'SO.client' => $client_id));
		}	
		
		
		
		if(!empty(trim($receiver_name)))
		{
			$this->db->where(array('SO.receiver_name' => $receiver_name));
		}
		
		
		
		
		if(!empty(trim($season))   )
		{
		$this->db->where(array('SO.season'=>$season));
		}
		
		
        $this->db->order_by('SI.sample_id','desc');
        //$this->db->limit($per_page, $page);
        $query = $this->db->get();
		
       
            $order_infos= $query->result_array();
        
		foreach($order_infos as $row)
		{	
			 //$status = ($row['status'] == 1)?'Active':'Inactive'; 
			 
			 $approvel_status="";
           
                    
                    
                    
                    
                    if(!empty($row['dispatchID']) and $row['approvel_status']==0)
                    {
                         $approvel_status="Sent for Approval";
                         
                    }
                    elseif($row['approvel_status']==2 and $row['approval_pending']==1 )
                    {
                        $approvel_status="Pending for Approvel";
                       
                    }
                    
                    elseif($row['approvel_status']==0)
                    {
                        $approvel_status="Pending";
                        
                   
                    }
                    elseif($row['approvel_status']==1)
                    {
                        $approvel_status="Approved";
                    
                      
                    }
                    elseif($row['approvel_status']==2)
                    {
                        $approvel_status="Redo";
                     
        
                    }

			 
			 
			 
			 
			 
			 
			 
			 
		//$this->db->select('SI.order_date,SI.model,SI.material_description,SI.colors,SI.qty,SI.status');	 
			 
        $lineData = array($row['order_date'], $row['model'], $row['material_description'], $row['colors'], $row['qty'].' '.$row['uom'],$approvel_status,$row['shade_no'],$row['challan_no'],$row['dispatch_date']); 
        fputcsv($f, $lineData, $delimiter); 	
		}
		
		// Move back to beginning of file 
    fseek($f, 0); 
     
    // Set headers to download file rather than displayed 
    header('Content-Type: text/csv'); 
    header('Content-Disposition: attachment; filename="' . $filename . '";'); 
     
    //output all remaining data on a file pointer 
    fpassthru($f); 
		
	}
	
	
	function creatarray_dispatch()
	{
		$countsize = count($this->input->post('shade_no'));
		
		/////print_r($_REQUEST);
		
		//'approval_pending'=>$this->input->post('approval_pending'),	
		for ($i=0; $i<$countsize ; $i++) 
		{
				if(!empty($this->input->post('shade_no')[$i]) and !empty($this->input->post('challan_no')[$i]) )
				{
					$postData = [
						'dispatch_id' => $this->input->post('dispatch_id')[$i],
						'sample_id'=> 0,
						'brand_sample_id'=>$this->input->post('brand_sample_id')[$i],
						'sample_po_no'=> $this->input->post('sample_po_no')[$i],
						'shade_no'=> $this->input->post('shade_no')[$i],
						'challan_no'=> $this->input->post('challan_no')[$i],
						'dispatch_date'=> $this->input->post('dispatch_date')[$i],
						'create_by'=> $this->session->userdata('id'),
						'approval_pending'=>$this->input->post('approval_pending')[$i],
						'create_date'=> date('Y-m-d H:i:s')
						];
						
						//echo "<pre>";
						//print_r($postData);
					//exit;
						 if (empty(trim($postData['dispatch_id']))) {
							  $tmp_dispatch_id=  $this->Sampling_model->create_dispatch($postData);
								if ($tmp_dispatch_id) {
									#set success message
										//$info['msg']    = display('save_successfully');
										//$info['status'] = 1;
										
										///redirect('sampling_list');
										
								} else {
									#set exception message
										$info['msg']    = display('please_try_again');
										$info['status'] = 0;
								}
							} else {
								if ($this->Sampling_model->update_dispatch($postData)) {
									
									//print_r($postData);
									#set success message
									//$info['msg']    = display('update_successfully');
									
									//$info['status'] = 1;
									
									////redirect('sampling_list');
									
								} 
							}
				}
		
		}
		redirect('pendancy_report');
	}	
		
	
	
	
	
	
	  public function sampling_delete($sample_id=0) 
     {
            //	ini_set('display_startup_errors', 1);
///ini_set('display_errors', 1);
          
            $this->db->where('sample_id', $sample_id)
                 ->delete('tov_sample_order');

		$this->db->where('sample_id', $sample_id)
			->delete("tov_sampling_information");
        $this->session->set_flashdata('message', display('delete_successfully'));
        redirect("sample_list");
    }
    

}

