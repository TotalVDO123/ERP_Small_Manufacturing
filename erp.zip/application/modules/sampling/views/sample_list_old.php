 <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4><?php echo $title ?> </h4>
                        </div>
                    </div>
                   
                    <div class="panel-body">
    
<div class="table-responsive">
                <table class="table table-bordered" id="CustomerList1111"  width="100%">
                    <thead>
 
                        <tr>
                            <th><?php echo display('sl') ?></th>
                            <th>Sample Order No</th>
                            <th>Order Date</th>
                            <th>Client</th>
                            <th>season</th>
                            
                            <th>Email</th>
                            
                            <th width="50px;"><?php echo display('action') ?> 
                            </th>
                        </tr>
                    </thead>
                    <tbody id="customer_tablebody">
					
					
					  <?php
                                    if ($all_samples) {
                                        $sl=1;
                                        foreach ($all_samples as $all_sample) {
                                         
                                        ?>
                                        
                                        <tr>
                            <td class="text-center"><?php echo $sl;?></td>
                            <td class="text-center"><?php echo $all_sample->sample_po_no;?></td>
                            <td class="text-center"><?php echo $all_sample->po_date;?></td>
                            
                            <td class="text-center"><?php echo $all_sample->client;?></td>
                          
                            <td class="text-center"><?php echo $all_sample->season;?> </td>
							<td class="text-center"><?php echo $all_sample->receiver_emial;?> </td>
                           
                                    <td>
                                    <center>
                                       
                                        <a href="<?php echo base_url() . 'edit_sample/'.$all_sample->sample_id; ?>" class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="left" title="<?php echo display('update') ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                                        
                                   
                                      
                                        <a href="<?php echo base_url('service/service/service_delete/'.$services['service_id']) ?>" class="btn btn-danger btn-sm"  data-toggle="tooltip" data-placement="right" title="delete" onclick="return confirm('Are Your Sure ?')" data-original-title="<?php echo display('delete') ?> "><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                   
                                          
                                    </center>
                                    </td>
                                    </tr>
                                   
                                    <?php $sl++;}
                                }
                                ?>
					
					
					
                       
                    </tbody>
                    <tfoot>
                                            
                                            
                                        </tfoot>
                  </table>  
              </div>
                  
            </div>
         

        </div>
    </div>
</div>
 
