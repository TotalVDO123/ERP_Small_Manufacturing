 <div class="row">
           
			<div class="col-sm-12">
                <div class="panel panel-default">
                    <div class="panel-body"> 
                        <?php echo form_open('sample_list', array('class' => '', 'id' => 'validate')) ?>
                        <?php $today = date('Y-m-d'); ?>
                        <div class="row">
                       <div class="col-sm-4">
                        <div class="form-group row">
                            <label for="customer_name" class="col-sm-4 col-form-label">Sample </label>
                            <div class="col-sm-8">
                                
								<select name="sample_po_no_id"  class="form-control">
                                    <option value=""></option>
                                   <?php foreach($samplelists as $samplelist){?>
                                    <option value="<?php echo html_escape($samplelist['sample_po_no'])?>" 
									<?php if($samplelist['sample_po_no']==$sample_po_no_id){ echo 'selected'; } ?>><?php echo html_escape($samplelist['sample_po_no'])?></option>
                                   <?php }?>
                                </select>
                            </div>
                            </div>
                            </div> 
                            <div class="col-sm-5">
                        <div class="form-group row">
                                <label for="from_date " class="col-sm-2 col-form-label"> <?php echo display('from') ?></label>
                                <div class="col-sm-4">
                                    <input type="text" name="from_date"  value="<?php echo (!empty($start)?$start:$today); ?>" class="datepicker form-control" id="from_date"/>
                                </div>
                                 <label for="to_date" class="col-sm-2 col-form-label"> <?php echo display('to') ?></label>
                                <div class="col-sm-4">
                                    <input type="text" name="to_date" value="<?php echo (!empty($end)?$end:$today); ?>" class="datepicker form-control" id="to_date"/>
                                </div>
                          
                        </div>
                    </div>

                    <?php /* ?>
					<div class="col-sm-3">
                                <button type="submit" class="btn btn-success "><i class="fa fa-search-plus" aria-hidden="true"></i> <?php echo display('search') ?></button>
                                <button type="button" class="btn btn-warning"  onclick="printDiv('printableArea')"><?php echo display('print') ?></button>
                    </div>
					<?php  */?>
                </div>
				
				<div class="row">
				<div class="col-sm-4">
				 <div class="form-group row">
                            <label for="customer_name" class="col-sm-4 col-form-label">Client list </label>
                            <div class="col-sm-8">
                                  
								  <select name="client" id="client" class="form-control "
                                    tabindex="1">
                                    <option value="">Select</option>
									
									<?php
									foreach($clients as $client )
									{
									?>
									<option value="<?php echo $client->id ?>" <?php if($client->id==$clientid){ echo 'selected'; } ?>  ><?php echo $client->client_name ?></option>
									<?php
									}
									?>
								</select>
                            </div>
                            </div>
				</div>
				
				
				<div class="col-sm-5">
				 <div class="form-group row">
							<label for="from_date " class="col-sm-2 col-form-label"> Brand List</label>
                        <div class="col-sm-4">
							
                             <select name="brand" id="brand" class="form-control " 
                                    tabindex="1">
                                    <option value="">Select</option>
									
									<?php
									foreach($brands as $brand )
									{
									?>
									<option value="<?php echo $brand->id ?>" <?php if($brand->id==$brandid){ echo 'selected'; } ?> ><?php echo $brand->brand_name ?></option>
									<?php
									}
									?>
								</select>
						</div>
					    
				

						
                            </div>
				</div>
				
					  <div class="col-sm-3">
                                   <button type="submit" class="btn btn-success "><i class="fa fa-search-plus" aria-hidden="true"></i> <?php echo display('search') ?></button>
                                <button type="button" class="btn btn-warning"  onclick="printDiv('printableArea')"><?php echo display('print') ?></button>
                                </div>	

				</div>
				</form>
				
                        <?php echo form_close() ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- customer ledger -->
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                  
                    <div class="panel-body">
                        <div id="printableArea">
							<?php /*  ?>
                            <?php if ($customer_name) { ?>
                                <div class="text-center">
                                    <h3> <?php echo $customer_name;?> </h3>
                                    <h4><?php echo display('address') ?> : <?php echo $address?> </h4>
                                    <h4> <?php echo display('print_date') ?>: <?php echo date("d/m/Y h:i:s"); ?> </h4>
                                </div>
                            <?php } ?>
							<?php */  ?>
                            <div class="table-responsive">

                                <table class="table table-bordered table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th class="text-center">Sample Order No</th>
                                            <th class="text-center">Order Date</th>
                                            <th class="text-center">Client</th>
											<th class="text-center">Brand</th>
                                            <th class="text-center">Season</th>
                                            <th class="text-center">Email</th>
                                            <th class="text-center">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($samples) {
                                           
                                            foreach ($samples as $row) {
												$brand_name=$this->db->select('tov_brands.brand_name')
												->from('tov_brands')
												->where('id', $row['brand_id'])
												->get()
												->row();
                                               
                                                ?>
                                                <tr>
                                                    <td class="text-center"><?php echo html_escape($row['sample_po_no']) ?></td>
                                                    <td><?php echo  date("d-m-Y", strtotime($row['po_date']) ); ?></td>
                                                   
												<?php
												
												$client_name=$this->db->select('tov_client.client_name')
												->from('tov_client')
												->where('id', $row['client'])
												->get()
												->row();
												?>								
														

												   <td>
                                                 
                                                    <?php echo $client_name->client_name ?>
                                                </td>
                                                   
												  <td>
                                                 
                                                    <?php echo $brand_name->brand_name ?>
                                                </td>  
												   
												   
												   
												   
                                                    <td >
                                                        <?php
                                                        
                                                            echo html_escape($row['season'])
                                                       
                                                        ?>
                                                    </td>
                                                    <td >
                                                        <?php
                                                        
                                                         echo html_escape($row['receiver_emial'])
                                                      
                                                        ?>
                                                    </td>
                                                    <td >
                                                        
                                                        
                                    <?php /* ?>
                                    <center>
                                        <a href="<?php echo base_url() . 'add_dispatch/'.$row['sample_id'] ?>" class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="left" title="<?php echo display('update') ?>"><i class="fa fa-truck" aria-hidden="true"></i></a>
                                        <a href="<?php echo base_url('service/service1/service_delete/'.$row['sample_id']) ?>" class="btn btn-danger btn-sm"  data-toggle="tooltip" data-placement="right" title="delete" onclick="return confirm('Are Your Sure ?')" data-original-title="<?php echo display('delete') ?> "><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                    </center>
                                   <?php */ ?>                 
                                                    
                                    <center>
                                       
                                         <a href="<?php echo base_url() . 'bulk_uplade_dispatch/'.$row['sample_id']; ?>" class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="left" title="<?php echo 'Uplade Bulk Dispatch' ?>"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
                                        <a href="<?php echo base_url() . 'edit_sample/'.$row['sample_id']; ?>" class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="left" title="<?php echo display('update') ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                                        

                                        <a href="<?php echo base_url('sampling/sampling/sampling_delete/'.$row['sample_id']) ?>" class="btn btn-danger btn-sm"  data-toggle="tooltip" data-placement="right" title="delete" onclick="return confirm('Are Your Sure ?')" data-original-title="<?php echo display('delete') ?> "><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                   
                                          
                                    </center>                
                                                    
                                                    
                                                    
                                                    
                                                    </td>
                                                </tr>
                                                <?php
                                            }
                                        }else{
                                        ?>
                                        <tr><td colspan="6"><center>No Record Found</center></td></tr>
                                        
                                        <?php }?>
                                    
                                    </tbody>
                                    
                                </table>
                                
                            </div>
                        </div>
                        <div class="text-right"><?php echo $links ?></div>
                    </div>
                </div>
            </div>
        </div>