 <div class="row">
           
			<div class="col-sm-12">
                <div class="panel panel-default">
                    <div class="panel-body"> 
                        <?php echo form_open('sampling_list', array('class' => '', 'id' => 'validate')) ?>
                        <?php $today = date('Y-m-d'); ?>
                        <div class="row">
                       <div class="col-sm-4">
                        <div class="form-group row">
                            <label for="customer_name" class="col-sm-4 col-form-label">Sample </label>
                            <div class="col-sm-8">
                                
								<select name="sample_po_no_id"  class="form-control">
                                    <option value=""></option>
                                   <?php foreach($samplelists as $samplelist){?>
                                    <option value="<?php echo html_escape($samplelist['sample_po_no'])?>" 
									<?php if($samplelist['sample_po_no']==$sample_po_no_id){ echo 'selected'; } ?>><?php echo html_escape($samplelist['sample_po_no'])?></option>
                                   <?php }?>
                                </select>
                            </div>
                            </div>
                            </div> 
                            <div class="col-sm-5">
                        <div class="form-group row">
                                <label for="from_date " class="col-sm-2 col-form-label"> <?php echo display('from') ?></label>
                                <div class="col-sm-4">
                                    <input type="text" name="from_date"  value="<?php echo (!empty($start)?$start:$today); ?>" class="datepicker form-control" id="from_date"/>
                                </div>
                                 <label for="to_date" class="col-sm-2 col-form-label"> <?php echo display('to') ?></label>
                                <div class="col-sm-4">
                                    <input type="text" name="to_date" value="<?php echo (!empty($end)?$end:$today); ?>" class="datepicker form-control" id="to_date"/>
                                </div>
                          
                        </div>
                    </div>

                    <?php /* ?>
					<div class="col-sm-3">
                                <button type="submit" class="btn btn-success "><i class="fa fa-search-plus" aria-hidden="true"></i> <?php echo display('search') ?></button>
                                <button type="button" class="btn btn-warning"  onclick="printDiv('printableArea')"><?php echo display('print') ?></button>
                    </div>
					<?php  */?>
                </div>
				
				<div class="row">
				<div class="col-sm-4">
				 <div class="form-group row">
                            <label for="customer_name" class="col-sm-4 col-form-label">Client list </label>
                            <div class="col-sm-8">
                                  
								  <select name="client" id="client" class="form-control "
                                    tabindex="1">
                                    <option value="">Select</option>
									
									<?php
									foreach($clients as $client )
									{
									?>
									<option value="<?php echo $client->id ?>" <?php if($client->id==$clientid){ echo 'selected'; } ?>  ><?php echo $client->client_name ?></option>
									<?php
									}
									?>
								</select>
                            </div>
                            </div>
				</div>
				
				
				<div class="col-sm-5">
				 <div class="form-group row">
							<label for="from_date " class="col-sm-2 col-form-label"> Brand List</label>
                        <div class="col-sm-4">
							
                             <select name="brand" id="brand" class="form-control " 
                                    tabindex="1">
                                    <option value="">Select</option>
									
									<?php
									foreach($brands as $brand )
									{
									?>
									<option value="<?php echo $brand->id ?>" <?php if($brand->id==$brandid){ echo 'selected'; } ?> ><?php echo $brand->brand_name ?></option>
									<?php
									}
									?>
								</select>
						</div>
					    
				

						
                            </div>
				</div>
				
					  <div class="col-sm-3">
                                   <button type="submit" class="btn btn-success "><i class="fa fa-search-plus" aria-hidden="true"></i> <?php echo display('search') ?></button>
                                <button type="button" class="btn btn-warning"  onclick="printDiv('printableArea')"><?php echo display('print') ?></button>
                                </div>	

				</div>
				</form>
				
                        <?php echo form_close() ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- customer ledger -->
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                  
                    <div class="panel-body">
                        <div id="printableArea">
							<?php /*  ?>
                            <?php if ($customer_name) { ?>
                                <div class="text-center">
                                    <h3> <?php echo $customer_name;?> </h3>
                                    <h4><?php echo display('address') ?> : <?php echo $address?> </h4>
                                    <h4> <?php echo display('print_date') ?>: <?php echo date("d/m/Y h:i:s"); ?> </h4>
                                </div>
                            <?php } ?>
							<?php */  ?>
                            <div class="table-responsive">

                                <table class="table table-bordered table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th class="text-center">Material Description</th>
                                            <th class="text-center">Color</th>
                                            <th class="text-center">Shade No</th>
											<th class="text-center">Challan No</th>
                                            <th class="text-center">Dispatch Date</th>
                                            <th class="text-center"> Approval Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($dispatchs) {
                                           
                                            foreach ($dispatchs as $dispatch) {
												
                                               
                                                ?>
                                                <tr>
                                                    <td class="text-center"><?php echo html_escape($dispatch['material_description']) ?></td>
                                                    <td><?php echo $dispatch['colors']; ?></td>
                                                   
												

												   <td>
                                                 
                                                    <?php echo $dispatch['shade_no']?>
                                                </td>
                                                   
												  <td>
                                                 
                                                    <?php echo $dispatch['challan_no'] ?>
                                                </td>  
												   
												   
												   
												   
                                                    <td >
                                                        <?php
                                                        
                                                            echo html_escape($dispatch['dispatch_date'])
                                                       
                                                        ?>
                                                    </td>
                                                  
                                                    <td >
                                                         <center>
                                       
                                        <a href="<?php echo base_url() . 'dispatch_approval_form/'.$dispatch['dispatch_id'] ?>" class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="left"  ><i class="fa fa-space-shuttle" aria-hidden="true"></i></a>
                                        
                                   
                                      <?php /* ?>
                                        <a href="<?php echo base_url('service/service1/service_delete/'.$row['sample_id']) ?>" class="btn btn-danger btn-sm"  data-toggle="tooltip" data-placement="right" title="delete" onclick="return confirm('Are Your Sure ?')" data-original-title="<?php echo display('delete') ?> "><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                   <?php */ ?>
                                          
                                    </center>
                                                    </td>
                                                </tr>
                                                <?php
                                            }
                                        }else{
                                        ?>
                                        <tr><td colspan="6"><center>No Record Found</center></td></tr>
                                        
                                        <?php }?>
                                    
                                    </tbody>
                                    
                                </table>
                                
                            </div>
                        </div>
                        <div class="text-right"><?php echo $links ?></div>
                    </div>
                </div>
            </div>
        </div>