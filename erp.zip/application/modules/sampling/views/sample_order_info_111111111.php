<script src="<?php echo base_url()?>my-assets/js/admin_js/purchase.js" type="text/javascript"></script>


<div class="row">
    <div class="col-sm-12">
        <div class="panel panel-bd lobidrag">
            <div class="panel-heading">
                <div class="panel-title">
                    <h4>Add Sample</h4>
                </div>
            </div>

            <div class="panel-body">
                <?php echo form_open_multipart('add_sample',array('class' => 'form-vertical', 'id' => 'insert_sampling','name' => 'insert_sampling'))?>

				<input type="hidden" name="sample_id" id="sample_id" value="<?php echo $sample_id?>">	
                
				<?php
				
				if(!empty($sample->sample_po_no))
				{
					$sample_po_no=$sample->sample_po_no;
					
				}	
				?>
				
				
				
				
				<div class="row">
                    <div class="col-sm-6">
                        <div class="form-group row">
                            <label for="supplier_sss" class="col-sm-4 col-form-label">Brand
                            
                            </label>
							<div class="col-sm-6">
                            <select name="brand" id="brand" class="form-control " required=""
                                    tabindex="1">
                                    <option value="">Select</option>
									
									<?php
									foreach($brands as $brand )
									{
									?>
									<option value="<?php echo $brand->id ?>" <?php if($brand->id==$sample->brand_id){ echo 'selected'; } ?> ><?php echo $brand->brand_name ?></option>
									<?php
									}
									
									?>
									
									
								</select>
							</div>	
                            
                        </div>
                    </div>

                </div>
				
				
				<div class="row">
                    <div class="col-sm-6">
                        <div class="form-group row">
                            <label for="supplier_sss" class="col-sm-4 col-form-label">Sample Order No
                            
                            </label>
                            <div class="col-sm-6">
                             
							 <input class="form-control" id="sample_po_no" type="text" name="sample_po_no"
                                 placeholder="Sample Order No" value="<?php echo $sample->sample_po_no ?>">
							
							</div>
                            
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="form-group row">
                            <label for="date" class="col-sm-4 col-form-label">Order Date 
                               
                            </label>
                            <div class="col-sm-8">
                                <?php 
								$date = date('Y-m-d');
								if(!empty(	$sample->po_date))
								{
									$date=$sample->po_date;
								}	
								?>
                                <input type="text" required tabindex="2" class="form-control datepicker"
                                    name="po_date" value="<?php echo $date; ?>" id="date" />
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group row">
                            <label for="chalan_no" class="col-sm-4 col-form-label">Client
                               
                            </label>
                            <div class="col-sm-6">
                               
								  
								  <select name="client" id="client" class="form-control " required=""
                                    tabindex="1">
                                    <option value="">Select</option>
									
									<?php
									foreach($clients as $client )
									{
									?>
									<option value="<?php echo $client->id ?>" <?php if($client->id==$sample->client){ echo 'selected'; } ?> ><?php echo $client->client_name ?></option>
									<?php
									}
									
									?>
									
									
								</select>
								  
								  
								  
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="form-group row">
                            <label for="adress" class="col-sm-4 col-form-label">Season
                            </label>
                            <div class="col-sm-8">
                                <input class="form-control" id="season" type="text" name="season"
                                 placeholder="Season" value="<?php echo $sample->season?>">
                            </div>
                        </div>
                    </div>
                </div>
				
				
				
				
				
				
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group row">
                            <label for="chalan_no" class="col-sm-4 col-form-label">Receiver's Mobile
                               
                            </label>
                            <div class="col-sm-6">
                                
								
								<input class="form-control" id="receiver_contact" type="text"
                                 name="receiver_contact" placeholder="Receiver's Mobile"
                                  value="<?php echo $sample->receiver_contact?>">
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="form-group row">
                            <label for="adress" class="col-sm-4 col-form-label">Receiver's Email
                            </label>
                            <div class="col-sm-8">
                                  <input type="text" class="form-control input-mask-trigger" name="receiver_emial" id="receiver_emial"
                                 data-inputmask="'alias': 'email'" im-insert="true"
                                 placeholder="Receiver's Email"
                                 value="<?php echo $sample->receiver_emial?>">
                            </div>
                        </div>
                    </div>
                </div>
                

                <br>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover" id="purchaseTable">
                        <thead>
                            <tr>
                                <th class="text-center" width="20%">S. No<i
                                        </th>
                                <th class="text-center">Model/Article</th>
								
								
								<th class="text-center">Material Description</th>
								
								
								 <th class="text-center">Color</th>
								 
								 <th class="text-center">UOM</th>
								 
                                <th class="text-center">Order Date</th>
                                
                                <th class="text-center">QTY</th>
                               
                                
                                
                               <!-- <th class="text-center invoice_fields">STATUS </th>-->
                                
								
                                <th class="text-center"><?php echo display('action') ?></th>
                            </tr>
                        </thead>
						
						
                        <tbody id="addPurchaseItem">
						
						<?php
						
					
						
						foreach($sample_information as $row )
						{
						
						
						
						?>
                            <tr>
                                <td class="span3 supplier">
                                   
								 <?php echo $row->s_no ?>
						<input type="hidden" name="sno[]" id="sno" value="<?php echo $row->s_no?>">
                                  
                                </td>

                                <td class="wt">
                                     <input class="form-control" id="model" type="text" name="model[]"
                                 placeholder="Model" value="<?php echo $row->model?>">
                                </td>

                                <td class="wt">
                                    <textarea name="material_description[]" id="material_description" class="form-control"
                                 placeholder="Material Description"><?php echo $row->material_description	?></textarea>

                                <td class="wt">
                                     <input type="text" name="colors[]" class="form-control" id="colors"
                                 placeholder="Color"
                                 value="<?php echo $row->colors?>">
                                </td>

                                <td class="text-right">
                                    <input type="text" class="form-control" name="uom[]" id="uom"
                                 placeholder="UOM"
                                 value="<?php echo $row->uom?>">
                                </td>
                                <td class="test">
                                   <input type="text" id="order_date" autocomplete="off" class="form-control datepicker expiry_date_1"
                                        placeholder="Order Date" name="order_date[]" value="<?php echo $row->order_date?>" />
                                </td>
                                <!-- Discount start-->
                                <td>
                                      <input type="number" class="form-control" name="qty[]" id="qty"
                                 placeholder="QTY"
                                 value="<?php echo $row->qty?>">

                                </td>
                                <!--<td>
                                     <select name="status" id="status" class="form-control " required=""
                                    tabindex="1">
                                    <option value="0">Pending</option>
									<option value="1">Approved</option>
                                </select>
                                </td> -->
                                <!-- Discount end-->
                                <!-- VAT  start-->
                                
                              
                                <!-- VAT  end-->

                               
                                <td>



                                    <button class="btn btn-danger text-right red" type="button"
                                        value="<?php echo display('delete')?>" onclick="deleteRow(this)" tabindex="8"><i
                                            class="fa fa-close"></i></button>
                                </td>
                            </tr>
							
						<?php
						}
						
						if(empty($sample_information))
						{	
						?>	
							
							
							
							<tr>
                                <td class="span3 supplier">
                                   
								1
						<input type="hidden" name="sno[]" id="sno" value="1">
                                  
                                </td>

                                <td class="wt">
                                     <input class="form-control" id="model" type="text" name="model[]"
                                 placeholder="Model" value="">
                                </td>

                                <td class="wt">
                                    <textarea name="material_description[]" id="material_description" class="form-control"
                                 placeholder="Material Description"></textarea>

                                <td class="wt">
                                     <input type="text" name="colors[]" class="form-control" id="colors"
                                 placeholder="Color"
                                 value="">
                                </td>

                                <td class="text-right">
                                    <input type="text" class="form-control" name="uom[]" id="uom"
                                 placeholder="UOM"
                                 value="">
                                </td>
                                <td class="test">
                                   <input type="text" id="order_date" autocomplete="off" class="form-control datepicker expiry_date_1"
                                        placeholder="Order Date" name="order_date[]" value="" />
                                </td>
                                <!-- Discount start-->
                                <td>
                                      <input type="number" class="form-control" name="qty[]" id="qty"
                                 placeholder="QTY"
                                 value="">

                                </td>
                                <!--<td>
                                     <select name="status" id="status" class="form-control " required=""
                                    tabindex="1">
                                    <option value="0">Pending</option>
									<option value="1">Approved</option>
                                </select>
                                </td> -->
                                <!-- Discount end-->
                                <!-- VAT  start-->
                                
                              
                                <!-- VAT  end-->

                               
                                <td>



                                    <button class="btn btn-danger text-right red" type="button"
                                        value="<?php echo display('delete')?>" onclick="deleteRow(this)" tabindex="8"><i
                                            class="fa fa-close"></i></button>
                                </td>
                            </tr>
							
							<?php 
						}
							?>
							
                        </tbody>
                        <tfoot>
                            <tr>

                                <td class="text-right" colspan="9"><b></b></td>
                              
                                <td colspan="1"> <button type="button" id="add_invoice_item" class="btn btn-info"
                                        name="add-invoice-item" onClick="addPurchaseOrderField1('addPurchaseItem')"
                                        tabindex="9"><i class="fa fa-plus"></i></button>

                                    <input type="hidden" name="baseUrl" class="baseUrl"
                                        value="<?php echo base_url();?>" />
                                </td>
                            </tr>
                           
                          

                         
                         
                        </tfoot>
                    </table>
                    <input type="hidden" name="finyear" value="<?php echo financial_year(); ?>">
                    <p hidden id="pay-amount"></p>
                    <p hidden id="change-amount"></p>
                   



				  
					
					
					
					
					
                </div>

                <div class="form-group row text-right">
                    <div class="col-sm-12 p-20">
                        <input type="submit" id="add_sampling" class="btn btn-primary btn-large" name="add-sampling"
                            value="<?php echo display('submit') ?>" />

                    </div>
                </div>
                <?php echo form_close()?>
            </div>
        </div>

    </div>
</div>