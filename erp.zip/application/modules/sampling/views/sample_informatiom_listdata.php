 <div class="row">
           
			<div class="col-sm-12">
                <div class="panel panel-default">
                    <div class="panel-body"> 
                        <?php echo form_open('sampling_information_list', array('class' => '', 'id' => 'validate')) ?>
                        <?php $today = date('Y-m-d'); ?>
                        <div class="row">
                       <div class="col-sm-4">
                        <div class="form-group row">
                            <label for="customer_name" class="col-sm-4 col-form-label">Sample Order No </label>
                            <div class="col-sm-8">
                                
								<select name="sample_po_no_id"  class="form-control">
                                    <option value=""></option>
                                   <?php foreach($samplelists as $samplelist){?>
                                    <option value="<?php echo html_escape($samplelist['sample_po_no'])?>" 
									<?php if($samplelist['sample_po_no']==$sample_po_no_id){ echo 'selected'; } ?>><?php echo html_escape($samplelist['sample_po_no'])?></option>
                                   <?php }?>
                                </select>
                            </div>
                            </div>
                            </div> 
                            <div class="col-sm-5">
                        <div class="form-group row">
                                <label for="from_date " class="col-sm-2 col-form-label"> <?php echo display('from') ?></label>
                                <div class="col-sm-4">
                                    <input type="text" name="from_date"  value="<?php echo (!empty($start)?$start:''); ?>" class="datepicker form-control" id="from_date"/>
                                </div>
                                 <label for="to_date" class="col-sm-2 col-form-label"> <?php echo display('to') ?></label>
                                <div class="col-sm-4">
                                    <input type="text" name="to_date" value="<?php echo (!empty($end)?$end:''); ?>" class="datepicker form-control" id="to_date"/>
                                </div>
                          
                        </div>
                    </div>

                    <?php /* ?>
					<div class="col-sm-3">
                                <button type="submit" class="btn btn-success "><i class="fa fa-search-plus" aria-hidden="true"></i> <?php echo display('search') ?></button>
                                <button type="button" class="btn btn-warning"  onclick="printDiv('printableArea')"><?php echo display('print') ?></button>
                    </div>
					<?php  */?>
                </div>
				
				<div class="row">
				<div class="col-sm-4">
				 <div class="form-group row">
                            <label for="customer_name" class="col-sm-4 col-form-label">Color </label>
                            <div class="col-sm-8">
                             <input type="text" name="colors"  value="<?php echo $colors ; ?>" class="form-control" id="colors"/>     
							
                            </div>
                            </div>
				</div>
				
				
				<div class="col-sm-5">
				 <div class="form-group row">
							<label for="material_description" class="col-sm-2 col-form-label">Material Description</label>
                        <div class="col-sm-4">
							<input type="text" name="material_description"  value="<?php echo $material_description ; ?>" class="form-control" id="material_description"/>     
                            
						</div>
					    
				

						
                            </div>
				</div>
				
					  <div class="col-sm-3">
                                   <button type="submit" class="btn btn-success "><i class="fa fa-search-plus" aria-hidden="true"></i> <?php echo display('search') ?></button>
                                <button type="button" class="btn btn-warning"  onclick="printDiv('printableArea')"><?php echo display('print') ?></button>
                                </div>	

				</div>
				</form>
				
                        <?php echo form_close() ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- customer ledger -->
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                  
                    <div class="panel-body">
                        <div id="printableArea">
							<?php /*  ?>
                            <?php if ($customer_name) { ?>
                                <div class="text-center">
                                    <h3> <?php echo $customer_name;?> </h3>
                                    <h4><?php echo display('address') ?> : <?php echo $address?> </h4>
                                    <h4> <?php echo display('print_date') ?>: <?php echo date("d/m/Y h:i:s"); ?> </h4>
                                </div>
                            <?php } ?>
							<?php */  ?>
                            <div class="table-responsive">

                                <table class="table table-bordered table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th class="text-center">Sample Order No</th>
                                            <th class="text-center">S No</th>
                                            <th class="text-center">Model/Article</th>
											<th class="text-center">Material Description</th>
                                            <th class="text-right">Color</th>
                                            <th class="text-right">UOM</th>
                                            
                                            <th class="text-right">Order Date</th>
                                            <th class="text-right">QTY</th>
                                            <th class="text-right">Add Dispatch</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($samples_infodata) {
                                           
                                            foreach ($samples_infodata as $row) 
                                            {
												
                                                ?>
                                                <tr>
                                                    <td class="text-center"><?php echo html_escape($row['sample_po_no']) ?></td>
                                                    <td><?php echo $row['s_no']; ?></td>
                                                   
																
														

												   <td>
                                                 
                                                    <?php echo $row['model'] ?>
                                                </td>
                                                   
												  <td>
                                                 
                                                    <?php echo $row['material_description'] ?>
                                                </td>  
												   
												   
												   
												   
                                                    <td >
                                                        <?php echo html_escape($row['colors']) ?>
                                                    </td>
                                                    <td >
                                                        <?php echo html_escape($row['uom']) ?>
                                                    </td>
                                                     <td >
                                                        <?php echo  date("d-m-Y", strtotime($row['order_date']) );  ?>
                                                    </td>
                                                    
                                                     <td >
                                                        <?php echo html_escape($row['qty']) ?>
                                                    </td>
                                                    
                                                    
                                                    <td >
                                                         <center>
                                        <?php
                                        
                                        if($row['d_status']!=1)
                                        {
                                        ?>
                                        <a href="<?php echo base_url() . 'add_dispatch_form/'.$row['brand_sample_id'] ?>" class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="left" title="<?php echo display('update') ?>"><i class="fa fa-truck" aria-hidden="true"></i></a>
                                        
                                        <?php
                                        }
                                        else
                                        {
                                        ?>
                                        <b>Approved</b>
                                        <?php
                                        }
                                        ?>
                                          
                                    </center>
                                                    </td>
                                                </tr>
                                                <?php
                                            }
                                        }else{
                                        ?>
                                        <tr><td colspan="6"><center>No Record Found</center></td></tr>
                                        
                                        <?php }?>
                                    
                                    </tbody>
                                    
                                </table>
                                
                            </div>
                        </div>
                        <div class="text-right"><?php echo $links ?></div>
                    </div>
                </div>
            </div>
        </div>