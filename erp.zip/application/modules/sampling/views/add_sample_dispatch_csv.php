 <div class="row">
            <div class="col-sm-12 col-md-12">
                <!-- Multiple panels with drag & drop -->
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4><?php echo display('csv_file_informaion')?></h4>
                        </div>
                    </div>
                    <div class="panel-body">
                       <a href="<?php echo base_url('assets/data/csv/add_sample_data_format1.csv') ?>" class="btn btn-primary pull-right"><i class="fa fa-download"></i> Download Sample Dispatch File</a>
                            <span class="text-warning">The first line in downloaded csv file should remain as it is. Please do not change the order of columns Please make sure the csv file is UTF-8 encoded .<p></p>
                    
                    <?php
                    
                    //print_r ( $sample_data );
                    ?>
                    
                    	<?php
												
							$client_name=$this->db->select('tov_client.client_name')
							->from('tov_client')
							->where('id',  $sample_data->client)
							->get()
							->row();
							?>	
                    
                      <div class="row">
                       <div class="col-sm-6">
                        <div class="form-group row">
                            <label for="customer_name" class="col-sm-4 col-form-label">Sample Order </label>
                            <div class="col-sm-6">
                              <?php echo $sample_data->sample_po_no ?>   
							
                            </div>
                            </div>
                            </div> 
                        <div class="col-sm-6">
                        <div class="form-group row">
                                <label for="from_date " class="col-sm-2 col-form-label"> Client</label>
                                <div class="col-sm-6">
                                 <?php echo $client_name->client_name ?>
                                </div>
                                 
                          
                        </div>
                    </div>

                   
                </div>
                    	
                    	<?php
                    	$brand_name=$this->db->select('tov_brands.brand_name')
												->from('tov_brands')
												->where('id',  $sample_data->brand_id)
												->get()
												->row();
                                               
                        ?>
                    
                   <div class="row">
                       <div class="col-sm-6">
                        <div class="form-group row">
                            <label for="customer_name" class="col-sm-4 col-form-label">Brand </label>
                            <div class="col-sm-6">
                         <?php echo $brand_name->brand_name ?>        
						
                            </div>
                            </div>
                            </div> 
                        <div class="col-sm-6">
                        <div class="form-group row">
                                <label for="from_date " class="col-sm-2 col-form-label"> Season</label>
                                <div class="col-sm-6">
                                   <?php echo $sample_data->season ?>
                                </div>
                                 
                          
                        </div>
                    </div>

                   
                </div>    
                    
                  <div class="row">
                       <div class="col-sm-6">
                        <div class="form-group row">
                            <label for="customer_name" class="col-sm-4 col-form-label">Email </label>
                            <div class="col-sm-6">
                             <?php echo $sample_data->receiver_emial ?>    
							
                            </div>
                            </div>
                            </div> 
                        <div class="col-sm-6">
                        <div class="form-group row">
                                <label for="from_date " class="col-sm-2 col-form-label"> Receiver Name</label>
                                <div class="col-sm-6">
                                   <?php echo $sample_data->receiver_name ?>
                                </div>
                                 
                          
                        </div>
                    </div>

                   
                </div>        
                     
                    
                    
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4><?php echo 'Import Sample  Dispatch CSV' ?></h4>
                        </div>
                    </div>
                     <?php echo form_open_multipart('sampling/sampling/upload_sample_dispatch_csv/'.$sample_data->sample_id ,array('class' => 'form-vertical', 'id' => 'validate','name' => 'insert_product'))?>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group row">
                                    <label for="upload_csv_file" class="col-sm-4 col-form-label"><?php echo display('upload_csv_file') ?> <i class="text-danger">*</i></label>
                                    <div class="col-sm-8">
                                        <input class="form-control" name="upload_csv_file" type="file" id="upload_csv_file" placeholder="<?php echo display('upload_csv_file') ?>" required>
                                    </div>
                                </div>
                            </div>
                        </div>
            
                        <div class="form-group row">
                            <div class="col-sm-6">
                                <input type="submit" id="add-product" class="btn btn-primary btn-large" name="add-product" value="<?php echo display('submit') ?>" />
                              <!--  <input type="submit" value="<?php echo display('submit_and_add_another') ?>" name="add-product-another" class="btn btn-large btn-success" id="add-product-another">-->
                            </div>
                        </div>
                    </div>
                    <?php echo form_close()?>
                </div>
            </div>
        </div>


