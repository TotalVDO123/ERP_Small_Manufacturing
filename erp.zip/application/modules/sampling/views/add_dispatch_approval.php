 <div class="row">
     <div class="col-sm-12">
         <div class="panel panel-bd lobidrag">
             <div class="panel-heading">
                 <div class="panel-title">
                     <h4><?php echo $title ?> </h4>
                 </div>
             </div>

             <div class="panel-body">
                 <?php echo form_open('dispatch_approval_form/'.$dispatch_id,'class="" id="dispatch_approval_form"')
				 ?>

               
				 <input type="hidden" name="dispatch_id" class="form-control" id="dispatch_id"  value="<?php echo $dispatch_id ?>">
				 
				 <div class="form-group row">
                     
					<label for="customer_email"
                         class="col-sm-4 text-right col-form-label">Approval Status</label>
                     <div class="col-sm-4">
                         <div class="">

                            <select name="approved_status" id="approved_status"  class="form-control " required=""
                                    tabindex="1">
                                    <option value="0" <?php if($dispatch_details->status==0){ echo 'selected'; } ?> >Pending</option>
									<option value="1" <?php if($dispatch_details->status==1){ echo 'selected'; } ?> >Approved</option>
									<option value="2" <?php if($dispatch_details->status==2){ echo 'selected'; } ?>>Rejected</option>
									
                                </select> 
                         </div>

                     </div>
                 </div>
				 
				 
				 <div class="form-group row">
                     
					<label for="review"
                         class="col-sm-4 text-right col-form-label">Review</label>
                     <div class="col-sm-4">
                         <div class="">

                         <textarea name="description" id="description" class="form-control"
                                 placeholder="Review" rows="7"><?php echo $dispatch_details->description ?></textarea>
                         </div>

                     </div>
                 </div>
				 
				 
			
  			 
				 
				 
				 
              



                 <div class="form-group row">
                     <div class="col-sm-6 text-right">
                     </div>
                     

                     <div class="col-sm-6 text-left">
                         <div class="">

                             <button type="submit" class="btn btn-success">
                                 Action</button>

                         </div>

                     </div>
                     
                     
                     
                 </div>


                 <?php echo form_close();?>
             </div>

         </div>
     </div>
 </div>
 
 
 
 <script>
 
 
 
 

 
 $('#list_material_description').change(function(){
	
	 
	 
var sampleid=$('#sampleid').val();	 	 
	 
var material_description=$('#list_material_description').val();	 
 //alert(purchase_order_no);
 $.ajax({
  url: "<?php echo base_url()?>sampling/sampling/ajaxget_material_description_color/",
 type : 'POST',
  data: {
            material_description: material_description,sampleid:sampleid
        },
  success: function(html){
	
	
	  
	  //$('#list_color').append(html);
	 $('#brand_sample_id').html(html);
	  
    //$("#results").append(html);
  }
});
 
 });
 
 
 
 </script>
 <script>
$('#brand_sample_id').change(function(){
	
	 
var brand_sample_id=$('#brand_sample_id').val();	 
 //alert(purchase_order_no);
 $.ajax({
  url: "<?php echo base_url()?>sampling/sampling/ajaxget_dispatch/"+brand_sample_id,
 type : 'GET',
  success: function(html){
	  //alert(html);
	 var data = html.split("||");
	  //alert(data[0]);
	  
	  $('#dispatch_id').val(data[0]);
	  $('#shade_no').val(data[1]);
	  $('#dispatch_date').val(data[2]);
	  $('#challan_no').val(data[3]);
	  
    //$("#results").append(html);
  }
});
 
 });
 </script>