 <div class="row">
           
			<div class="col-sm-12">
                <div class="panel panel-default">
                    <div class="panel-body"> 
                        <?php echo form_open('pendancy_report', array('class' => '', 'id' => 'validate')) ?>
                        <?php $today = date('Y-m-d'); ?>
                        <div class="row">
                       	<div class="col-sm-4">
				 <div class="form-group row">
                            <label for="customer_name" class="col-sm-4 col-form-label">Client list </label>
                            <div class="col-sm-8">
                                  
								  <select name="client_id" id="client_id" class="form-control "
                                    tabindex="1">
                                    <option value="">Select</option>
									
									<?php
									foreach($clients as $client )
									{
									?>
									<option value="<?php echo $client->id ?>" <?php if($client->id==$client_id){ echo 'selected'; } ?>  ><?php echo $client->client_name ?></option>
									<?php
									}
									?>
								</select>
                            </div>
                            </div>
				</div>
                       
                       	<div class="col-sm-5">
				 <div class="form-group row">
							<label for="from_date " class="col-sm-2 col-form-label"> Brand List</label>
                        <div class="col-sm-4">
							
                             <select name="brand_id" id="brand_id" class="form-control " 
                                    tabindex="1">
                                    <option value="">Select</option>
									
									<?php
									foreach($brands as $brand )
									{
									?>
									<option value="<?php echo $brand->id ?>" <?php if($brand->id==$brand_id){ echo 'selected'; } ?> ><?php echo $brand->brand_name ?></option>
									<?php
									}
									?>
								</select>
						</div>
					    
				

						
                            </div>
				</div>
                           

                    <?php /* ?>
					<div class="col-sm-3">
                                <button type="submit" class="btn btn-success "><i class="fa fa-search-plus" aria-hidden="true"></i> <?php echo display('search') ?></button>
                                <button type="button" class="btn btn-warning"  onclick="printDiv('printableArea')"><?php echo display('print') ?></button>
                    </div>
					<?php  */?>
                </div>
				
				<div class="row">
				<div class="col-sm-4">
				 <div class="form-group row">
                            <label for="receiver_name" class="col-sm-4 col-form-label">Receiver Name </label>
                            
                             <div class="col-sm-8">
                            <select name="receiver_name" id="receiver_name" class="form-control " 
                                    tabindex="1">
                                    <option value="">Select</option>
									
									<?php
									foreach($samplelists as $samplelist )
									{
									?>
									<option value="<?php echo $samplelist['receiver_name'] ?>" <?php if($samplelist['receiver_name']==$receiver_name){ echo 'selected'; } ?> ><?php echo $samplelist['receiver_name'] ?></option>
									<?php
									}
									?>
								</select>

                            </div>
                            </div>
				</div>

				<div class="col-sm-5">
				 <div class="form-group row">
							<label for="season" class="col-sm-2 col-form-label">Season</label>
                        <div class="col-sm-4">
							
							
							
							 <select name="season" id="season" class="form-control " 
                                    tabindex="1">
                                    <option value="">Select</option>
									
									<?php
									foreach($samplelists as $samplelist )
									{
									?>
									<option value="<?php echo $samplelist['season'] ?>" <?php if($samplelist['season']==$season){ echo 'selected'; } ?> ><?php echo $samplelist['season'] ?></option>
									<?php
									}
									?>
								</select>
							

						 
						</div>
					    
				

						
                </div>
				</div>
				
					  <div class="col-sm-3">
                                   <button type="submit" class="btn btn-success "><i class="fa fa-search-plus" aria-hidden="true"></i> <?php echo display('search') ?></button>
                                <button type="button" class="btn btn-warning"  onclick="printDiv('printableArea')"><?php echo display('print') ?></button>
                                
                                <button type="submit" id="export_csv" name="csv" value="1" class="btn btn-success "><i class="fa fa-search-plus" aria-hidden="true"></i> CSV</button>
                                
                                </div>	

				</div>
				</form>
				
                        <?php echo form_close() ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- customer ledger -->
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                  
                    <div class="panel-body">
                        <div id="printableArea">
							<?php /*  ?>
                            <?php if ($customer_name) { ?>
                                <div class="text-center">
                                    <h3> <?php echo $customer_name;?> </h3>
                                    <h4><?php echo display('address') ?> : <?php echo $address?> </h4>
                                    <h4> <?php echo display('print_date') ?>: <?php echo date("d/m/Y h:i:s"); ?> </h4>
                                </div>
                            <?php } ?>
							<?php */  ?>
                            <div class="table-responsive">

                                <table class="table table-bordered table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th class="text-right">Order Date</th>
                                            <th class="text-center">Model/Article</th>
											<th class="text-center">Material Description</th>
                                            <th class="text-right">Color</th>
                                            <th class="text-right">QTY</th>
                                            <th class="text-center">Approval Status</th>
                                            <th class="text-center">Shade No</th>
                                            <th class="text-right">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($samples_infodata) {
                                           
                                            foreach ($samples_infodata as $row) 
                                            {
											
                                                    $approvel_status="";
                                                    $td_color="";
                                                    
                                                    
                                                    
                                                    if(!empty($row['dispatchID']) and $row['approvel_status']==0)
                                                    {
                                                         $approvel_status="Sent for Approval";
                                                         $td_color="style='background-color:#e9d9aa;'";
                                                    }
                                                    
                                                    elseif($row['approvel_status']==2 and $row['approval_pending']==1 )
                                                    {
                                                        $approvel_status="Pending for Approvel";
                                                        $td_color="style='background-color:#ffc107;'"; 
                                                    }
                                                    
                                                    elseif($row['approvel_status']==0)
                                                    {
                                                        $approvel_status="Pending";
                                                        
                                                        $td_color="style='background-color:#ed909a;'";
                                                        
                                                    }
                                                    elseif($row['approvel_status']==1)
                                                    {
                                                        $approvel_status="Approved";
                                                    
                                                        $td_color="style='background-color:#5de57c;'";
                                                    }
                                                    elseif($row['approvel_status']==2)
                                                    {
                                                        $approvel_status="Redo";
                                                        $td_color="style='background-color:#ffc107;'";

                                                    }

                                                ?>
                                                <tr  <?php echo $td_color; ?>  >
                                                    
                                                    <td >
                                                        <?php echo  date("d-m-Y", strtotime($row['order_date']) );  ?>
                                                    </td>
        										    
        										    <td class="modalinloop" data-toggle="modal" data-target="#exampleModal" data-id="<?php echo $row['brand_sample_id'] ?>" ><?php echo $row['model'] ?></td>
												    
												    <td>
                                                        <?php echo $row['material_description'] ?>
                                                    </td>  
												    <td >
                                                        <?php echo html_escape($row['colors']) ?>
                                                    </td>
                                                    
                                                    <td >
                                                        <?php echo html_escape( $row['qty'].' '.$row['uom']) ?>
                                                    </td>
                                                    
                                                    
                                                 <td class="text-center"><?php echo html_escape($approvel_status) ?></td>    
                                                <td class="text-center"><?php echo html_escape($row['shade_no']) ?></td>        
                                                    

                                                    <td >
                                                         <center>
                                                
                                               
                                         <?php
                                         
                                         
                                         
                                        if(!empty($row['dispatchID']) and $row['approvel_status']==0)
                                        {
                                        ?> 
                                        <a href="<?php echo base_url() . 'dispatch_approval_form/'.$row['dispatchID'] ?>" class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="left" title="Create Approval"  ><i class="fa fa-space-shuttle" aria-hidden="true"></i></a>
                                        
                                        <?php                                 
                                        }
                                        elseif($row['approvel_status']==2 and $row['approval_pending']==1)
                                        {
                                        ?>    
                                        <a href="<?php echo base_url() . 'dispatch_approval_form/'.$row['dispatchID'] ?>" class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="left" title="Create Approval"  ><i class="fa fa-space-shuttle" aria-hidden="true"></i></a>    
                                        <?php    
                                        }
                                        elseif($row['approvel_status']!=1)
                                        { 
                                         ?>       
                                                
                                        <a href="<?php echo base_url() . 'add_dispatch_form/'.$row['brand_sample_id'].'/1' ?>" class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="left" title="Dispatch"><i class="fa fa-truck" aria-hidden="true"></i></a>
                                        
                                        <?php
                                        }
                                        ?>
                                 
                                          
                                    </center>
                                                    </td>
                                                </tr>
                                                <?php
                                            }
                                        }else{
                                        ?>
                                        <tr><td colspan="6"><center>No Record Found</center></td></tr>
                                        
                                        <?php }?>
                                    
                                    </tbody>
                                    
                                </table>
                                
                            </div>
                        </div>
                        <div class="text-right"><?php echo $links ?></div>
                    </div>
                </div>
            </div>
        </div>
        
        
        
        
        <div class="modal fade modalinloop" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">New message</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      
        
        
        
        
        <div class="panel-body" id="head_info">
                
				
				
			
		
              
                

                
            </div>
            
      
      
      
      
      
      
      
      
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
       <!-- <button type="button" class="btn btn-primary">Send message</button>-->
      </div>
    </div>
  </div>
</div>


<script>
$('.modalinloop').on('show.bs.modal', function (event) {
  
   var brand_sample_id=$(event.relatedTarget).data('id');
  
  
  var button = $(event.relatedTarget) // Button that triggered the modal
  var recipient = button.data('whatever') // Extract info from data-* attributes
  // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
  // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.

  
  
  
  $.ajax({
  url: "<?php echo base_url()?>sampling/sampling/ajaxget_sampling_data/",
 type : 'POST',
  data: {
            brand_sample_id: brand_sample_id
        },
  success: function(data){
	
	//alert(data);
	  
	  //$('#list_color').append(html);
	 $('#head_info').html(data);
	  
    //$("#results").append(html);
  }
});
  
  
  
  var modal = $(this)
  modal.find('.modal-title').text('New message to1111 ' + recipient)
  modal.find('.modal-body input').val(recipient)
})

</script>

