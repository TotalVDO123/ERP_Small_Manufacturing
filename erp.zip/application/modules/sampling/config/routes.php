<?php
defined('BASEPATH') OR exit('No direct script access allowed');



$route['add_sample']         = "sampling/sampling/bdtask_form";
//$route['sample_list']        = "sampling/sampling/index";
$route['edit_sample/(:num)'] = 'sampling/sampling/bdtask_form/$1';

$route['add_dispatch']         = "sampling/sampling/dispatch_form";

$route['add_dispatch/(:num)']         = "sampling/sampling/dispatch_form/$1";

$route['add_dispatch_form/(:num)']         = "sampling/sampling/add_dispatch_form/$1";

$route['add_dispatch_form/(:num)/(:num)']         = "sampling/sampling/add_dispatch_form/$1/$2";


$route['sample_list']        = "sampling/sampling/sample_list";
$route['sample_list/(:num)']        = "sampling/sampling/sample_list/$1";


$route['creatarray_dispatch']         = "sampling/sampling/creatarray_dispatch";




$route['pendancy_report']        = "sampling/sampling/pendancy_report";
$route['pendancy_report/(:num)']        = "sampling/sampling/pendancy_report/$1";




$route['sampling_list']         = "sampling/sampling/sampling_list";
$route['sampling_list/(:num)']  = "sampling/sampling/sampling_list/$1";



$route['export_data']  = "sampling/sampling/export_data";
$route['export_data/(:num)']  = "sampling/sampling/export_data/$1";
$route['export_data/(:num)/(:num)']  = "sampling/sampling/export_data/$1/$2";
$route['export_data/(:num)/(:num)/(:any)']  = "sampling/sampling/export_data/$1/$2/$3";
$route['export_data/(:num)/(:num)/(:any)/(:any)']  = "sampling/sampling/export_data/$1/$2/$3/$4";





$route['sampling_information_list']         = "sampling/sampling/sampling_information_list";
$route['sampling_information_list/(:num)']  = "sampling/sampling/sampling_information_list/$1";







$route['dispatch_approvel_list']         = "sampling/sampling/dispatch_approvel_list";
$route['dispatch_approvel_list/(:num)']  = "sampling/sampling/dispatch_approvel_list/$1";

$route['dispatch_approvel_data']         = "sampling/sampling/dispatch_approvel_data";
$route['dispatch_approvel_data/(:num)']  = "sampling/sampling/dispatch_approvel_data/$1";

//$route['sample_order_info/(:num)']  = "sampling/sampling/sample_order_info/$1";




$route['dispatch_approval_form/(:num)']  = "sampling/sampling/dispatch_approval_form/$1";

$route['bulk_uplade_sample']        = "sampling/sampling/bulk_uplade_sample";

$route['bulk_uplade_dispatch/(:num)']        = "sampling/sampling/bulk_uplade_dispatch/$1";

$route['upload_sample_dispatch_csv/(:num)']        = "sampling/sampling/upload_sample_dispatch_csv/$1";




$route['credit_customer']      = "customer/customer/bdtask_credit_customer";
$route['paid_customer']        = "customer/customer/bdtask_paid_customer";
$route['customer_ledger']      = "customer/customer/bdtask_customer_ledger";
$route['customer_ledger/(:num)']      = "customer/customer/bdtask_customer_ledger/$1";
$route['customer_ledgerdata']  = "customer/customer/bdtask_customer_ledgerData";
$route['customer_advance']     = "customer/customer/bdtask_customer_advance";
$route['advance_receipt/(:any)/(:num)']= "customer/customer/customer_advancercpt/$1/$1";