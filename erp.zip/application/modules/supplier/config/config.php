<?php
// module directory name
$HmvcConfig['supplier']["_title"]     = "supplier Details ";
$HmvcConfig['supplier']["_description"] = "Simple supplier processing System";
	  
$HmvcConfig['supplier']['_database'] = true;
$HmvcConfig['supplier']["_tables"] = array( 
	'supplier_information',
);
