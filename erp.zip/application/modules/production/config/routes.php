<?php
defined('BASEPATH') OR exit('No direct script access allowed');



$route['add_production']         = "production/production/bdtask_form";

$route['edit_production/(:num)'] = 'production/production/bdtask_form/$1';


$route['production_list']         = "production/production/production_list";
$route['production_list/(:num)']  = "production/production/production_list/$1";



$route['bulk_uplade_production']         = "production/production/bulk_uplade_production";



$route['production_dispatch_list']         = "production/production/production_dispatch_list";
$route['production_dispatch_list/(:num)']  = "production/production/production_dispatch_list/$1";

$route['creatarray_production_dispatch']         = "production/production/creatarray_production_dispatch";


$route['create_production_dispatch_debit']         = "production/production/create_production_dispatch_debit";
$route['create_production_dispatch_debit/(:num)']  = "production/production/create_production_dispatch_debit/$1";

$route['production_approval_list']         = "production/production/production_approval_list";
$route['production_approval_list/(:num)']  = "production/production/production_approval_list/$1";



$route['production_approved_reject']         = "production/production/production_approved_reject";




$route['creatarray_production_dispatch_debit']         = "production/production/creatarray_production_dispatch_debit";

$route['dispatch_form']         = "production/production/dispatch_form";


///$route['add_production_dispatch']         = "production/production/production_dispatch";

////////////////////////////////////////////////////////////////////

$route['sample_list']        = "sampling/sampling/index";
//$route['edit_sample/(:num)'] = 'sampling/sampling/bdtask_form/$1';

$route['add_dispatch']         = "sampling/sampling/dispatch_form";

$route['add_dispatch/(:num)']         = "sampling/sampling/dispatch_form/$1";





$route['dispatch_list']         = "sampling/sampling/dispatch_list";
$route['dispatch_list/(:num)']  = "sampling/sampling/dispatch_list/$1";

$route['dispatch_approvel_data']         = "sampling/sampling/dispatch_approvel_data";
$route['dispatch_approvel_data/(:num)']  = "sampling/sampling/dispatch_approvel_data/$1";

$route['dispatch_approval_form/(:num)']  = "sampling/sampling/dispatch_approval_form/$1";




$route['credit_customer']      = "customer/customer/bdtask_credit_customer";
$route['paid_customer']        = "customer/customer/bdtask_paid_customer";
$route['customer_ledger']      = "customer/customer/bdtask_customer_ledger";
$route['customer_ledger/(:num)']      = "customer/customer/bdtask_customer_ledger/$1";
$route['customer_ledgerdata']  = "customer/customer/bdtask_customer_ledgerData";
$route['customer_advance']     = "customer/customer/bdtask_customer_advance";
$route['advance_receipt/(:any)/(:num)']= "customer/customer/customer_advancercpt/$1/$1";