
<div class="row">
    <div class="col-sm-12">
        <div class="panel panel-bd lobidrag">
            <div class="panel-heading">
                <div class="panel-title">
                    <h4>Add Production Dispatch</h4>
                </div>
            </div>

            <div class="panel-body">
                <?php echo form_open_multipart('dispatch_form',array('class' => 'form-vertical', 'id' => 'insert_production_dispatch','name' => 'insert_production'))?>

				<input type="hidden" name="production_id" id="production_id" value="<?php echo $production->production_id ?>">	
                

				<div class="row">
                    <div class="col-sm-6">
                        <div class="form-group row">
                            <label for="supplier_sss" class="col-sm-4 col-form-label">Brand
                            
                            </label>
							<div class="col-sm-6">
                            <select name="brand" id="brand" class="form-control " required=""
                                    tabindex="1">
                                    <option value="">Select</option>
									
									<?php
									foreach($brands as $brand )
									{
									?>
									<option value="<?php echo $brand->id ?>" <?php if($brand->id==$production->brand_id){ echo 'selected'; } ?> ><?php echo $brand->brand_name ?></option>
									<?php
									}
									
									?>
									
									
								</select>
							</div>	
                        </div>
                    </div>
                    
                    
                    
                    
                    
                    
							
							  <div class="col-sm-6">
                        <div class="form-group row">
                            <label for="invoce_no" class="col-sm-4 col-form-label">INVOICE NO 
                               
                            </label>
                            <div class="col-sm-8">
                                	 <input class="form-control" id="invoce_no" type="text" name="invoce_no"
                                 placeholder="INVOICE NO" value="<?php echo $production->invoce_no ?>">
                            </div>
                        </div>
                    </div>
							
                    
                    
                    
                    

                </div>
				
				
				<div class="row">
                    <div class="col-sm-6">
                        <div class="form-group row">
                            <label for="supplier_sss" class="col-sm-4 col-form-label">P.O No
                            
                            </label>
                            <div class="col-sm-6">
                             
                                   <select name="po_no" id="po_no" class="form-control " required=""
                                    tabindex="1">
                                    <option value="">Select</option>
									
									<?php
									foreach($production_lists as $production_list )
									{
									?>
									<option value="<?php echo $production_list['production_id'] ?>" <?php if($production_list['production_id']==$production->production_id){ echo 'selected'; } ?> ><?php echo $production_list['purchase_order_no'] ?></option>
									<?php
									}
									
									?>
									
									
								</select>
                                 
                                 
                            
                                 
							
							</div>
                            
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="form-group row">
                            <label for="po_date" class="col-sm-4 col-form-label">Dispatch Date 
                            </label>
                            <div class="col-sm-8">
                                <?php 
								$date = date('Y-m-d');
								if(!empty(	$production->dispatch_date))
								{
									$date=$production->dispatch_date;
								}	
								?>
                                <input type="text" required tabindex="2" class="form-control datepicker"
                                    name="dispatch_date" value="<?php echo $date; ?>" id="date" />
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group row">
                            <label for="chalan_no" class="col-sm-4 col-form-label">Client
                               
                            </label>
                            <div class="col-sm-6">
                               
								  
								  <select name="client" id="client" class="form-control " required=""
                                    tabindex="1">
                                    <option value="">Select</option>
									
									<?php
									foreach($clients as $client )
									{
									?>
									<option value="<?php echo $client->id ?>" <?php if($client->id==$production->client_id){ echo 'selected'; } ?> ><?php echo $client->client_name ?></option>
									<?php
									}
									
									?>
									
									
								</select>
								  
								  
								  
                            </div>
                        </div>
                    </div>

                    
                    <?php /* ?>
                    <div class="col-sm-6">
                        <div class="form-group row">
                            <label for="adress" class="col-sm-4 col-form-label">CSD
                            </label>
                            
							<div class="col-sm-8">
                                <?php 
								$date = date('Y-m-d');
								if(!empty(	$production->csd_date))
								{
									$date=$production->csd_date;
								}	
								?>
                                <input type="text" required tabindex="2" class="form-control datepicker"
                                    name="csd" value="<?php echo $date; ?>" id="csd" />
                            </div>
                        </div>
                    </div>
                    
                    <?php */ ?>
                    
                    
                </div>
				
				
				<?php
				$product_catlog='';
				$product_catlog.='<select name="product_catalogue_id[]"  onchange="choosevalue(value)" class="form-control article-code" tabindex="1"><option value="">Select</option>';
									
								
									foreach($product_catalogue_lists as $product_catalogue_list )
									{
								
					$product_catlog.='<option value="'.$product_catalogue_list['product_catalogue_id'].' " >'. $product_catalogue_list['article_code'].'</option>';
								
									}
									
                    $product_catlog.='</select>';
                                 
				
			
				
				
				
				?>
				
				
				<?php /* ?>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group row">
                            <label for="chalan_no" class="col-sm-4 col-form-label">Receiver Contacts
                               
                            </label>
                            <div class="col-sm-6">
                                
								
								<input class="form-control" id="receiver_contact" type="text"
                                 name="receiver_contact" placeholder="Receiver Contacts"
                                  value="<?php echo $sample->receiver_contact?>">
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="form-group row">
                            <label for="adress" class="col-sm-4 col-form-label">Email
                            </label>
                            <div class="col-sm-8">
                                  <input type="text" class="form-control input-mask-trigger" name="receiver_emial" id="receiver_emial"
                                 data-inputmask="'alias': 'email'" im-insert="true"
                                 placeholder="Email"
                                 value="<?php echo $sample->receiver_emial?>">
                            </div>
                        </div>
                    </div>
                </div>
                <?php */ ?>
                <br>
                <div class="table-responsive">
                    <table class="table table-bordered table-hover" id="purchaseTable">
                        <thead>
                            <tr>
                                <!--<th class="text-center" width="20%">
								 Description                                </th> -->
								 
								 
								 <th class="text-center">Article Code</th>
								 <th class="text-center">Lace Type</th>
								 <th class="text-center">Material Type</th>
								 <th class="text-center">No Of Colors</th>
								 
                                <th class="text-center">Width</th>
                                <th class="text-center">Length</th>
							
								<th class="text-center">Color</th>
								 
								<th class="text-center">UOM</th>
								<th class="text-center">QTY: </th>
								<th class="text-center">Rate: </th>
                               
                                
                                
                               <!-- <th class="text-center invoice_fields">STATUS </th>-->
                                
								
                                <th class="text-center"><?php echo display('action') ?></th>
                            </tr>
                        </thead>
						
						
                        <tbody id="addPurchaseItem">
						
						<?php
						
					
						
						foreach($production_information as $row )
						{
						
						$discription_data =$this->Production_model->production_discription_information_details($row->production_information_id ); 
						?>
                            <tr>
                              <!--    <td class="wt">
							  
							  <button type="button" class="btn btn-primary modalinloop" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo">Description
							   <input type="text" name="article_code[]" class="form-control article_code" placeholder="Width" value="1234">
							   </button>
                                </td>-->
                                
                                
                                <td class="wt">rat
                                
                                    <input type="hidden" name="product_catalogue_id[]" class="form-control" placeholder="Article Code" value="<?php echo $discription_data[0]->product_catalogue_id ?>">
                                    
                                    	<?php echo  $product_catlog ?></td>
                                 <td class="wt"><input type="text" name="lace_type[]" class="form-control" placeholder="Lace Type" value="<?php echo $discription_data[0]->lace_type ?>"></td>
                                 <td class="wt"><input type="text" name="material_type[]" class="form-control" placeholder="Material Type" value="<?php echo $discription_data[0]->material_type ?>"></td>
                                  <td class="wt"><input type="text" name="no_of_colors[]" class="form-control" placeholder="No Of Colors" value="<?php echo $discription_data[0]->no_of_colors ?>"></td>
                                
                                <td class="wt">
                                     
                                     
                                     
                                     <input type="hidden" name="production_information_id[]" class="form-control"  value="<?php echo $row->production_information_id ?>">
									 
									 
									 <input type="text" name="width[]" class="form-control" placeholder="Width" value="<?php echo $row->width?>">	 
                                </td>
                                
                                
                                 <td class="wt">
                                     
								
									 <input type="text" name="length[]" class="form-control" placeholder="Length" value="<?php echo $row->length?>">
									 
                                </td>
                                

                                <td class="wt">
                                    
									<input type="text" name="colors[]" class="form-control" placeholder="Color" value="<?php echo $row->color?>">

                                <td class="wt">
                                     <input type="text" name="umo[]" class="form-control" placeholder="UMO" value="<?php echo $row->uom?>">
                                </td>

                                <td class="text-right">
                                     <input type="number" class="form-control" name="qty[]" placeholder="QTY" value="<?php echo $row->qty?>">
                                </td>
                                <td class="test">
                                  <input type="number" class="form-control" name="rate[]" placeholder="RATE" value="<?php echo $row->rate?>">
                                </td>
                                <!-- Discount start-->
                               
                                <!--<td>
                                     <select name="status" id="status" class="form-control " required=""
                                    tabindex="1">
                                    <option value="0">Pending</option>
									<option value="1">Approved</option>
                                </select>
                                </td> -->
                                <!-- Discount end-->
                                <!-- VAT  start-->
                                
                              
                                <!-- VAT  end-->

                               
                                <td>



                                    <button class="btn btn-danger text-right red" type="button"
                                        value="<?php echo display('delete')?>" onclick="deleteRow(this)" tabindex="8"><i
                                            class="fa fa-close"></i></button>
                                </td>
                            </tr>
							
						<?php
						}
						
						$count=1;
						if(empty($sample_information))
						{	
						?>	
							
							
							
							<tr>
                               
                               
                               <!--
                               <td class="wt">
							   <button type="button" class="btn btn-primary modalinloop" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo">Description
                                
                                <input type="text" name="article_code[]" class="form-control article_code" placeholder="Width" value="1234">
                                </button>
                                </td> -->
                                
                                <td class="wt">
                                    <!--<input type="text" name="article_code[]" class="form-control" placeholder="Article Code"> -->
                                    <?php echo  $product_catlog ?>
                                    
                                    </td>
                                 <td class="wt"><input type="text" name="lace_type[]" class="form-control lacetype" id="lacetype_<?php echo $count?>'" placeholder="Lace Type"></td>
                                 <td class="wt"><input type="text" name="material_type[]" class="form-control" id="materialtype_<?php echo $count?>'" placeholder="Material Type"></td>
                                  <td class="wt"><input type="text" name="no_of_colors[]" class="form-control" id="noofcolors_<?php echo $count?>'" placeholder="No Of Colors"></td>
                                
                                <td class="wt">
									 <input type="text" name="width[]" class="form-control" placeholder="Width" value="">
                                </td>
								
                                
                                <td class="wt">
                                     <input type="text" name="length[]" class="form-control" placeholder="Length" value="">
                                </td>
								   
								<td class="wt">
                                     <input type="text" name="colors[]" class="form-control" placeholder="Color" value="">
                                </td>

							  <td class="wt">
                                     <input type="text" name="umo[]" class="form-control" placeholder="UMO" value="">
                                </td>
								
								<td>
                                      <input type="number" class="form-control" name="qty[]" placeholder="QTY" value="">

                                </td>
								<td>
                                      <input type="number" class="form-control" name="rate[]" placeholder="RATE" value="">

                                </td>
                               
                                <td>



                                    <button class="btn btn-danger text-right red" type="button"
                                        value="<?php echo display('delete')?>" onclick="deleteRow(this)" tabindex="8"><i
                                            class="fa fa-close"></i></button>
                                </td>
                            </tr>
							
							<?php 
						}
							?>
							
                        </tbody>
                       <?php
                       	if(empty($production->production_id))
						{	
						?>
                       
                       
                        <tfoot>
                            <tr>

                                <td class="text-right" colspan="10"><b></b></td>
                              
                                <td colspan="1"> <button type="button" id="add_invoice_item" class="btn btn-info"
                                        name="add-invoice-item" onClick="addPurchaseOrderField1('addPurchaseItem')"
                                        tabindex="9"><i class="fa fa-plus"></i></button>

                                    <input type="hidden" name="baseUrl" class="baseUrl"
                                        value="<?php echo base_url();?>" />
                                </td>
                            </tr>
                           
                          

                         
                         
                        </tfoot>
                    
                    <?php
                    }
                    ?>
                    
                    </table>
                    <input type="hidden" name="finyear" value="<?php echo financial_year(); ?>">
                    <p hidden id="pay-amount"></p>
                    <p hidden id="change-amount"></p>
                   



				  
					
					
					
					
					
                </div>

                <div class="form-group row text-right">
                    <div class="col-sm-12 p-20">
                        <input type="submit" id="add_sampling" class="btn btn-primary btn-large" name="add-sampling"
                            value="<?php echo display('submit') ?>" />

                    </div>
                </div>
                <?php echo form_close()?>
            </div>
        </div>

    </div>
</div>

<div class="modal fade modalinloop" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">New message</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form>
          <div class="form-group">
            <label for="article_code" class="col-form-label">Article Code:</label>
            <input type="text" name="article_code" class="form-control" id="article_code">
          </div>
          
          <div class="lace_type">
            <label for="recipient-name" class="col-form-label">Lace Type:</label>
            <input type="text" name="lace_type" class="form-control" id="lace_type">
          </div>
          
          <div class="material_type">
            <label for="material_type" class="col-form-label">Material Type:</label>
            <input type="text" name="material_type" class="form-control" id="material_type">
          </div>
          
          <div class="material_type">
            <label for="no_of_colors" class="col-form-label">No Of Colors:</label>
            <input type="text" name="no_of_colors" class="form-control" id="no_of_colors">
          </div>
          
          
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Add Description</button>
      </div>
    </div>
  </div>
</div>


<script>
$('.modalinloop').on('show.bs.modal', function (event) {
    
    
     var val = $(this).closest("options").find(".article_code").val();
    
    alert(val);
    
    alert($(this).find('.article_code').val());
     console.log($(this));
  var button = $(event.relatedTarget) // Button that triggered the modal
  var recipient = button.data('whatever') // Extract info from data-* attributes
  // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
  // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
  var modal = $(this)
  //modal.find('.modal-title').text('New message to ' + recipient)
  //modal.find('.modal-body input').val(recipient)
  
   //$(this).find('.article_code').val('1234');
   
  
   
})

</script>

<script>
 var limits = 500;
        "use strict";
function addPurchaseOrderField1(divName){
      
      var row = $("#purchaseTable tbody tr").length;
    var count = row + 1;
      var  tab1 = 0;
      var  tab2 = 0;
      var  tab3 = 0;
      var  tab4 = 0;
      var  tab5 = 0;
      var  tab6 = 0;
      var  tab7 = 0;
      var  tab8 = 0;
      var  tab9 = 0;
      var  tab10 = 0;
      var  tab11 = 0;
      var  tab12 = 0;
      var  tab13 = 0;
      var  tab14 = 0;
      
  //alert(randomString(10,'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'));
        if (count == limits)  {
            alert("You have reached the limit of adding " + count + " inputs");
        }
        else{
            var newdiv = document.createElement('tr');
            var tabin="product_name_"+count;
             tabindex = count * 4 ,
           newdiv = document.createElement("tr");
            tab1 = tabindex + 1;
            
            tab2 = tabindex + 2;
            tab3 = tabindex + 3;
            tab4 = tabindex + 4;
            tab5 = tabindex + 5;
            tab6 = tab5 + 1;
            tab7 = tab6 +1;
            tab11 = tabindex +11;
            tab12 = tabindex +12;
            tab13 = tabindex +13;
            tab14 = tabindex +14;
           
				
			



    //newdiv.innerHTML ='<td class="span3 supplier"><button type="button" class="btn btn-primary modalinloop" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo">Description</button> </td> <td class="wt"><input type="text" name="width[]" class="form-control" placeholder="Width" value=""></td> <td class="span3 supplier"> <input type="text" name="length[]" class="form-control" placeholder="Length" value=""> </td> <td class="wt"> <input type="text" name="colors[]" class="form-control" placeholder="Color" value=""></td><td ><input type="text" name="umo[]" class="form-control" placeholder="UMO" value=""></td><td class="text-right"><input type="number" class="form-control" name="qty[]" placeholder="QTY" value="">   </td><td class="text-right"><input type="number" class="form-control" name="rate[]" placeholder="RATE" value=""></td><td> <input type="hidden" id="total_discount_1" class="" /><input type="hidden" id="all_discount_1" class="total_discount" /><button style="text-align: right;" class="btn btn-danger red" type="button"  onclick="deleteRow(this)" tabindex="8"><i class="fa fa-close"></i></button></td>';


newdiv.innerHTML ='<td class="wt"><?php echo  $product_catlog ?></td><td class="wt"><input type="text" name="lace_type[]" id="lacetype_'+count+'" class="form-control" placeholder="Lace Type"></td><td class="wt"><input type="text" name="material_type[]" class="form-control" id="materialtype_'+count+'" placeholder="Material Type"></td><td class="wt"><input type="text" name="no_of_colors[]" class="form-control" id="noofcolors_'+count+'" placeholder="No Of Colors"></td><td class="wt"><input type="text" name="width[]" class="form-control" placeholder="Width" value=""></td> <td class="span3 supplier"> <input type="text" name="length[]" class="form-control" placeholder="Length" value=""> </td> <td class="wt"> <input type="text" name="colors[]" class="form-control" placeholder="Color" value=""></td><td ><input type="text" name="umo[]" class="form-control" placeholder="UMO" value=""></td><td class="text-right"><input type="number" class="form-control" name="qty[]" placeholder="QTY" value="">   </td><td class="text-right"><input type="number" class="form-control" name="rate[]" placeholder="RATE" value=""></td><td> <input type="hidden" id="total_discount_1" class="" /><input type="hidden" id="all_discount_1" class="total_discount" /><button style="text-align: right;" class="btn btn-danger red" type="button"  onclick="deleteRow(this)" tabindex="8"><i class="fa fa-close"></i></button></td>';



 



            document.getElementById(divName).appendChild(newdiv);
            document.getElementById(tabin).focus();
            document.getElementById("add_invoice_item").setAttribute("tabindex", tab5);
            document.getElementById("add_purchase").setAttribute("tabindex", tab6); 
            count++;

            $("select.form-control:not(.dont-select-me)").select2({
                placeholder: "Select option",
                allowClear: true
            });
        }
    }

</script>
<script>

 //Delete row
        "use strict";
    function deleteRow(e) {
        var t = $("#purchaseTable > tbody > tr").length;
        if (1 == t) alert("There only one row you can't delete.");
        else {
            var a = e.parentNode.parentNode;
            a.parentNode.removeChild(a)
        }
        
        
       
    }

    function choosevalue(product_catalogue_id)
    {
        
        alert('-----------'+product_catalogue_id);
        
        

        $.ajax({
        type: "POST",
        url: "<?php echo base_url() ?>production/production/ajaxget_product_catalogue_details",
        data: { product_catalogue_id:product_catalogue_id},
      
          success: function(data){
             alert(data);
             //$(this).parent().find("input[name=lace_type[]]").val('123');
             alert($(this));
             
             console.log($(this));
             
            // $(this).closest("td.options").find("input[name='lace_type[]']").val('123');
             //$('.article-code').closest('.lacetype').val('123');
             $(this).closest('tr').find('.lacetype').val('tyty');
             //$(this).closest("tr").find("input[name='lace_type[]']").val('123');
          }
        });
     
    }
</script>