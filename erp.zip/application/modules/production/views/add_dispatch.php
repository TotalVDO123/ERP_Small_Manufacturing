 <div class="row">
     <div class="col-sm-12">
         <div class="panel panel-bd lobidrag">
             <div class="panel-heading">
                 <div class="panel-title">
                     <h4><?php echo $title ?> </h4>
                 </div>
             </div>

             <div class="panel-body">
                 <?php echo form_open('','class="" id="add_dispatch"')
				 ?>

                
                 <input type="hidden" name="sample_id" id="sampleid" class="form-control"  value="<?php echo $sample->sample_id ?>">
				 <input type="hidden" name="sample_po_no" class="form-control"   value="<?php echo $sample->sample_po_no ?>">
				 <input type="hidden" name="dispatch_id" class="form-control" id="dispatch_id"  value="">
				 
				 <div class="form-group row">
                     
					<label for="customer_email"
                         class="col-sm-4 text-right col-form-label">Material Description</label>
                     <div class="col-sm-4">
                         <div class="">

                            <select name="purchase_order_no" id="list_material_description"  class="form-control " required=""
                                    tabindex="1">
                                    <option value="">Select</option>
									<?php
									foreach($material_descriptions as $material_description  )
									{
									?>	
									<option value="<?php echo $material_description->material_description?>"><?php echo $material_description->material_description ?></option>
									<?php	
									}	
									?>
									
									
                                </select> 
                         </div>

                     </div>
                 </div>
				 
				 
				 <div class="form-group row">
                     
					<label for="customer_email"
                         class="col-sm-4 text-right col-form-label">Color</label>
                     <div class="col-sm-4">
                         <div class="">

                            <select name="brand_sample_id" id="brand_sample_id"  class="form-control " required=""
                                    tabindex="1">
                                    <option value="">Select</option>
									
									
                                </select> 
                         </div>

                     </div>
                 </div>
				 
				 
				 
				 
				 		
				  <div class="form-group row">
                     
					<label for="Shade No"
                         class="col-sm-4 text-right col-form-label">Shade No:</label>
                     <div class="col-sm-4">
                         <div class="">

                            
						<input type="text" name="shade_no" class="form-control" placeholder="Shade No" id="shade_no" value="">
                         </div>

                     </div>
                    
                 </div>
				 
				 
				 
				 
				 
				 <div class="form-group row">
                     
                     <label for="Challan No"
                         class="col-sm-4 text-right col-form-label">Challan No :</label>
                     <div class="col-sm-4">
                         <div class="">
						<input type="text" name="challan_no" class="form-control" placeholder="Challan No" id="challan_no" value="">
                         </div>

                     </div>
                 </div>
                 <div class="form-group row">
                     <label for="Dispatch Date"
                         class="col-sm-4 text-right col-form-label">Dispatch Date :</label>
					 
					 <div class="col-sm-4">
                         <div class="">
								 <?php $date = date('Y-m-d'); ?>
                                <input type="text" required tabindex="2" class="form-control datepicker"
                                    name="dispatch_date" value="<?php echo $date; ?>" id="dispatch_date" />

							
                         </div>

                     </div>
                    
                    
                 </div>
                
  			 
				 
				 
				 
              



                 <div class="form-group row">
                     <div class="col-sm-6 text-right">
                     </div>
                     <div class="col-sm-6 text-right">
                         <div class="">

                             <button type="submit" class="btn btn-success">
                                 <?php echo (empty($customer->customer_id)?display('save'):display('update')) ?></button>

                         </div>

                     </div>
                 </div>


                 <?php echo form_close();?>
             </div>

         </div>
     </div>
 </div>
 
 
 
 <script>
 
 
 
 

 
 $('#list_material_description').change(function(){
	
	 
	 
var sampleid=$('#sampleid').val();	 	 
	 
var material_description=$('#list_material_description').val();	 
 //alert(purchase_order_no);
 $.ajax({
  url: "<?php echo base_url()?>sampling/sampling/ajaxget_material_description_color/",
 type : 'POST',
  data: {
            material_description: material_description,sampleid:sampleid
        },
  success: function(html){
	
	
	  
	  //$('#list_color').append(html);
	 $('#brand_sample_id').html(html);
	  
    //$("#results").append(html);
  }
});
 
 });
 
 
 
 </script>
 <script>
$('#brand_sample_id').change(function(){
	
	 
var brand_sample_id=$('#brand_sample_id').val();	 
 //alert(purchase_order_no);
 $.ajax({
  url: "<?php echo base_url()?>sampling/sampling/ajaxget_dispatch/"+brand_sample_id,
 type : 'GET',
  success: function(html){
	  //alert(html);
	 var data = html.split("||");
	  //alert(data[0]);
	  
	  $('#dispatch_id').val(data[0]);
	  $('#shade_no').val(data[1]);
	  $('#dispatch_date').val(data[2]);
	  $('#challan_no').val(data[3]);
	  
    //$("#results").append(html);
  }
});
 
 });
 </script>