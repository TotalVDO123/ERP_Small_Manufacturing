 <div class="row">
     <div class="col-sm-12">
         <div class="panel panel-bd lobidrag">
             <div class="panel-heading">
                 <div class="panel-title">
                     <h4><?php echo $title ?> </h4>
                 </div>
             </div>

             <div class="panel-body">
                 <?php echo form_open('','class="" id="sample_form"')?>

                 <input type="hidden" name="sample_id" id="sample_id" value="<?php echo $sample->sample_id?>">
                 <div class="form-group row">
                     <label for="sample_po_no"
                         class="col-sm-2 text-right col-form-label">Sample P.O No <i
                             class="text-danger"> * </i>:</label>
                     <div class="col-sm-4">
                         <div class="">

                             <?php echo $sample_po_no ?>
						<input type="hidden" name="sample_po_no" id="sample_po_no" value="<?php echo $sample_po_no?>">
                         </div>

                     </div>
                     <label for="purchase_order_no"
                         class="col-sm-2 text-right col-form-label">Purchase Order No <i
                             class="text-danger"> </i>:</label>
                     <div class="col-sm-4">
                         <div class="">

                            <?php echo $purchase_order_no ?>
						<input type="hidden" name="purchase_order_no" id="purchase_order_no" value="<?php echo $purchase_order_no?>">
                         </div>

                     </div>
                 </div>
                 <div class="form-group row">
                     <label for="po_date"
                         class="col-sm-2 text-right col-form-label">P.O Date :</label>
                     
					 
					 
					 
					 
					 
					 <div class="col-sm-4">
                         <div class="">


								 <?php $date = date('Y-m-d'); ?>
                                <input type="text" required tabindex="2" class="form-control datepicker"
                                    name="po_date" value="<?php echo $date; ?>" id="date" />

							<?php /* ?>
                             <input type="text" class="form-control input-mask-trigger" name="customer_email" id="email"
                                 data-inputmask="'alias': 'email'" im-insert="true"
                                 placeholder="<?php echo display('email')?>"
                                 value="<?php echo $customer->customer_email?>">
							<?php */ ?>

                         </div>

                     </div>
                     <label for="s_no"
                         class="col-sm-2 text-right col-form-label">S No:</label>
                     <div class="col-sm-4">
                         <div class="">

                             <input type="text" class="form-control" name="s_no" id="s_no"
                                 placeholder="S No"
                                 value="<?php echo $sample->s_no?>">

                         </div>

                     </div>
                 </div>
                 <div class="form-group row">
                     <label for="client"
                         class="col-sm-2 text-right col-form-label">Client:</label>
                     <div class="col-sm-4">
                         <div class="">

                             <input class="form-control" id="phone" type="text"
                                 name="client" placeholder="client"
                                  value="<?php echo $sample->client?>">

                         </div>

                     </div>

                     <label for="model" class="col-sm-2 text-right col-form-label">Model:
                     </label>
                     <div class="col-sm-4">
                         <div class="">

                             <input class="form-control" id="model" type="text" name="model"
                                 placeholder="Model" value="<?php echo $sample->model?>">

                         </div>

                     </div>
                 </div>
                 
				  <div class="form-group row">
                     

                     <label for="season"
                         class="col-sm-2 text-right col-form-label">Season:</label>
                     <div class="col-sm-4">
                         <div class="">

                             <input class="form-control" id="season" type="text" name="season"
                                 placeholder="Season" value="<?php echo $sample->season?>">

                         </div>


                     </div>
					 
					 
					 <label for="material_description"
                         class="col-sm-2 text-right col-form-label">Material Description:</label>
                     <div class="col-sm-4">
                         <div class="">

                             <textarea name="material_description	" id="material_description	" class="form-control"
                                 placeholder="Material Description"><?php echo $sample->material_description	?></textarea>

                         </div>

                     </div>
                 </div>
				 
				 
				 
				 
				  <div class="form-group row">
                     
                     <label for="receiver_contact"
                         class="col-sm-2 text-right col-form-label">Receiver Contact <i
                             class="text-danger"> </i>:</label>
                     <div class="col-sm-4">
                         <div class="">

                             <input type="number" name="receiver_contact"
                                 class="form-control input-mask-trigger text-left" id="receiver_contact"
                                 placeholder="Receiver Contact"
                                 value="<?php echo $sample->receiver_contact?>"
                                 data-inputmask="'alias': 'decimal', 'groupSeparator': '', 'autoGroup': true"
                                 im-insert="true">

                         </div>

                     </div>
					 
					 
					 
					 <label for="customer_name"
                         class="col-sm-2 text-right col-form-label">Color <i
                             class="text-danger"> * </i>:</label>
                     <div class="col-sm-4">
                         <div class="">

                             <input type="color" name="colors" class="form-control" id="colors"
                                 placeholder="Color"
                                 value="<?php echo $sample->colors?>">
                           

                         </div>

                     </div>
					 
					 
					 
                 </div>
				 
				 
				   <div class="form-group row">
                     <label for="customer_email"
                         class="col-sm-2 text-right col-form-label">Email:</label>
                     <div class="col-sm-4">
                         <div class="">

                             <input type="text" class="form-control input-mask-trigger" name="receiver_emial" id="receiver_emial"
                                 data-inputmask="'alias': 'email'" im-insert="true"
                                 placeholder="Email"
                                 value="<?php echo $sample->receiver_emial?>">

                         </div>

                     </div>
                     <label for="email_address"
                         class="col-sm-2 text-right col-form-label">UOM:</label>
                     <div class="col-sm-4">
                         <div class="">

                             <input type="text" class="form-control" name="uom" id="uom"
                                 placeholder="UOM"
                                 value="<?php echo $sample->uom?>">

                         </div>

                     </div>
                 </div>
				 
				  
				
				 
				 
				 
				 
				 
				 
				 
				 <div class="form-group row">
                     
					<label for="customer_email"
                         class="col-sm-2 text-right col-form-label"></label>
                     <div class="col-sm-4">
                         <div class="">

                            

                         </div>

                     </div>
					 
					 
					 
                   

                     <label for="Order Date"
                         class="col-sm-2 text-right col-form-label">Order Date:</label>
                     <div class="col-sm-4">
                         <div class="">

                            <?php $date = date('Y-m-d'); ?>
                                <input type="text" required tabindex="2" class="form-control datepicker"
                                    name="order_date" value="<?php echo $date; ?>" id="order_date" />

                         </div>

                     </div>
                 </div>
				 
				 <div class="form-group row">
                     
					<label for="customer_email"
                         class="col-sm-2 text-right col-form-label"></label>
                     <div class="col-sm-4">
                         <div class="">

                            

                         </div>

                     </div>
					 
					 
					 
                   

                     <label for="Order Date"
                         class="col-sm-2 text-right col-form-label">QTY:</label>
                     <div class="col-sm-4">
                         <div class="">

                              <input type="number" class="form-control" name="qty" id="qty"
                                 placeholder="QTY"
                                 value="<?php echo $sample->qty?>">

                         </div>

                     </div>
                 </div>
				 
				 
				  <div class="form-group row">
                     
					<label for="customer_email"
                         class="col-sm-2 text-right col-form-label"></label>
                     <div class="col-sm-4">
                         <div class="">

                            

                         </div>

                     </div>
					 
					 
					 
                   

                     <label for="Order Date"
                         class="col-sm-2 text-right col-form-label">QTY:</label>
                     <div class="col-sm-4">
                         <div class="">

                              <select name="status" id="status" class="form-control " required=""
                                    tabindex="1">
                                    <option value="0">Pending</option>
									<option value="1">Approved</option>
                                  
                                  
                                </select>

                         </div>

                     </div>
                 </div>
				 
				 
				 
				 
				 
				 
				 
				 
				 
				 
				 
				 
				 
				
				 
				 
				 
				 
              



                 <div class="form-group row">
                     <div class="col-sm-6 text-right">
                     </div>
                     <div class="col-sm-6 text-right">
                         <div class="">

                             <button type="button" onclick="customer_form()" class="btn btn-success">
                                 <?php echo (empty($customer->customer_id)?display('save'):display('update')) ?></button>

                         </div>

                     </div>
                 </div>


                 <?php echo form_close();?>
             </div>

         </div>
     </div>
 </div>