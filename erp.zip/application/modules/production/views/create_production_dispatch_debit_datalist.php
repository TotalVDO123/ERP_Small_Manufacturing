  <div class="row">
           
			<div class="col-sm-12">
                <div class="panel panel-default">
                    <div class="panel-body"> 
                        <?php echo form_open('create_production_dispatch_debit', array('method'=>'get')) ?>
                        <?php $today = date('Y-m-d'); ?>
                        

				<div class="row">
                    <div class="col-sm-4">
                        <div class="form-group row">
                            <label for="supplier_sss" class="col-sm-4 col-form-label">Invoice No
                            
                            </label>
                            <div class="col-sm-6">
                             
                                    <select name="production_dispatch_id" id="production_dispatch_id" class="form-control " tabindex="1">
                                    <option value="">Select</option>
									
									<?php
									foreach($production_dispatch_lists as $production_dispatch_list )
									{
									?>
									    <option value="<?php echo $production_dispatch_list['production_dispatch_id'] ?>" <?php if($production_dispatch_list['production_dispatch_id']==$production_dispatch_id){ echo 'selected'; } ?> ><?php echo $production_dispatch_list['invoice_no'] ?></option>
									<?php
									}
									
									?>
								</select>
							</div>
                        </div>
                    </div>
<!----------------------------------------------->

                        <div class="col-sm-4">
                        <div class="form-group row">
                            <label for="supplier_sss" class="col-sm-4 col-form-label">P.O No
                            
                            </label>
                            <div class="col-sm-6">
                             
                                   <select name="production_id" id="production_id" class="form-control " tabindex="1">
                                    <option value="">Select</option>
									
									<?php
									foreach($production_lists as $production_list )
									{
									?>
									<option value="<?php echo $production_list['production_id'] ?>" <?php if($production_list['production_id']==$production_id){ echo 'selected'; } ?> ><?php echo $production_list['purchase_order_no'] ?></option>
									<?php
									}
									
									?>
								</select>
							</div>
                        </div>
                        
                    </div>
                <!----------------------------------------------------->
                </div>

                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                   
                        
                        <div class="row">
                       	<div class="col-sm-4">
				 <div class="form-group row">
                            <label for="customer_name" class="col-sm-4 col-form-label">Client list </label>
                            <div class="col-sm-6">
                                  
								  <select name="client_id" id="client_id" class="form-control "
                                    tabindex="1">
                                    <option value="">Select</option>
									
									<?php
									foreach($clients as $client )
									{
									?>
									<option value="<?php echo $client->id ?>" <?php if($client->id==$client_id){ echo 'selected'; } ?>  ><?php echo $client->client_name ?></option>
									<?php
									}
									?>
								</select>
                            </div>
                            </div>
				</div>
                       
                      	<div class="col-sm-4">
				 <div class="form-group row">
							<label for="from_date " class="col-sm-4 col-form-label"> Brand List</label>
                        <div class="col-sm-6">
							
                             <select name="brand_id" id="brand_id" class="form-control " 
                                    tabindex="1">
                                    <option value="">Select</option>
									
									<?php
									foreach($brands as $brand )
									{
									?>
									<option value="<?php echo $brand->id ?>" <?php if($brand->id==$brand_id){ echo 'selected'; } ?> ><?php echo $brand->brand_name ?></option>
									<?php
									}
									?>
								</select>
						</div>
					    
				

						
                            </div>
				</div>
                           

                </div>
				
               


                 <div class="row">
                       	<div class="col-sm-9"></div>

				
					    <div class="col-sm-3">
                                <button type="submit" class="btn btn-success "><i class="fa fa-search-plus" aria-hidden="true"></i> <?php echo display('search') ?></button>
                                
                                <?php /* ?>
                                <button type="button" class="btn btn-warning"  onclick="printDiv('printableArea')"><?php echo display('print') ?></button>
								<button type="submit" id="export_csv" name="csv" value="1" class="btn btn-success "><i class="fa fa-search-plus" aria-hidden="true"></i> CSV</button>
								<?php */ ?>
								
					    </div>	
                </div>
			
			
				
                        <?php echo form_close() ?>
                    </div>
						
                </div>
            </div>
        </div>

        <!-- customer ledger -->
        <div class="row">
		
	
		
            <div class="col-sm-12">
                
            	<?php echo form_open('creatarray_production_dispatch_debit', array('class' => '', 'id' => 'validate')) ?>    
             <!-------------------------------------->   
                 <input type="hidden" name="production_dispatch_id" size="4" class="fixedqty" value="<?php echo $production_dispatch_id ?>">
                 <div class="row">
           
			<div class="col-sm-12">
                <div class="panel panel-default">
                    <div class="panel-body"> 
                       
				<div class="row">
                    <div class="col-sm-4">
                        <div class="form-group row">
                            <label for="debit_no" class="col-sm-4 col-form-label">Debit No
                            </label>
                            <div class="col-sm-6">
						    <input type="text" name="debit_no"  class="form-control" value="" required	>	
							</div>
                        </div>
                    </div>






			    <div class="col-sm-5">
				 <div class="form-group row">
						<label for="dabit_date" class="col-sm-3 col-form-label"> Debit Date </label>
                        <div class="col-sm-4">
                              <?php 
								$date = date('Y-m-d');
								?>
                                <input type="text" required tabindex="2" class="form-control datepicker"
                                    name="dabit_date" value="<?php echo $date; ?>" id="dabit_date" />
						</div>
                            </div>
				</div>
							
				 <div class="col-sm-3">
				    <div class="form-group row">
					 <button type="submit" name="ctrate_debit" class="btn btn-success "></i> create Debit</button>	
                    </div>
				</div>			




                  
                </div>

  
                    </div>
						
                </div>
            </div>
        </div>
         
                
                
                
                
            <!--------------------------------------------------->    
                <div class="panel panel-bd lobidrag">
                  
                    <div class="panel-body">
                        <div id="printableArea">
							<?php /*  ?>
                            <?php if ($customer_name) { ?>
                                <div class="text-center">
                                    <h3> <?php echo $customer_name;?> </h3>
                                    <h4><?php echo display('address') ?> : <?php echo $address?> </h4>
                                    <h4> <?php echo display('print_date') ?>: <?php echo date("d/m/Y h:i:s"); ?> </h4>
                                </div>
                            <?php } ?>
							<?php */  ?>
                            <div class="table-responsive">

                                <table class="table table-bordered table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th class="text-right">Article Code</th>
                                            <th class="text-right">Lace Type</th>
                                            <th class="text-center">Material Type</th>
											<th class="text-center">No Of Colors</th>
                                            <th class="text-right">Width</th>
                                            <th class="text-right">Length</th>
                                            <th class="text-center">Color</th>
                                            <th class="text-center">UOM</th>
											
											<th class="text-center">Actual Qty</th>
											<th class="text-center">Dispatch Qty</th>
											<th class="text-center">Remaining Qty</th>
											<!--<th class="text-center">QTY</th> -->
											<th class="text-center">Debit Qty</th>
                                            <th class="text-right">Action</th>
                                        </tr>
                                    </thead>
								
                                    <tbody>
                                        <?php
                                        if ($productiondispatch_listdata) {
                                           
                                            foreach ($productiondispatch_listdata as $row) 
                                            {
										        $this->db->select('SUM(qty) AS tot_dqty');
                                                $this->db->from('tov_production_dispatch_info');
                                                $this->db->where('production_information_id',$row['production_information_id']);
                                                
                                                $this->db->group_by('production_information_id');
                                                $query = $this->db->get();
                                                $result=$query->result_array();
                                                
                                                
                                                ///$remainig_qty= intval($row['qty'])-intval($result[0]['tot_dqty'])
                                                
                                                $remainig_qty= intval($row['qty'])-intval($row['d_qty'])+intval($row['debit_qty'])
                                                
                                                ?>
											 	
                                                <tr >
                                                    
                                                    <td class="text-center" >
                                                        <?php echo  $row['article_code']  ?>
                                                    </td>
                                                    
                                                    <td class="text-center">
                                                        <?php echo  $row['lace_type']  ?>
                                                    </td>
                                                    
        										    
        										    <td class="text-center">
        										        <?php echo  $row['material_type']  ?>
        										    </td> 
												    
												    <td>
                                                        <?php echo  $row['no_of_colors']  ?>
                                                    </td>  
												    <td >
                                                        <?php echo  $row['width']  ?>
                                                    </td>
                                                    
                                                    <td >
                                                        <?php echo  $row['length']  ?>
                                                    </td>
                                                    
                                                    
                                                 <td class="text-center">
                                                     <?php echo  $row['color']  ?>
                                                     
                                                     </td>    
                                                
												
												<td class="text-center">
												<?php echo  $row['uom']  ?>
												
												</td>      
                                                
                                                
                                                <td class="text-center">
											        <input type="hidden" size="4" name="actual_qty_<?php echo $row['production_dispatch_info_id'] ?>"   value="<?php echo  $row['qty']  ?>" readonly	>
												<?php echo  $row['qty']  ?>
												
												</td>
                                              
                                              
                                                 <td class="text-center">
											     
												<?php echo  $row['d_qty']  ?>
												
												</td>
                                              
                                                
                                                <td class="text-center">
											     
												<?php echo  $remainig_qty  ?>
												<input type="hidden" name="d_qty_<?php echo $row['production_dispatch_info_id'] ?>"  value="<?php echo $row['d_qty'] ?>"	>
												</td>
                                                
                                                <?php /* ?>
                                                <td class="text-center">
												 
												 <input type="text" name="d_qty_<?php echo $row['production_dispatch_info_id'] ?>" size="4" class="qty" value="<?php echo $row['d_qty'] ?>"	>
												 
												  
												 </td>
												 <?php */ ?>
												 
																								 
												 
												 <td class="text-center">
											        <input type="text" size="4" name="debit_qry_<?php echo $row['production_dispatch_info_id'] ?>"  value="<?php echo $row['debit_qty'] ?>"	>
												</td>	
												 
												 
												 
												  <td >
                                                         <center>
                                                
                                               <input type="checkbox" name="production_dispatch_info_id[]" value="<?php echo $row['production_dispatch_info_id'] ?>">
                                        
                                          
                                    </center>
                                                    </td>
                                                </tr>
									
                                                <?php
                                            }
                                        }else{
                                        ?>
                                        <tr><td colspan="6"><center>No Record Found</center></td></tr>
                                        
                                        <?php }?>
                                    
                                    </tbody>
									
											
										 <div class="col-sm-3">
										 
										 
										 
										 
                              <!--  <button type="submit" class="btn btn-success "> create Dispatch</button> -->
                             
								
								
								
								</div>	
									
											
											
                                    
                                </table>
                                
                            </div>

                        </div>
                        <div class="text-right"><?php echo $links ?></div>
                    </div>
                </div>
                 <?php echo form_close() ?>	
                
            </div>
        </div>
        
        
        
        
        <div class="modal fade modalinloop" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">New message</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      
        
        
        
        
        <div class="panel-body" id="head_info">
                
				
				
			
		
              
                

                
            </div>
            
      
      
      
      
      
      
      
      
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
       <!-- <button type="button" class="btn btn-primary">Send message</button>-->
      </div>
    </div>
  </div>
</div>


<script>
$('.modalinloop').on('show.bs.modal', function (event) {
  
   var brand_sample_id=$(event.relatedTarget).data('id');
  
  
  var button = $(event.relatedTarget) // Button that triggered the modal
  var recipient = button.data('whatever') // Extract info from data-* attributes
  // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
  // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.

  
  
  
  $.ajax({
  url: "<?php echo base_url()?>sampling/sampling/ajaxget_sampling_data/",
 type : 'POST',
  data: {
            brand_sample_id: brand_sample_id
        },
  success: function(data){
	
	//alert(data);
	  
	  //$('#list_color').append(html);
	 $('#head_info').html(data);
	  
    //$("#results").append(html);
  }
});
  
  
  
  var modal = $(this)
  modal.find('.modal-title').text('New message to1111 ' + recipient)
  modal.find('.modal-body input').val(recipient)
})

</script>


<script>

$(function () {
	
	alert('----------');
$('#export_csv111').on('click', function () {
	
	alert('----------');
//var myusername = $("#username").val();
$.ajax({
  type: "GET",
  url: "http://localhost/workshree_erp/export_data",
  data: myusername:'',
  
  success: function(data){
     //$("#resultarea").text(data);
	 
	 alert(data);
  }
});
 });
});


</script>

<script>

$(document).ready(function(){
  $(".toggle-btn").click(function(){
	  
	  /*
	  if ($('.toggle-input').is(':visible')) {
    
	$('.dispatch_date').val('');
	
	$(".toggle-input").hide();
} else {
    //alert('The input is hidden');
	$(".toggle-input").show();
}
	*/  
	  
	  
    // Find the input element in the same row and toggle its visibility
    $(this).closest('tr').find('.toggle-input').toggle();
	//$(this).closest('tr').find('.toggle-input').show();  // To show the input
	 
  });
});
</script>
<script>
    
    $(document).ready(function() {
    // Example usage with a button click event
    $('.qty111').focusout(function() {
       
        
        var fixed_qty=parseInt( $(this).closest('tr').find('.fixedqty').val());
        var inputValue =parseInt( $(this).closest('tr').find('.remaining_qty').val());
        
        var quantity=parseInt($(this).val());
        
        var finalvalue=(fixed_qty-quantity);
        
        //alert('-----------'+inputValue );
        //alert('-----------'+(inputValue-quantity)) ;
        if(finalvalue>=0)
        {
        
        $(this).closest('tr').find('.remaining_qty').val(finalvalue);
        }
        else
        {
            alert('You have entered an invalid quantity value');
            $(this).closest('tr').find('.remaining_qty').val(finalvalue);
            //$(this).closest('tr').find('.remaining_qty').val(fixed_qty);
            //$(this).val(0);
        }
        
        //alert('-----------'+$(this).val() );
        
       
        
       
        //console.log(inputValue); // This will log the value of the input
    });
});
    
    
</script>
