<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 #------------------------------------    
    # Author: Bdtask Ltd
    # Author link: https://www.bdtask.com/
    # Dynamic style php file
    # Developed by :Isahaq
    #------------------------------------    

class Production_model extends CI_Model {

     
   public function create($data = array())
	{
		$add_production =  $this->db->insert('tov_production', $data);

		$production_id = $this->db->insert_id();
      
  
        return $production_id;
	}
	
	public function create_production_dispatch($data = array())
	{
	        $this->db->insert('tov_production_dispatch', $data);
		    $id = $this->db->insert_id();
            return $id;
	}
	
	
	public function create_production_dispatch_debit($data = array())
	{
	        $this->db->insert('tov_production_dispatch_debit', $data);
		    $id = $this->db->insert_id();
            return $id;
	}
	
	
	public function create_production_information_dispatch($data = array())
	{
	        $this->db->insert('tov_production_dispatch_info', $data);
		    $id = $this->db->insert_id();
            return $id;
	}
	
		public function create_production_information_dispatch_debit($data = array())
	{
	        $this->db->insert('tov_production_dispatch_debit_info', $data);
		    $id = $this->db->insert_id();
            return $id;
	}
	
	
	public function create_production_information($data = array(),$sample_id=NULL)
	{
		
		$add_production_information =  $this->db->insert('tov_production_information', $data);

		 $production_information_id= $this->db->insert_id();
      
  
        return $production_information_id;
	}
	
	
	
	public function update_production_information($data = array())
	{
		
		
		$update =  $this->db->where('production_information_id', $data["production_information_id"])
			->update("tov_production_information", $data);
      return true;
	}
	
	
	
	public function update_product_catalogue($data = array())
	{
		
		
		$update =  $this->db->where('product_catalogue_id', $data["product_catalogue_id"])
			->update("tov_product_catalogue", $data);
      return true;
	}
	
	
	
	
	public function create_product_catalogue($data = array())
	{
		$add_product_catalogue =  $this->db->insert('tov_product_catalogue', $data);
		 $product_catalogue_id= $this->db->insert_id();
        return $production_information_id;
	}
	

	public function customer_dropdown()
	{
		$data =  $this->db->select("*")
			->from('customer_information')
			->order_by('customer_name', 'asc')
			->get()
			->result();

      $list[''] = display('select_option');
    if (!empty($data)) {
      foreach($data as $value)
        $list[$value->customer_id] = $value->customer_name;
      return $list;
    } else {
      return false; 
    }
	}

  //credit customer dropdown
    public function bdtask_credit_customer_dropdown()
  {
    $data =  $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode`)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode`)) as balance")
      ->from('customer_information a')
      ->join('acc_coa b','a.customer_id = b.customer_id','left')
      ->having('balance > 0')
      ->group_by('a.customer_id')
      ->order_by('a.customer_name', 'asc')
      ->get()
      ->result();

      $list[''] = display('select_option');
    if (!empty($data)) {
      foreach($data as $value)
        $list[$value->customer_id] = $value->customer_name;
      return $list;
    } else {
      return false; 
    }
  }


  // paid customer dropdown
   public function bdtask_paid_customer_dropdown()
  {
    $data =  $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode`)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode`)) as balance")
      ->from('customer_information a')
      ->join('acc_coa b','a.customer_id = b.customer_id','left')
      ->having('balance <= 0')
      ->group_by('a.customer_id')
      ->order_by('a.customer_name', 'asc')
      ->get()
      ->result();

      $list[''] = display('select_option');
    if (!empty($data)) {
      foreach($data as $value)
        $list[$value->customer_id] = $value->customer_name;
      return $list;
    } else {
      return false; 
    }
  }

	public function customer_list($offset=null, $limit=null)
    {
  

        return $result = $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode`)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode`)) as balance")
			->from('customer_information a')
			->join('acc_coa b','a.customer_id = b.customer_id','left')
			->group_by('a.customer_id')
			->order_by('a.customer_name', 'asc')
			->limit($offset, $limit)
			->get()
			->result();

         
    }


      public function getCustomerList($postData=null){

         $response = array();
         $customer_id =  $this->input->post('customer_id');
         $custom_data = $this->input->post('customfiled');
         if(!empty($custom_data)){
         $cus_data = [''];
         foreach ($custom_data as $cusd) {
           $cus_data[] = $cusd;
         }
       }
    
         ## Read value
         $draw = $postData['draw'];
         $start = $postData['start'];
         $rowperpage = $postData['length']; // Rows display per page
         $columnIndex = $postData['order'][0]['column']; // Column index
         $columnName = $postData['columns'][$columnIndex]['data']; // Column name
         $columnSortOrder = $postData['order'][0]['dir']; // asc or desc
         $searchValue = $postData['search']['value']; // Search value

         ## Search 
         $searchQuery = "";
         if($searchValue != ''){
            $searchQuery = " (a.customer_name like '%".$searchValue."%' or a.customer_mobile like '%".$searchValue."%' or a.customer_email like '%".$searchValue."%'or a.phone like '%".$searchValue."%' or a.customer_address like '%".$searchValue."%' or a.country like '%".$searchValue."%' or a.state like '%".$searchValue."%' or a.zip like '%".$searchValue."%' or a.city like '%".$searchValue."%') ";
         }

         ## Total number of records without filtering
         $this->db->select('count(*) as allcount');
         $this->db->from('customer_information a');
         $this->db->join('acc_coa b','a.customer_id = b.customer_id','left');
         
         if(!empty($customer_id)){
             $this->db->where('a.customer_id',$customer_id);
         }
         if(!empty($custom_data)){
             $this->db->where_in('a.customer_id',$cus_data);
         }
          if($searchValue != '')
         $this->db->where($searchQuery);
         $this->db->group_by('a.customer_id');
         $totalRecords =$this->db->get()->num_rows();

         ## Total number of record with filtering
         $this->db->select('count(*) as allcount');
         $this->db->from('customer_information a');
         $this->db->join('acc_coa b','a.customer_id = b.customer_id','left');
         if(!empty($customer_id)){
             $this->db->where('a.customer_id',$customer_id);
         }
          if(!empty($custom_data)){
             $this->db->where_in('a.customer_id',$cus_data);
         }
         if($searchValue != '')
            $this->db->where($searchQuery);
           $this->db->group_by('a.customer_id');
         $totalRecordwithFilter = $this->db->get()->num_rows();

         ## Fetch records
         $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction  where subCode= `s`.`id` AND subType = 3)-(select ifnull(sum(Credit),0) from acc_transaction where subCode= `s`.`id` AND subType = 3)) as balance");
         $this->db->from('customer_information a');
         
         $this->db->join('acc_coa b','a.customer_id = b.customer_id','left');
         $this->db->join('acc_subcode s','a.customer_id = s.referenceNo','left');
         $this->db->where('s.subTypeId',3);

         $this->db->group_by('a.customer_id');
          if(!empty($customer_id)){
             $this->db->where('a.customer_id',$customer_id);
         }
          if(!empty($custom_data)){
             $this->db->where_in('a.customer_id',$cus_data);
         }
         if($searchValue != '')
         $this->db->where($searchQuery);
         $this->db->order_by($columnName, $columnSortOrder);
         $this->db->limit($rowperpage, $start);
         $records = $this->db->get()->result();
         $data = array();
         $sl =1;
  
         foreach($records as $record ){
          $button = '';
          $base_url = base_url();
 
    if($this->permission1->method('manage_customer','update')->access()){
      $button .=' <a href="'.$base_url.'edit_customer/'.$record->customer_id.'" class="btn btn-info btn-xs m-b-5 custom_btn" data-toggle="tooltip" data-placement="left" title="Update"><i class="pe-7s-note" aria-hidden="true"></i></a>';
    }
    if($this->permission1->method('manage_customer','delete')->access()){
      $button .=' <a onclick="customerdelete('.$record->customer_id.')" href="javascript:void(0)"  class="btn btn-danger btn-xs m-b-5 custom_btn" data-toggle="tooltip" data-placement="right" title="Delete "><i class="pe-7s-trash" aria-hidden="true"></i></a>';
    }


        
               
            $data[] = array( 
                'sl'               =>$sl,
                'customer_name'    =>$record->customer_name,
                'address'          =>$record->customer_address,
                'address2'         =>$record->address2,
                'mobile'           =>$record->customer_mobile,
                'phone'            =>$record->phone,
                'email'            =>$record->customer_email,
                'email_address'    =>$record->email_address,
                'contact'          =>$record->contact,
                'fax'              =>$record->fax,
                'city'             =>$record->email_address,
                'state'            =>$record->contact,
                'zip'              =>$record->zip,
                'country'          =>$record->country,
                'balance'          =>(!empty($record->balance)?$record->balance:0),
                'button'           =>$button,
                
            ); 
            $sl++;
         }

         ## Response
         $response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalRecordwithFilter,
            "iTotalDisplayRecords" => $totalRecords,
            "aaData" => $data
         );

         return $response; 
    }



          public function getCreditCustomerList($postData=null){

         $response = array();
         $customer_id =  $this->input->post('customer_id');
         $custom_data = $this->input->post('customfiled');
         if(!empty($custom_data)){
         $cus_data = [''];
         foreach ($custom_data as $cusd) {
           $cus_data[] = $cusd;
         }
       }
    
         ## Read value
         $draw = $postData['draw'];
         $start = $postData['start'];
         $rowperpage = $postData['length']; // Rows display per page
         $columnIndex = $postData['order'][0]['column']; // Column index
         $columnName = $postData['columns'][$columnIndex]['data']; // Column name
         $columnSortOrder = $postData['order'][0]['dir']; // asc or desc
         $searchValue = $postData['search']['value']; // Search value

         ## Search 
         $searchQuery = "";
         if($searchValue != ''){
            $searchQuery = " (a.customer_name like '%".$searchValue."%' or a.customer_mobile like '%".$searchValue."%' or a.customer_email like '%".$searchValue."%'or a.phone like '%".$searchValue."%' or a.customer_address like '%".$searchValue."%' or a.country like '%".$searchValue."%' or a.state like '%".$searchValue."%' or a.zip like '%".$searchValue."%' or a.city like '%".$searchValue."%') ";
         }

         ## Total number of records without filtering
         $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)) as balance");
         $this->db->from('customer_information a');
         $this->db->join('acc_coa b','a.customer_id = b.customer_id','left');
         
         if(!empty($customer_id)){
             $this->db->where('a.customer_id',$customer_id);
         }
         if(!empty($custom_data)){
             $this->db->where_in('a.customer_id',$cus_data);
         }
          if($searchValue != '')
         $this->db->where($searchQuery);
         $this->db->having('balance > 0'); 
         $this->db->group_by('a.customer_id');
         $totalRecords =$this->db->get()->num_rows();

         ## Total number of record with filtering
         $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)) as balance");
         $this->db->from('customer_information a');
         $this->db->join('acc_coa b','a.customer_id = b.customer_id','left');
         if(!empty($customer_id)){
             $this->db->where('a.customer_id',$customer_id);
         }
          if(!empty($custom_data)){
             $this->db->where_in('a.customer_id',$cus_data);
         }
         if($searchValue != '')
            $this->db->where($searchQuery);
           $this->db->having('balance > 0');
           $this->db->group_by('a.customer_id');
         $totalRecordwithFilter = $this->db->get()->num_rows();

         ## Fetch records
         $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)) as balance");
         $this->db->from('customer_information a');
         $this->db->join('acc_coa b','a.customer_id = b.customer_id','left');
         $this->db->group_by('a.customer_id');
          if(!empty($customer_id)){
             $this->db->where('a.customer_id',$customer_id);
         }
          if(!empty($custom_data)){
             $this->db->where_in('a.customer_id',$cus_data);
         }
         if($searchValue != '')
         $this->db->where($searchQuery);
         $this->db->having('balance > 0');
         $this->db->order_by($columnName, $columnSortOrder);
         $this->db->limit($rowperpage, $start);
         $records = $this->db->get()->result();
         $data = array();
         $sl =1;
  
         foreach($records as $record ){
          $button = '';
          $base_url = base_url();
 
          if($this->permission1->method('credit_customer','update')->access()){
            $button .=' <a href="'.$base_url.'edit_customer/'.$record->customer_id.'" class="btn btn-info btn-xs m-b-5 custom_btn" data-toggle="tooltip" data-placement="left" title="Update"><i class="pe-7s-note" aria-hidden="true"></i></a>';
          }
          if($this->permission1->method('credit_customer','dalete')->access()){
            $button .=' <a onclick="customerdelete('.$record->customer_id.')" href="javascript:void(0)"  class="btn btn-danger btn-xs m-b-5 custom_btn" data-toggle="tooltip" data-placement="right" title="Delete "><i class="pe-7s-trash" aria-hidden="true"></i></a>';
          }


        
               
            $data[] = array( 
                'sl'               =>$sl,
                'customer_name'    =>$record->customer_name,
                'address'          =>$record->customer_address,
                'address2'         =>$record->address2,
                'mobile'           =>$record->customer_mobile,
                'phone'            =>$record->phone,
                'email'            =>$record->customer_email,
                'email_address'    =>$record->email_address,
                'contact'          =>$record->contact,
                'fax'              =>$record->fax,
                'city'             =>$record->city,
                'state'            =>$record->state,
                'zip'              =>$record->zip,
                'country'          =>$record->country,
                'balance'          =>(!empty($record->balance)?$record->balance:0),
                'button'           =>$button,
                
            ); 
            $sl++;
         }

         ## Response
         $response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalRecordwithFilter,
            "iTotalDisplayRecords" => $totalRecords,
            "aaData" => $data
         );

         return $response; 
    }

    //paid customer list
     public function bdtask_getPaidCustomerList($postData=null){

         $response = array();
         $customer_id =  $this->input->post('customer_id');
         $custom_data = $this->input->post('customfiled');
         if(!empty($custom_data)){
         $cus_data = [''];
         foreach ($custom_data as $cusd) {
           $cus_data[] = $cusd;
         }
       }
    
         ## Read value
         $draw = $postData['draw'];
         $start = $postData['start'];
         $rowperpage = $postData['length']; // Rows display per page
         $columnIndex = $postData['order'][0]['column']; // Column index
         $columnName = $postData['columns'][$columnIndex]['data']; // Column name
         $columnSortOrder = $postData['order'][0]['dir']; // asc or desc
         $searchValue = $postData['search']['value']; // Search value

         ## Search 
         $searchQuery = "";
         if($searchValue != ''){
            $searchQuery = " (a.customer_name like '%".$searchValue."%' or a.customer_mobile like '%".$searchValue."%' or a.customer_email like '%".$searchValue."%'or a.phone like '%".$searchValue."%' or a.customer_address like '%".$searchValue."%' or a.country like '%".$searchValue."%' or a.state like '%".$searchValue."%' or a.zip like '%".$searchValue."%' or a.city like '%".$searchValue."%') ";
         }

         ## Total number of records without filtering
         $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)) as balance");
         $this->db->from('customer_information a');
         $this->db->join('acc_coa b','a.customer_id = b.customer_id','left');
         
         if(!empty($customer_id)){
             $this->db->where('a.customer_id',$customer_id);
         }
         if(!empty($custom_data)){
             $this->db->where_in('a.customer_id',$cus_data);
         }
          if($searchValue != '')
         $this->db->where($searchQuery);
         $this->db->having('balance <= 0'); 
         $this->db->group_by('a.customer_id');
         $totalRecords =$this->db->get()->num_rows();

         ## Total number of record with filtering
         $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)) as balance");
         $this->db->from('customer_information a');
         $this->db->join('acc_coa b','a.customer_id = b.customer_id','left');
         if(!empty($customer_id)){
             $this->db->where('a.customer_id',$customer_id);
         }
          if(!empty($custom_data)){
             $this->db->where_in('a.customer_id',$cus_data);
         }
         if($searchValue != '')
            $this->db->where($searchQuery);
           $this->db->having('balance <= 0');
           $this->db->group_by('a.customer_id');
         $totalRecordwithFilter = $this->db->get()->num_rows();

         ## Fetch records
         $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode` AND IsAppove = 1)) as balance");
         $this->db->from('customer_information a');
         $this->db->join('acc_coa b','a.customer_id = b.customer_id','left');
         $this->db->group_by('a.customer_id');
          if(!empty($customer_id)){
             $this->db->where('a.customer_id',$customer_id);
         }
          if(!empty($custom_data)){
             $this->db->where_in('a.customer_id',$cus_data);
         }
         if($searchValue != '')
         $this->db->where($searchQuery);
         $this->db->having('balance <= 0');
         $this->db->order_by($columnName, $columnSortOrder);
         $this->db->limit($rowperpage, $start);
         $this->db->group_by('a.customer_id');
         $records = $this->db->get()->result();
         $data = array();
         $sl =1;
  
         foreach($records as $record ){
          $button = '';
          $base_url = base_url();
 
          if($this->permission1->method('paid_customer','update')->access()){
            $button .=' <a href="'.$base_url.'edit_customer/'.$record->customer_id.'" class="btn btn-info btn-xs m-b-5 custom_btn" data-toggle="tooltip" data-placement="left" title="Update"><i class="pe-7s-note" aria-hidden="true"></i></a>';
          }
          if($this->permission1->method('paid_customer','delete')->access()){
            $button .=' <a onclick="customerdelete('.$record->customer_id.')" href="javascript:void(0)"  class="btn btn-danger btn-xs m-b-5 custom_btn" data-toggle="tooltip" data-placement="right" title="Delete "><i class="pe-7s-trash" aria-hidden="true"></i></a>';
          }


        
               
            $data[] = array( 
                'sl'               =>$sl,
                'customer_name'    =>$record->customer_name,
                'address'          =>$record->customer_address,
                'address2'         =>$record->address2,
                'mobile'           =>$record->customer_mobile,
                'phone'            =>$record->phone,
                'email'            =>$record->customer_email,
                'email_address'    =>$record->email_address,
                'contact'          =>$record->contact,
                'fax'              =>$record->fax,
                'city'             =>$record->city,
                'state'            =>$record->state,
                'zip'              =>$record->zip,
                'country'          =>$record->country,
                'balance'          =>(!empty($record->balance)?$record->balance:0),
                'button'           =>$button,
                
            ); 
            $sl++;
         }

         ## Response
         $response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalRecordwithFilter,
            "iTotalDisplayRecords" => $totalRecords,
            "aaData" => $data
         );

         return $response; 
    }

    public function individual_info($id){
      return $result = $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode`)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode`)) as balance")
      ->from('customer_information a')
      ->join('acc_coa b','a.customer_id = b.customer_id','left')
      ->where('a.customer_id',$id)
      ->group_by('a.customer_id')
      ->order_by('a.customer_name', 'asc')
      ->get()
      ->result();
    }

    public function credit_customer($offset=null, $limit=null)
    {
  

        return $result = $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode`)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode`)) as balance")
			->from('customer_information a')
			->join('acc_coa b','a.customer_id = b.customer_id','left')
			->having('balance > 0') 
			->group_by('a.customer_id')
			->order_by('a.customer_name', 'asc')
			->limit($offset, $limit)
			->get()
			->result();

         
    }


     public function count_credit_customer()
    {
        return $result = $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode`)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode`)) as balance")
			->from('customer_information a')
			->join('acc_coa b','a.customer_id = b.customer_id','left')
			->having('balance > 0') 
			->group_by('a.customer_id')
			->order_by('a.customer_name', 'asc')
			->get()
			->num_rows();

         
    }

	public function singledata($id = null)
	{
		return $this->db->select('*')
			->from('tov_production')
			->where('production_id', $id)
			->get()
			->row();
	}

public function production_information($id = null)
	{
		return $this->db->select('*')
			->from('tov_production_information')
			->where('production_id', $id)
			->get()
			->result();
	}


public function production_discription_information_details($production_information_id = null)
	{
		return $this->db->select('*')
			->from('tov_product_catalogue')
			->where('production_information_id', $production_information_id)
			->get()
			->result();
	}


public function product_catalogue_details($product_catalogue_id =0)
	{
		return $this->db->select('*')
			->from('tov_product_catalogue')
			->where('product_catalogue_id', $product_catalogue_id)
			->get()
			->result();
	}


public function singledispatch($sample_id = null)
	{
		return $this->db->select('*')
			->from('tov_dispatch')
			->where('sample_id', $sample_id)
			->get()
			->row();
	}


public function dispatch_details($dispatch_id = null)
	{
		return $this->db->select('*')
			->from('tov_dispatch')
			->where('dispatch_id', $dispatch_id)
			->get()
			->row();
	}


public function dispatch_detailswithpurchase_order($brand_sample_id = null)
	{
		return $this->db->select('*')
			->from('tov_dispatch')
			->where('brand_sample_id', $brand_sample_id)
			->get()
			->row();
	}

  public function allsamples()
  {
    return $this->db->select('*')
      ->from('tov_sample_order')
      ->get()
      ->result();
  }
  
  public function allclients()
  {
    return $this->db->select('*')
      ->from('tov_client')
      ->get()
      ->result();
  }
  
  public function allbrands()
  {
    return $this->db->select('*')
      ->from('tov_brands')
      ->get()
      ->result();
  }
  
  public function samplingInformation_materialDescription($sample_id)
  {
	  return $this->db->select('*')
			->from('tov_sampling_information')
			->where('sample_id', $sample_id)
			->group_by('material_description')
			->get()
			->result();
  }
  
  
  

  public function bdtask_all_credit_customer(){

   return $data =  $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode`)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode`)) as balance")
      ->from('customer_information a')
      ->join('acc_coa b','a.customer_id = b.customer_id','left')
      ->having('balance > 0')
      ->group_by('a.customer_id')
      ->order_by('a.customer_name', 'asc')
      ->get()
      ->result();
  }

    public function bdtask_all_paid_customer(){

   return $data =  $this->db->select("a.*,b.HeadCode,((select ifnull(sum(Debit),0) from acc_transaction where COAID= `b`.`HeadCode`)-(select ifnull(sum(Credit),0) from acc_transaction where COAID= `b`.`HeadCode`)) as balance")
      ->from('customer_information a')
      ->join('acc_coa b','a.customer_id = b.customer_id','left')
      ->having('balance <= 0')
      ->group_by('a.customer_id')
      ->order_by('a.customer_name', 'asc')
      ->get()
      ->result();
  }

	public function update($data = array())
	{
		$update =  $this->db->where('production_id', $data["production_id"])
			->update("tov_production", $data);
      return true;
	}

	public function update_dispatch($data = array())
	{
		
		
		$update =  $this->db->where('dispatch_id', $data["dispatch_id"])
			->update("tov_dispatch", $data);
      return true;
	}

     public function client_details($client_name='')
  {
    return $this->db->select('*')
      ->from('tov_client')
      ->where('client_name', $client_name)
	  ->get()
      ->result();
  }
  
  public function brands_details($brand_name='')
  {
    return $this->db->select('*')
      ->from('tov_brands')
	  ->where('brand_name', $brand_name)
      ->get()
      ->result();
  }
  




    public function previous_balance_add($balance, $customer_id) {
    $cusifo = $this->db->select('*')->from('customer_information')->where('customer_id',$customer_id)->get()->row();
    $headn = $customer_id.'-'.$cusifo->customer_name;
    $coainfo = $this->db->select('*')->from('acc_coa')->where('HeadName',$headn)->get()->row();
    $customer_headcode = $coainfo->HeadCode;
        $transaction_id = $this->generator(10);
       

// Customer debit for previous balance
      $cosdr = array(
      'VNo'            =>  $transaction_id,
      'Vtype'          =>  'PR Balance',
      'VDate'          =>  date("Y-m-d"),
      'COAID'          =>  $customer_headcode,
      'Narration'      =>  'Customer debit For '.$cusifo->customer_name,
      'Debit'          =>  $balance,
      'Credit'         =>  0,
      'IsPosted'       => 1,
      'CreateBy'       => $this->session->userdata('id'),
      'CreateDate'     => date('Y-m-d H:i:s'),
      'IsAppove'       => 1
    );
       $inventory = array(
      'VNo'            =>  $transaction_id,
      'Vtype'          =>  'PR Balance',
      'VDate'          =>  date("Y-m-d"),
      'COAID'          =>  1141,
      'Narration'      =>  'Inventory credit For Old sale For'.$cusifo->customer_name,
      'Debit'          =>  0,
      'Credit'         =>  $balance,//purchase price asbe
      'IsPosted'       => 1,
      'CreateBy'       => $this->session->userdata('id'),
      'CreateDate'     => date('Y-m-d H:i:s'),
      'IsAppove'       => 1
    ); 

       
        if(!empty($balance)){
           $this->db->insert('acc_transaction', $cosdr); 
           $this->db->insert('acc_transaction', $inventory); 
        }
    }



public function generator($lenth)
    {
        $number=array("A","B","C","D","E","F","G","H","I","J","K","L","N","M","O","P","Q","R","S","U","V","T","W","X","Y","Z","1","2","3","4","5","6","7","8","9","0");
    
        for($i=0; $i<$lenth; $i++)
        {
            $rand_value=rand(0,34);
            $rand_number=$number["$rand_value"];
        
            if(empty($con))
            { 
            $con=$rand_number;
            }
            else
            {
            $con="$con"."$rand_number";}
        }
        return $con;
    }


          public function customer_ledgerdata($per_page, $page) {
        $this->db->select('a.*,b.HeadName');
        $this->db->from('acc_transaction a');
        $this->db->join('acc_coa b','a.COAID=b.HeadCode');
        $this->db->where('b.PHeadName','Customer Receivable');
        $this->db->where('a.IsAppove',1);
        $this->db->order_by('a.VDate','desc');
        $this->db->limit($per_page, $page);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }


		public function production_listdata($per_page, $page) {
        //ini_set('display_startup_errors', 1);
//ini_set('display_errors', 1);
		
		$po_no=$this->input->post('po_no');
			$client=$this->input->post('client_id');	
			$brand=$this->input->post('brand_id');
			
		
		
		$this->db->select('tov_production.*');
        $this->db->from('tov_production');
		
		
		if(!empty(trim($po_no)))
		{
			$this->db->where(array('purchase_order_no' => $po_no));
		}	
		
		if(!empty(trim($client)))
		{
			$this->db->where(array( 'client_id' => $client));
		}	
		
		if(!empty(trim($brand)))
		{
			$this->db->where(array('brand_id' => $brand));
		}	
		
		
        $this->db->order_by('create_date','desc');
        $this->db->limit($per_page, $page);
        $query = $this->db->get();
		
		
		
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }
        
        public function count_production() {
			
			
			$po_no=$this->input->post('po_no');
			$client=$this->input->post('client_id');	
			$brand=$this->input->post('brand_id');
			
		
			
        $this->db->select('tov_production.*');
        $this->db->from(' tov_production');
		
		
		if(!empty(trim($po_no)))
		{
			$this->db->where(array('purchase_order_no' => $po_no));
		}	
	
		if(!empty(trim($client)))
		{
			$this->db->where(array( 'client_id' => $client));
		}	
		
		if(!empty(trim($brand)))
		{
			$this->db->where(array('brand_id' => $brand));
		}
			
        
		$this->db->order_by('create_date','desc');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->num_rows();
        }
        return false;
    }
  

	 public function sample_order_list() {
        $this->db->select('*');
        $this->db->from(' tov_sample_order');
        $this->db->order_by('create_date', 'desc');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

 public function production_information_list() {
        $this->db->select('*');
        $this->db->from('tov_production');
        $this->db->order_by('create_date', 'desc');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

      

        public function customer_personal_data($customer_id) {
        $this->db->select('*');
        $this->db->from('customer_information');
        $this->db->where('customer_id', $customer_id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

           public function customerledger_searchdata($customer_id, $start, $end) {
        $this->db->select('a.*,b.HeadName');
        $this->db->from('acc_transaction a');
        $this->db->join('acc_coa b','a.COAID=b.HeadCode');
        $this->db->where(array('b.customer_id' => $customer_id, 'a.VDate >=' => $start, 'a.VDate <=' => $end));
        $this->db->where('a.IsAppove',1);
        $this->db->order_by('a.VDate','desc');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

        public function customer_list_advance(){
        $this->db->select('*');
        $this->db->from('customer_information');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

        public function advance_details($transaction_id,$customer_id){

        $headcode = $this->db->select('HeadCode')->from('acc_coa')->where('customer_id',$customer_id)->get()->row();
        return $data  = $this->db->select('*')
                        ->from('acc_transaction')
                        ->where('VNo',$transaction_id)
                        ->where('COAID',$headcode->HeadCode)
                        ->get()
                        ->result_array();

    }







public function dispatch_listdata($per_page, $page) {
        //ini_set('display_startup_errors', 1);
//ini_set('display_errors', 1);
		
		 $this->db->select('D.*,SI.material_description,SI.colors');
        $this->db->from('tov_dispatch D');
        $this->db->join('tov_sampling_information SI','D.brand_sample_id=SI.brand_sample_id');
        //$this->db->where('b.PHeadName','Customer Receivable');
        //$this->db->where('a.IsAppove',1);
        $this->db->order_by('SI.material_description','asc');
        $this->db->limit($per_page, $page);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
		
		
    }
        
        public function count_dispatch() {
        $this->db->select('D.*,SI.material_description,SI.colors');
        $this->db->from('tov_dispatch D');
        $this->db->join('tov_sampling_information SI','D.brand_sample_id=SI.brand_sample_id');
        //$this->db->where('b.PHeadName','Customer Receivable');
        //$this->db->where('a.IsAppove',1);
        $this->db->order_by('SI.material_description','asc');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->num_rows();
        }
        return false;
    }
    

    public function production_list() {
        $this->db->select('*');
        $this->db->from('tov_production');
        $this->db->order_by('create_date', 'desc');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

 public function product_catalogue_list() {
        $this->db->select('*');
        $this->db->from('tov_product_catalogue');
        $this->db->order_by('create_date', 'desc');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

     public function production_dispatch_list() {
        $this->db->select('*');
        $this->db->from('tov_production_dispatch');
        $this->db->order_by('create_date', 'desc');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }
    
     public function count_production_information() {
			
		
		$po_no=$this->input->get('po_no');
		$client=$this->input->get('client_id');	
		$brand=$this->input->get('brand_id');
			
		
			
        $this->db->select('PI.*');
        $this->db->from(' tov_production_information PI');
        $this->db->join('tov_product_catalogue PC','PI.production_information_id=PC.production_information_id','left');
		$this->db->join('tov_production P','PI.production_id=P.production_id','left');
		$this->db->join(' tov_production_dispatch_info PDI','PI.production_information_id=PDI.production_information_id','left');
		
		
		
		if(!empty(trim($po_no)))
		{
			$this->db->where(array('P.production_id' => $po_no));
		}	
	
		if(!empty(trim($client)))
		{
			$this->db->where(array( 'P.client_id' => $client));
		}	
		
		if(!empty(trim($brand)))
		{
			$this->db->where(array('P.brand_id' => $brand));
		}
			
        $this->db->group_by('PI.production_information_id');
		$this->db->order_by('PI.create_date','desc');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->num_rows();
        }
        return false;
    }

    public function production_dispatch_information_datalist($per_page, $page) {
        //ini_set('display_startup_errors', 1);
//ini_set('display_errors', 1);
		
		    ///$invoice_no=$this->input->get('invoice_no');
		    $po_no=$this->input->get('po_no');
			$client=$this->input->get('client_id');	
			$brand_id=$this->input->get('brand_id');
			
	  $this->db->select('PI.*, PC.*,SUM(PDI.qty) as d_qty,PDI.remaining_qty');
        $this->db->from('tov_production_information PI');
	    $this->db->join('tov_product_catalogue PC','PI.production_information_id=PC.production_information_id','left');
		$this->db->join('tov_production P','PI.production_id=P.production_id','left');
	    $this->db->join(' tov_production_dispatch_info PDI','PI.production_information_id=PDI.production_information_id','left');
	
		//if(!empty(trim($invoice_no)))
		//{
		//	$this->db->where(array('PD.invoice_no' => $invoice_no));
		//}	
		
		if(!empty(trim($po_no)))
		{
			$this->db->where(array('P.production_id' => $po_no));
		}	
	
		if(!empty(trim($client)))
		{
			$this->db->where(array( 'P.client_id' => $client));
		}	
		
		if(!empty(trim($brand)))
		{
			$this->db->where(array('P.brand_id' => $brand));
		}
		
	
		
		 $this->db->group_by('PI.production_information_id');
        $this->db->order_by('PI.create_date','desc');
        $this->db->limit($per_page, $page);
        $query = $this->db->get();
		
		
		
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

    
    

    public function count_production_dispatch() {
        
        
       
			
	$production_dispatch_id=$this->input->get('production_dispatch_id');
		//$po_no=$this->input->get('po_no');
		//$client=$this->input->get('client_id');	
		//$brand=$this->input->get('brand_id');
			
		
		$this->db->select('PI.*');
		$this->db->from('tov_production_dispatch_info PDI');
		$this->db->join('tov_production_dispatch PD','PDI.production_dispatch_id=PD.production_dispatch_id','left');
		$this->db->join('tov_production_information PI','PDI.production_information_id =PI.production_information_id','left');
		$this->db->join('tov_product_catalogue PC','PI.production_information_id=PC.production_information_id','left');
		
        //$this->db->select('PI.*');
        //$this->db->from(' tov_production_information PI');
        //$this->db->join('tov_product_catalogue PC','PI.production_information_id=PC.production_information_id','left');
		//$this->db->join('tov_production P','PI.production_id=P.production_id','left');
		//$this->db->join(' tov_production_dispatch_info PDI','PI.production_information_id=PDI.production_information_id','inner');
		
		
		
		if(!empty(trim($production_dispatch_id)))
		{
			$this->db->where(array('PD.production_dispatch_id' => $production_dispatch_id));
		}	
	/*
		if(!empty(trim($client)))
		{
			$this->db->where(array( 'P.client_id' => $client));
		}	
		
		if(!empty(trim($brand)))
		{
			$this->db->where(array('P.brand_id' => $brand));
		}
		*/	
        $this->db->group_by('PI.production_information_id');
		//$this->db->order_by('PI.create_date','desc');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->num_rows();
        }
        return false;
    }
  
    public function production_dispatch_listdata($per_page, $page) {
        //ini_set('display_startup_errors', 1);
//ini_set('display_errors', 1);
		
		$production_id=$this->input->get('production_id');
			$client=$this->input->get('client_id');	
			$brand_id=$this->input->get('brand_id');
		//$invoice_no=$this->input->get('invoice_no');	
		$production_dispatch_id=$this->input->get('production_dispatch_id');
				$this->db->select('PI.*, PC.*,PDI.qty as d_qty,PDI.remaining_qty,PDI.production_dispatch_info_id,PDDI.debit_qty');
		$this->db->from('tov_production_dispatch_info PDI');
		$this->db->join('tov_production_dispatch PD','PDI.production_dispatch_id=PD.production_dispatch_id','left');
		$this->db->join('tov_production_information PI','PDI.production_information_id =PI.production_information_id','left');
		
		$this->db->join('tov_production_dispatch_debit_info PDDI','PDI.production_dispatch_info_id  =PDDI.production_dispatch_info_id ','left');
			
	
		
		
		$this->db->join('tov_production P','PI.production_id=P.production_id','left');
		$this->db->join('tov_product_catalogue PC','PI.production_information_id=PC.production_information_id','left');

			
	  //$this->db->select('PI.*, PC.*,PDI.qty as d_qty,PDI.remaining_qty');
        //$this->db->from('tov_production_information PI');
	    //$this->db->join('tov_product_catalogue PC','PI.production_information_id=PC.production_information_id','left');
		//$this->db->join('tov_production P','PI.production_id=P.production_id','left');
	    //$this->db->join(' tov_production_dispatch_info PDI','PI.production_information_id=PDI.production_information_id','inner');
	
		if(!empty(trim($production_dispatch_id)))
		{
			$this->db->where(array('PD.production_dispatch_id' => $production_dispatch_id));
		}	
	
	
		if(!empty(trim($client)))
		{
			$this->db->where(array( 'P.client_id' => $client));
		}	
		
		if(!empty(trim($brand_id)))
		{
			$this->db->where(array('P.brand_id' => $brand_id));
		}
		
			if(!empty(trim($production_id)))
		{
			$this->db->where(array('PD.production_id' => $production_id));
		}
	
		 ///$this->db->group_by('PI.production_information_id');
        $this->db->order_by('PI.create_date','desc');
        $this->db->limit($per_page, $page);
        $query = $this->db->get();
		
		
		
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }




         public function count_production_approval() {
			
		
		$po_no=$this->input->get('po_no');
		$client=$this->input->get('client_id');	
		$brand=$this->input->get('brand_id');
			
		
			
        $this->db->select('PI.*');
        $this->db->from(' tov_production_information PI');
        $this->db->join('tov_product_catalogue PC','PI.production_information_id=PC.production_information_id','left');
		$this->db->join('tov_production P','PI.production_id=P.production_id','left');
		$this->db->join(' tov_production_dispatch_info PDI','PI.production_information_id=PDI.production_information_id','left');
		$this->db->where(array('PI.approvel' => 1));
		
		
		if(!empty(trim($po_no)))
		{
			$this->db->where(array('P.production_id' => $po_no));
		}	
	
		if(!empty(trim($client)))
		{
			$this->db->where(array( 'P.client_id' => $client));
		}	
		
		if(!empty(trim($brand)))
		{
			$this->db->where(array('P.brand_id' => $brand));
		}
			
        $this->db->group_by('PI.production_information_id');
		$this->db->order_by('PI.create_date','desc');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->num_rows();
        }
        return false;
    }
    
    
    
    public function production_approval_datalist($per_page, $page) {
        //ini_set('display_startup_errors', 1);
//ini_set('display_errors', 1);
		
		    ///$invoice_no=$this->input->get('invoice_no');
		    $po_no=$this->input->get('po_no');
			$client=$this->input->get('client_id');	
			$brand_id=$this->input->get('brand_id');
			
	  $this->db->select('PI.*, PC.*,SUM(PDI.qty) as d_qty,PDI.remaining_qty');
        $this->db->from('tov_production_information PI');
	    $this->db->join('tov_product_catalogue PC','PI.production_information_id=PC.production_information_id','left');
		$this->db->join('tov_production P','PI.production_id=P.production_id','left');
	    $this->db->join(' tov_production_dispatch_info PDI','PI.production_information_id=PDI.production_information_id','left');
	    $this->db->where(array('PI.approvel' => 1));
	
		//if(!empty(trim($invoice_no)))
		//{
		//	$this->db->where(array('PD.invoice_no' => $invoice_no));
		//}	
		
		if(!empty(trim($po_no)))
		{
			$this->db->where(array('P.production_id' => $po_no));
		}	
	
		if(!empty(trim($client)))
		{
			$this->db->where(array( 'P.client_id' => $client));
		}	
		
		if(!empty(trim($brand)))
		{
			$this->db->where(array('P.brand_id' => $brand));
		}
		
	
		
		 $this->db->group_by('PI.production_information_id');
        $this->db->order_by('PI.create_date','desc');
        $this->db->limit($per_page, $page);
        $query = $this->db->get();
		
		
		
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }





}

