<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 #------------------------------------    
    # Author: Bdtask Ltd
    # Author link: https://www.bdtask.com/
    # Dynamic style php file
    # Developed by :Isahaq
    #------------------------------------    

class Production extends MX_Controller {

    public function __construct()
    {
        parent::__construct();

        $this->load->model(array(
            'Production_model'));
            

        if (! $this->session->userdata('isLogIn'))
            redirect('login');
          
    }
    
    function index() 
	{
    		
		$data['title']             = display('sample_list');
        $data['module']            = "sampling";
        $data['page']              = "sample_list"; 
        //echo "===============";
		///$data["customer_dropdown"] = $this->Production_model->customer_dropdown();
        
		
		
	   $data['all_samples']      = $this->Production_model->allsamples(); 
      
	   
		echo modules::run('template/layout', $data);
    }


  
    

   
    
    


  public function bdtask_form($id = null)
    {
        //$data['title'] = display('add_sample');
        
       // error_reporting(E_ALL);
//ini_set('display_errors', '1');
        
        #-------------------------------#
        $this->form_validation->set_rules('po_no','P.O No','required|max_length[200]');
        $this->form_validation->set_rules('po_date', 'P.O Date') ;
		$this->form_validation->set_rules('client','client','required|max_length[200]');
        //if(empty($id)){
        //$this->form_validation->set_rules('customer_email',display('email'),'max_length[100]|valid_email|is_unique[customer_information.customer_email]');
    //}else{
      //  $this->form_validation->set_rules('customer_email',display('email'),'max_length[100]|valid_email');
    //}
        //$this->form_validation->set_rules('contact',display('contact'),'max_length[200]');
        //$this->form_validation->set_rules('phone',display('phone'),'max_length[20]');
        //$this->form_validation->set_rules('city',display('city'),'max_length[100]'); 
        //$this->form_validation->set_rules('state',display('state'),'max_length[100]');
        //$this->form_validation->set_rules('zip',display('zip'),'max_length[30]');
        //$this->form_validation->set_rules('country',display('country'),'max_length[100]');  
        //$this->form_validation->set_rules('customer_address',display('customer_address'),'max_length[255]');
        //$this->form_validation->set_rules('address2',display('address2'),'max_length[255]'); 
        #-------------------------------#


/*
        $data['customer'] = (object)$postData = [
            'customer_id'      => $this->input->post('customer_id',true),
            'customer_name'    => $this->input->post('customer_name',true),
            'customer_mobile'  => $this->input->post('customer_mobile', true),
            'customer_email'   => $this->input->post('customer_email', true),
            'email_address'    => $this->input->post('email_address', true),
            'contact'          => $this->input->post('contact', true),
            'phone'            => $this->input->post('phone', true),
            'fax'              => $this->input->post('fax', true), 
            'city'             => $this->input->post('city', true) ,
            'state'            => $this->input->post('state', true) ,
            'zip'              => $this->input->post('zip', true) ,
            'country'          => $this->input->post('country', true) ,
            'customer_address' => $this->input->post('customer_address', true) ,
            'address2'         => $this->input->post('address2', true) ,
            'status'           => 1,
            'create_by'        => $this->session->userdata('id') ,
            
        ]; 
		
		*/
		
		
		
		
		$data['tov_production'] = (object)$postData = [
		
		'production_id'=> $this->input->post('production_id',true),
		'brand_id' => $this->input->post('brand',true),
		'client_id'=> $this->input->post('client',true),
		'purchase_order_date'=> $this->input->post('po_date',true),
		'purchase_order_no'=> $this->input->post('po_no',true),
		'csd_date'=> $this->input->post('csd',true),
		'create_date'=> date('Y-m-d H:i:s'),
		'create_by'=>$this->session->userdata('id')
        ]; 
		
		
		
		
        #-------------------------------#
        if ($this->form_validation->run() === true) {
            #if empty $id then insert data
            if (empty($postData['production_id'])) {
              $tmp_production_id=  $this->Production_model->create($postData);
				if ($tmp_production_id) {
				
								
					$this -> db -> where('production_id', $tmp_production_id	);
					$this -> db -> delete('tov_production_information');

				
				$countsize = count($this->input->post('length'));
			
				for ($i=0; $i<$countsize ; $i++) 
				{
				
				 
			
				$postData2 = [
					'production_id'=>$tmp_production_id,
					'width'=>$this->input->post('width')[$i],
					'length'=>$this->input->post('length')[$i],
					'color'=>$this->input->post('colors')[$i],
					'uom'=>$this->input->post('umo')[$i],
					'qty'=>$this->input->post('qty')[$i],
					'rate'=>$this->input->post('rate')[$i],
					'create_date'=> date('Y-m-d H:i:s'),
					'create_by'=> $this->session->userdata('id')
					];
				$production_information_id=	$this->Production_model->create_production_information($postData2);
				///echo "==============production_information_id".$production_information_id	;
				
				$article_code = $this->input->post('article_code')[$i];    
			    
			    ///echo "*************".$article_code;
			    
			    if(!empty($article_code ))
			    {
				    $Data2 = [
					'production_information_id'=>$production_information_id,
					'article_code'=>(!empty($article_code)?$article_code:''),
					'production_id'=>$tmp_production_id,
					'lace_type'=>(!empty($this->input->post('lace_type')[$i])?$this->input->post('lace_type')[$i]:''),
					'material_type'=>(!empty($this->input->post('material_type')[$i])?$this->input->post('material_type')[$i]:''),
					'no_of_colors'=>(!empty($this->input->post('no_of_colors')[$i])?$this->input->post('no_of_colors')[$i]:0),
					'create_date'=> date('Y-m-d H:i:s'),
					'create_by'=> $this->session->userdata('id')
					];
					
					///print_r($Data2);
					//exit;
			        $this->Production_model->create_product_catalogue($Data2);
			        
			        
			    }    
				    
				    
				    
				    
				}
				
					
					
					
                    #set success message
                        $info['msg']    = display('save_successfully');
                        
						
						$info['status'] = 1;
						
						redirect(base_url('production_list'));
						
                } else {
                    #set exception message
                        $info['msg']    = display('please_try_again');
                        $info['status'] = 0;
                }
            } else {
                if ($this->Production_model->update($postData)) {
					
									
				//$this -> db -> where('production_id', $postData['production_id']	);
				//$this -> db -> delete('tov_production_information');

					$countsize = count($this->input->post('length'));
			
			
				for ($i=0; $i<$countsize ; $i++) 
				{
					$postData2 = [
					'production_information_id'=>$this->input->post('production_information_id')[$i],
					'production_id'=>$postData['production_id'],
					'width'=>$this->input->post('width')[$i],
					'length'=>$this->input->post('length')[$i],
					'color'=>$this->input->post('colors')[$i],
					'uom'=>$this->input->post('umo')[$i],
					'qty'=>$this->input->post('qty')[$i],
					'rate'=>$this->input->post('rate')[$i],
					'create_by'=> $this->session->userdata('id')
					]; 
				
				//print_r($postData2);
				//exit;
					
					$this->Production_model->update_production_information($postData2);
					
					
					
				$article_code = $this->input->post('article_code')[$i];    
			    
			    if(!empty($article_code ))
			    {
				    $Data12 = [
					
					
					
					'product_catalogue_id'=>(!empty($this->input->post('product_catalogue_id')[$i])?$this->input->post('product_catalogue_id')[$i]:0),
					
					'production_information_id'=>$this->input->post('production_information_id')[$i],
					'article_code'=>(!empty($article_code)?$article_code:''),
					'lace_type'=>(!empty($this->input->post('lace_type')[$i])?$this->input->post('lace_type')[$i]:''),
					'material_type'=>(!empty($this->input->post('material_type')[$i])?$this->input->post('material_type')[$i]:''),
					'no_of_colors'=>(!empty($this->input->post('no_of_colors')[$i])?$this->input->post('no_of_colors')[$i]:0),
					'create_by'=> $this->session->userdata('id')
					];
					
				    //print_r($Data12);
					//exit;
			        $this->Production_model->update_product_catalogue($Data12);
			        
			        
			    }    
					
					
					
					
					
					
				}
                    #set success message
                    $info['msg']    = display('update_successfully');
                    $info['status'] = 1;
					redirect(base_url('production_list'));
                } else {
                    #set exception message
                    $info['msg']    = display('please_try_again');
                    $info['status'] = 0;
                } 
            }
 
            echo json_encode($info);

        } else { 
            
			
			
			if(empty($this->input->post('customer_name',true))){
	
			if(!empty($id)){
            $data['title']    = 'Edit Production';
            $data['production'] = $this->Production_model->singledata($id);  
            
		
			
			$data['production_information'] = $this->Production_model->production_information($id); 
		
		
			$data['production_id']=$id;
			}
			else
			{
			$data['production_id']="";	
			$data['title']    = 'Create Production';
			}	
            $data['module']   = "production";  
            $data['page']     = "form";  
			$data['clients'] = $this->Production_model->allclients(); 			
			$data['brands'] = $this->Production_model->allbrands(); 			
			
			
			
            echo Modules::run('template/layout', $data); 
        }else{

          $info['msg']    = validation_errors();
          $info['status'] = 0;
           echo json_encode($info);
        }
        } 
    }
///////////////////////////////////////////////////////////

public function production_dispatch($sample_id = null)
    {
		
		
        $data['title'] = 'Production Dispatch';
        #-------------------------------#
        $this->form_validation->set_rules('purchase_order_no','Purchase Order No','required|max_length[100]');
        
		$this->form_validation->set_rules('dispatch_date', 'Dispatch Date') ;
		$this->form_validation->set_rules('shade_no','Shade No','required|max_length[50]');
		$this->form_validation->set_rules('challan_no','Challan No','required|max_length[50]');
			
        
		
		
	
		
		$postData = [
		'dispatch_id' => $this->input->post('dispatch_id',true),
		'sample_id'=> $this->input->post('sample_id',true),
		'brand_sample_id'=>$this->input->post('brand_sample_id',true),
		'sample_po_no'=> $this->input->post('sample_po_no',true),
		'shade_no'=> $this->input->post('shade_no',true),
		'challan_no'=> $this->input->post('challan_no',true),
		'dispatch_date'=> $this->input->post('dispatch_date',true),
		'purchase_order_no'=> $this->input->post('purchase_order_no',true),
		'create_by'=> date('Y-m-d H:i:s'),
		'create_date'=> $this->session->userdata('id')
		];
		
		
		
		
		//print_r($postData);
	//exit;
		//echo "=========".  strlen( trim($postData['dispatch_id']));
		//exit;
        #-------------------------------#
        if ($this->form_validation->run() === true) {
            #if empty $id then insert data
            if (empty(trim($postData['dispatch_id']))) {
              $tmp_dispatch_id=  $this->Production_model->create_dispatch($postData);
				if ($tmp_dispatch_id) {
				
					
				
				
            
        
					
					
					
					
					
					
                    #set success message
                        $info['msg']    = display('save_successfully');
                        $info['status'] = 1;
                } else {
                    #set exception message
                        $info['msg']    = display('please_try_again');
                        $info['status'] = 0;
                }
            } else {
                if ($this->Production_model->update_dispatch($postData)) {
					//print_r($postData);
                    #set success message
                    $info['msg']    = display('update_successfully');
                    $info['status'] = 1;
                } else {
                    #set exception message
                    $info['msg']    = display('please_try_again');
                    $info['status'] = 0;
                } 
            }
 
            echo json_encode($info);

        } else { 
            
			
			
		
	
			

			//$data['sample'] = $this->Production_model->singledata($sample_id);  
			
			$data['clients'] = $this->Production_model->allclients(); 
			
			//$data['material_descriptions'] = $this->Production_model->samplingInformation_materialDescription($sample_id);
			
			
			//$data['sample_id']=$sample_id;	
			//$data['dispatch_id']=$dispatch_id;	
			
            $data['module']   = "production";  
            $data['page']     = "add_production_dispatch";  
			
			//print_r($data);
			//exit;
			
            echo Modules::run('template/layout', $data); 
        
        } 
    }







public function dispatch_approval_form($dispatch_id = null)
    {
		
		
        $data['title'] = 'Add Approval';
        #-------------------------------#
        $this->form_validation->set_rules('approved_status','Approved status','required|max_length[100]');
        
		//$this->form_validation->set_rules('dispatch_date', 'Dispatch Date') ;
		//$this->form_validation->set_rules('shade_no','Shade No','required|max_length[50]');
		//$this->form_validation->set_rules('challan_no','Challan No','required|max_length[50]');
			
        
		
		
	$postData = [
		'dispatch_id' => $this->input->post('dispatch_id',true),
		'status'=> $this->input->post('approved_status',true),
		'description'=>$this->input->post('description',true)
		];
	
		
		
		
	
		//echo "=========".  strlen( trim($postData['dispatch_id']));
		//exit;
        #-------------------------------#
        if ($this->form_validation->run() === true) {
            #if empty $id then insert data
            if (!empty(trim($postData['dispatch_id']))) {
				
				
				
				//print_r($postData);
	//exit;
             
                if ($this->Production_model->update_dispatch($postData)) {
					
					#set success message
                    //$info['msg']    = display('update_successfully');
                    //$info['status'] = 1;
					 echo "<script>alert('Your Status has been Updated  successfully');</script>"; 
					 redirect('dispatch_approval_form/'.$postData['dispatch_id'], 'refresh');
                } else {
                    #set exception message
                    $info['msg']    = display('please_try_again');
                    $info['status'] = 0;
                } 
            }
 
            echo json_encode($info);

        } else { 
            
			
			
		
	
			
            //$data['title']    = display('edit_sample');
            //$data['sample_informations'] = $this->Production_model->sampling_information($sample_id);
			//$data['sample'] = $this->Production_model->singledata($sample_id);  
			
			//$data['singledispatch'] = $this->Production_model->singledispatch($sample_id); 
			
			//$data['material_descriptions'] = $this->Production_model->samplingInformation_materialDescription($sample_id);
			
			 $data['dispatch_details']          = $this->Production_model->dispatch_details($dispatch_id);
			
			$data['dispatch_id']=$dispatch_id;	
			
            $data['module']   = "Sampling";  
            $data['page']     = "add_dispatch_approval.php";  
			
			//print_r($data);
			//exit;
			
            echo Modules::run('template/layout', $data); 
        
        } 
    }




	function ajaxget_material_description_color()
	{
		
		$material_description=$this->input->post('material_description');
		$sampleid=$this->input->post('sampleid');
		
		
		$color_data= $this->db->select('*')
			->from('tov_sampling_information')
			->where('material_description', $material_description)
			->where('sample_id', $sampleid)
			
			->get()
			->result();
			
			
			$string_list='';
			foreach($color_data as $row  )
			{
		
			$string_list.='<option value="'.$row->brand_sample_id.'">'.$row->colors.'</option>';
		
			}	
			
			echo $string_list;
			
		
		
		
	}



	



		function randomToken($length = 4, $result='') 
		{

			for($i = 0; $i < $length; $i++) {

				$case = mt_rand(0, 1);
				switch($case){

					case 0:
						$data = mt_rand(0, 9);
						break;
					case 1:
						$alpha = range('a','z');
						$item = mt_rand(0, 25);

						$data = strtoupper($alpha[$item]);
						break;
				}

				$result .= $data;
			}

			return $result;
	}

    

    
	
	
	
	
	
	
public function production_list() {
    
    	//ini_set('display_startup_errors', 1);
//ini_set('display_errors', 1);
    
    $data['title']             = 'Dispatch List'; 
    $config["base_url"]        = base_url('production_list');
    $config["total_rows"]      = $this->Production_model->count_production();
    //echo $this->db->last_query();
    //print_r($config["total_rows"]);
    
	$config["per_page"]        = 5;
    $config["uri_segment"]     = 2;
    $config["last_link"]       = "Last"; 
    $config["first_link"]      = "First"; 
    $config['next_link']       = 'Next';
    $config['prev_link']       = 'Prev';  
    $config['full_tag_open']   = "<ul class='pagination col-xs pull-right'>";
    $config['full_tag_close']  = "</ul>";
    $config['num_tag_open']    = '<li>';
    $config['num_tag_close']   = '</li>';
    $config['cur_tag_open']    = "<li class='disabled'><li class='active'><a href='#'>";
    $config['cur_tag_close']   = "<span class='sr-only'></span></a></li>";
    $config['next_tag_open']   = "<li>";
    $config['next_tag_close']  = "</li>";
    $config['prev_tag_open']   = "<li>";
    $config['prev_tagl_close'] = "</li>";
    $config['first_tag_open']  = "<li>";
    $config['first_tagl_close']= "</li>";
    $config['last_tag_open']   = "<li>";
    $config['last_tagl_close'] = "</li>";
	$this->pagination->initialize($config);
    $page                      = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
    $data["productions"]           = $this->Production_model->production_listdata($config["per_page"], $page);
	$data["links"]             = $this->pagination->create_links();
    $data['production_information']          = $this->Production_model->production_information_list();
	
	$data['clients'] = $this->Production_model->allclients(); 			
	$data['brands'] = $this->Production_model->allbrands(); 
	$data['po_no']=$this->input->post('po_no');
	$data['clientid']=$this->input->post('client');	
	$data['brandid']=$this->input->post('brand');
	
	
	
    $data['customer_name']     = '';
    $data['customer_id']       = '';
    $data['address']           ='';
    $data['module']            = "production";      
    $data['page']              = "production_list"; 
	
    echo Modules::run('template/layout', $data); 
    }






    
    

    
    
    
     public function production_delete($production_id=0) 
     {
            //	ini_set('display_startup_errors', 1);
///ini_set('display_errors', 1);
          
            $this->db->where('production_id', $production_id)
                 ->delete('tov_production');

		$this->db->where('production_id', $production_id)
			->delete("tov_product_catalogue");

        $this->db->where('production_id', $production_id)
			->delete("tov_production_information");
        
        $this->session->set_flashdata('message', display('delete_successfully'));
        
        redirect("production_list");

        
    }
    
    
      public function bulk_uplade_production(){
        $data['title']         = 'Add Production CSV';
        $data['module']        = "production";
        $data['page']          = "add_production_csv"; 
        echo modules::run('template/layout', $data);
    }
    
   public function upload_production_csv()
   {
       //ini_set('display_startup_errors', 1);
//ini_set('display_errors', 1);



       
       $filename = $_FILES['upload_csv_file']['name'];  
        
        $basenameAndExtension = explode('.', $filename);
        $ext = end($basenameAndExtension);
        if($ext == 'csv'){
        $count=0;
        $fp = fopen($_FILES['upload_csv_file']['tmp_name'],'r') or die("can't open file");

        if (($handle = fopen($_FILES['upload_csv_file']['tmp_name'], 'r')) !== FALSE)
        {
       $i=0;
         //$this->db->trans_begin();
         while($csv_line = fgetcsv($fp,1024))
         {
            
            
            
            if($i==1)
            {
                
                 $purchase_order_no =(!empty($csv_line[2])?$csv_line[2]:'');
                
                $purchase_order_date=(!empty($csv_line[5])?$csv_line[5]: date('d/m/Y')) ;
				 $tmpdate = explode('-', $purchase_order_date);
				$purchase_order_date = $tmpdate[2].'-'.$tmpdate[1].'-'.$tmpdate[0];
				 
				 
            }
            elseif($i==2)
            {
                 
                 $brand_name=(!empty($csv_line[2])?$csv_line[2]:'');
                 
                 
                    $array_brand=  $this->Production_model->brands_details($brand_name);
                if(!empty($array_brand))
                {
                $brand_id= $array_brand[0]->id;
                
                 
                }
                else
                {
                    //$message = "This Brand does not match your records";
                    //echo "<script type='text/javascript'>alert('$message');</script>";
                    //exit;
					
					$brand_id= 0;
                    
                }
                ////////////////////////////////////////////////////////////////////
                
                 $csd_date=(!empty($csv_line[5])?$csv_line[5]: date('d/m/Y')) ;
                 ////$order_date=date("Y-m-d", strtotime($csd_date) );
				 
				 $tmpdate = explode('-', $csd_date);
				$csd_date = $tmpdate[2].'-'.$tmpdate[1].'-'.$tmpdate[0];
                
                
                 
                 
                 //$receiver_name=(!empty($csv_line[2])?$csv_line[2]:'') ;
                 //$receiver_contact= (!empty($csv_line[5])?$csv_line[5]:'') ;
                
            }
            elseif($i==3)
            {
                 
                $client_name=(!empty($csv_line[2])?$csv_line[2]:'');
                $array_client=  $this->Production_model->client_details($client_name);
                if(!empty($array_client))
                {
                $client_id=   $array_client[0]->id;
                }
                else
                {
                    //$message = "This Client does not match your records";
                    ///echo "<script type='text/javascript'>alert('$message');</script>";
                    //exit;
					 $client_id=   0;
                }

                 
                 
                 
                 
                ///$receiver_emial=(!empty($csv_line[5])?$csv_line[5]:'');  
                
            }
             elseif($i==4)
             {
                 
            
            
            $postData = [
		
		'brand_id' => $brand_id,
		'client_id'=> $client_id,
		'purchase_order_date'=> $purchase_order_date,
		'purchase_order_no'=> $purchase_order_no,
		'csd_date'=> $csd_date,
		'create_date'=> date('Y-m-d H:i:s'),
		'create_by'=>$this->session->userdata('id')
        ]; 
              $tmp_production_id=  $this->Production_model->create($postData);
        }
                 

      
    
                
        if (!empty($tmp_production_id) and $i>=8) 
        {
			
			if(!empty($csv_line[4]) and !empty($csv_line[5]) )
			{
				$postData2 = [
					'production_id'=>$tmp_production_id,
					'width'=>(!empty($csv_line[4])?$csv_line[4]:''),
					'length'=>(!empty($csv_line[5])?$csv_line[5]:''),
					'color'=>(!empty($csv_line[6])?$csv_line[6]:''),
					'uom'=>(!empty($csv_line[7])?$csv_line[7]:''),
					'qty'=>(!empty($csv_line[8])?$csv_line[8]:0),
					'rate'=>(!empty($csv_line[9])?$csv_line[9]:0),
					'create_date'=> date('Y-m-d H:i:s'),
					'create_by'=> $this->session->userdata('id')
					];
				$production_information_id=	$this->Production_model->create_production_information($postData2);
				
				
			
				    $Data2 = [
					'production_information_id'=>$production_information_id,
					'article_code'=>(!empty($csv_line[0])?$csv_line[0]:''),
					'production_id'=>$tmp_production_id,
					'lace_type'=>(!empty($csv_line[1])?$csv_line[1]:''),
					'material_type'=>(!empty($csv_line[3])?$csv_line[3]:''),
					'no_of_colors'=>(!empty($csv_line[4])?$csv_line[4]:''),
					'create_date'=> date('Y-m-d H:i:s'),
					'create_by'=> $this->session->userdata('id')
					];
			        $this->Production_model->create_product_catalogue($Data2);
			        
			        
			}
				    
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
				
			
        }	
                    
           
                
                
               
           $i++;    
         }
        //exit;
            redirect('production_list');    
         
         //$this->db->trans_complete ();
         
    }
      }
      
   }    
       
       
    /////////////////////////////////////////////////////////////////////////////   
       
       public function dispatch_form($id = null)
    {
        //$data['title'] = display('add_sample');
        
       // error_reporting(E_ALL);
//ini_set('display_errors', '1');
        
        #-------------------------------#
        $this->form_validation->set_rules('po_no','P.O No','required|max_length[200]');
        $this->form_validation->set_rules('po_date', 'P.O Date') ;
		$this->form_validation->set_rules('client','client','required|max_length[200]');
        //if(empty($id)){
        //$this->form_validation->set_rules('customer_email',display('email'),'max_length[100]|valid_email|is_unique[customer_information.customer_email]');
    //}else{
      //  $this->form_validation->set_rules('customer_email',display('email'),'max_length[100]|valid_email');
    //}
        //$this->form_validation->set_rules('contact',display('contact'),'max_length[200]');
        //$this->form_validation->set_rules('phone',display('phone'),'max_length[20]');
        //$this->form_validation->set_rules('city',display('city'),'max_length[100]'); 
        //$this->form_validation->set_rules('state',display('state'),'max_length[100]');
        //$this->form_validation->set_rules('zip',display('zip'),'max_length[30]');
        //$this->form_validation->set_rules('country',display('country'),'max_length[100]');  
        //$this->form_validation->set_rules('customer_address',display('customer_address'),'max_length[255]');
        //$this->form_validation->set_rules('address2',display('address2'),'max_length[255]'); 
        #-------------------------------#


/*
        $data['customer'] = (object)$postData = [
            'customer_id'      => $this->input->post('customer_id',true),
            'customer_name'    => $this->input->post('customer_name',true),
            'customer_mobile'  => $this->input->post('customer_mobile', true),
            'customer_email'   => $this->input->post('customer_email', true),
            'email_address'    => $this->input->post('email_address', true),
            'contact'          => $this->input->post('contact', true),
            'phone'            => $this->input->post('phone', true),
            'fax'              => $this->input->post('fax', true), 
            'city'             => $this->input->post('city', true) ,
            'state'            => $this->input->post('state', true) ,
            'zip'              => $this->input->post('zip', true) ,
            'country'          => $this->input->post('country', true) ,
            'customer_address' => $this->input->post('customer_address', true) ,
            'address2'         => $this->input->post('address2', true) ,
            'status'           => 1,
            'create_by'        => $this->session->userdata('id') ,
            
        ]; 
		
		*/
		
		
		
		
		$data['tov_production'] = (object)$postData = [
		
		'production_id'=> $this->input->post('production_id',true),
		'brand_id' => $this->input->post('brand',true),
		'client_id'=> $this->input->post('client',true),
		'purchase_order_date'=> $this->input->post('po_date',true),
		'purchase_order_no'=> $this->input->post('po_no',true),
		'csd_date'=> $this->input->post('csd',true),
		'create_date'=> date('Y-m-d H:i:s'),
		'create_by'=>$this->session->userdata('id')
        ]; 
		
		
		
		
        #-------------------------------#
        if ($this->form_validation->run() === true) {
            #if empty $id then insert data
            if (empty($postData['production_id'])) {
              $tmp_production_id=  $this->Production_model->create($postData);
				if ($tmp_production_id) {
				
								
					$this -> db -> where('production_id', $tmp_production_id	);
					$this -> db -> delete('tov_production_information');

				
				$countsize = count($this->input->post('length'));
			
				for ($i=0; $i<$countsize ; $i++) 
				{
				
				 
			
				$postData2 = [
					'production_id'=>$tmp_production_id,
					'width'=>$this->input->post('width')[$i],
					'length'=>$this->input->post('length')[$i],
					'color'=>$this->input->post('colors')[$i],
					'uom'=>$this->input->post('umo')[$i],
					'qty'=>$this->input->post('qty')[$i],
					'rate'=>$this->input->post('rate')[$i],
					'create_date'=> date('Y-m-d H:i:s'),
					'create_by'=> $this->session->userdata('id')
					];
				$production_information_id=	$this->Production_model->create_production_information($postData2);
				///echo "==============production_information_id".$production_information_id	;
				
				$article_code = $this->input->post('article_code')[$i];    
			    
			    ///echo "*************".$article_code;
			    
			    if(!empty($article_code ))
			    {
				    $Data2 = [
					'production_information_id'=>$production_information_id,
					'article_code'=>(!empty($article_code)?$article_code:''),
					'production_id'=>$tmp_production_id,
					'lace_type'=>(!empty($this->input->post('lace_type')[$i])?$this->input->post('lace_type')[$i]:''),
					'material_type'=>(!empty($this->input->post('material_type')[$i])?$this->input->post('material_type')[$i]:''),
					'no_of_colors'=>(!empty($this->input->post('no_of_colors')[$i])?$this->input->post('no_of_colors')[$i]:0),
					'create_date'=> date('Y-m-d H:i:s'),
					'create_by'=> $this->session->userdata('id')
					];
					
					///print_r($Data2);
					//exit;
			        $this->Production_model->create_product_catalogue($Data2);
			        
			        
			    }    
				    
				    
				    
				    
				}
				
					
					
					
                    #set success message
                        $info['msg']    = display('save_successfully');
                        
						
						$info['status'] = 1;
						
						redirect(base_url('production_list'));
						
                } else {
                    #set exception message
                        $info['msg']    = display('please_try_again');
                        $info['status'] = 0;
                }
            } else {
                if ($this->Production_model->update($postData)) {
					
									
				//$this -> db -> where('production_id', $postData['production_id']	);
				//$this -> db -> delete('tov_production_information');

					$countsize = count($this->input->post('length'));
			
			
				for ($i=0; $i<$countsize ; $i++) 
				{
					$postData2 = [
					'production_information_id'=>$this->input->post('production_information_id')[$i],
					'production_id'=>$postData['production_id'],
					'width'=>$this->input->post('width')[$i],
					'length'=>$this->input->post('length')[$i],
					'color'=>$this->input->post('colors')[$i],
					'uom'=>$this->input->post('umo')[$i],
					'qty'=>$this->input->post('qty')[$i],
					'rate'=>$this->input->post('rate')[$i],
					'create_by'=> $this->session->userdata('id')
					]; 
				
				//print_r($postData2);
				//exit;
					
					$this->Production_model->update_production_information($postData2);
					
					
					
				$article_code = $this->input->post('article_code')[$i];    
			    
			    if(!empty($article_code ))
			    {
				    $Data12 = [
					
					
					
					'product_catalogue_id'=>(!empty($this->input->post('product_catalogue_id')[$i])?$this->input->post('product_catalogue_id')[$i]:0),
					
					'production_information_id'=>$this->input->post('production_information_id')[$i],
					'article_code'=>(!empty($article_code)?$article_code:''),
					'lace_type'=>(!empty($this->input->post('lace_type')[$i])?$this->input->post('lace_type')[$i]:''),
					'material_type'=>(!empty($this->input->post('material_type')[$i])?$this->input->post('material_type')[$i]:''),
					'no_of_colors'=>(!empty($this->input->post('no_of_colors')[$i])?$this->input->post('no_of_colors')[$i]:0),
					'create_by'=> $this->session->userdata('id')
					];
					
				    //print_r($Data12);
					//exit;
			        $this->Production_model->update_product_catalogue($Data12);
			        
			        
			    }    
					
					
					
					
					
					
				}
                    #set success message
                    $info['msg']    = display('update_successfully');
                    $info['status'] = 1;
					redirect(base_url('production_list'));
                } else {
                    #set exception message
                    $info['msg']    = display('please_try_again');
                    $info['status'] = 0;
                } 
            }
 
            echo json_encode($info);

        } else { 
            
			
			
			if(empty($this->input->post('customer_name',true))){
	
			if(!empty($id)){
            //$data['title']    = 'Edit Production';
            //$data['production'] = $this->Production_model->singledata($id);  
            
		
			
			///$data['production_information'] = $this->Production_model->production_information($id); 
		
		
			///$data['production_id']=$id;
			}
			else
			{
			$data['production_id']="";	
			$data['title']    = 'Production Dispatch';
			}	
            $data['module']   = "production";  
            $data['page']     = "production_ dispatch_form";  
			$data['clients'] = $this->Production_model->allclients(); 			
			$data['brands'] = $this->Production_model->allbrands(); 
			
			$data['production_lists'] = $this->Production_model->production_list(); 
			
			$data['product_catalogue_lists'] = $this->Production_model->product_catalogue_list(); 
		
			

            echo Modules::run('template/layout', $data); 
        }else{

          $info['msg']    = validation_errors();
          $info['status'] = 0;
           echo json_encode($info);
        }
        } 
    }

       
       
       
       
       function ajaxget_product_catalogue_details() 
	{
		
		
		$product_catalogue_id=$this->input->post('product_catalogue_id',true);
		
		$product_catalogue_details=$this->Production_model->product_catalogue_details($product_catalogue_id); 
		
		
		///print_r($product_catalogue_details);
		
		//$dispatch=$this->Production_model->dispatch_detailswithpurchase_order($brand_sample_id);
		echo $product_catalogue_details[0]->lace_type.'||'.$product_catalogue_details[0]->material_type.'||'.$product_catalogue_details[0]->no_of_colors;
	}
       
       
    public function production_dispatch_list() {
	
	//ini_set('display_startup_errors', 1);
//ini_set('display_errors', 1);


     $this->session->set_userdata('production_dispatch_list', $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
    $data['title']             = 'sample List'; 
    $config["base_url"]        = base_url('production_dispatch_list');
    $config["total_rows"]      = $this->Production_model->count_production_information();
	$config["per_page"]        = 10;
    $config["uri_segment"]     = 2;
    $config["last_link"]       = "Last"; 
    $config["first_link"]      = "First"; 
    $config['next_link']       = 'Next';
    $config['prev_link']       = 'Prev';  
    $config['full_tag_open']   = "<ul class='pagination col-xs pull-right'>";
    $config['full_tag_close']  = "</ul>";
    $config['num_tag_open']    = '<li>';
    $config['num_tag_close']   = '</li>';
    $config['cur_tag_open']    = "<li class='disabled'><li class='active'><a href='#'>";
    $config['cur_tag_close']   = "<span class='sr-only'></span></a></li>";
    $config['next_tag_open']   = "<li>";
    $config['next_tag_close']  = "</li>";
    $config['prev_tag_open']   = "<li>";
    $config['prev_tagl_close'] = "</li>";
    $config['first_tag_open']  = "<li>";
    $config['first_tagl_close']= "</li>";
    $config['last_tag_open']   = "<li>";
    $config['last_tagl_close'] = "</li>";
	$this->pagination->initialize($config);
    $page                      = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
    $data["productiondispatch_listdata"]           = $this->Production_model->production_dispatch_information_datalist($config["per_page"], $page);
    
    //echo $this->db->last_query();
    
	
	$data["links"]             = $this->pagination->create_links();
    //$data['samplelists']          = $this->Sampling_model->sample_order_list();
	
	$data['clients'] = $this->Production_model->allclients(); 			
	$data['brands'] = $this->Production_model->allbrands();
	
	$data['production_lists'] = $this->Production_model->production_list(); 
	
	$data['production_id']=$this->input->get('po_no');
	$data['client_id']=$this->input->get('client_id');	
	$data['brand_id']=$this->input->get('brand_id');
	
	
    $data['customer_name']     = '';
    $data['customer_id']       = '';
    $data['address']           ='';
    $data['module']            = "production";      
    $data['page']              = "production_dispatch_listdata"; 
	
	
	
    echo Modules::run('template/layout', $data); 
    }
   
       
    function creatarray_production_dispatch()
	{
		
		if($_REQUEST['approvel']==1)
		{
		    
		    if(!empty($_POST['production_information_id'])) 
		    {
    		    foreach($_POST['production_information_id'] as $tmp_production_information_id) 
                {
                    //tov_production_dispatch_info
                    //tov_production_dispatch
                    
                    ///$remaining_qty=intval($this->input->post('actual_qty_'.$tmp_production_information_id))-intval($this->input->post('qty_'.$tmp_production_information_id));
                    
                    $postactive = ['approvel'=>1];
                    
                    	$update =  $this->db->where('production_information_id', $tmp_production_information_id)
			                    ->update("tov_production_information", $postactive);
                }
		    }
		    
		    //redirect('production_dispatch_list');
		    
		    
		    redirect('http://'.$this->session->userdata('production_dispatch_list'));
		    
		}
	
		
		if(!empty($_POST['production_information_id'])) 
		{
            
            
            $postData = [
            'production_id'=>$this->input->post('production_id'),
            'invoice_no'=>$this->input->post('invoice_no'),
            'invoice_date'=>$this->input->post('invoice_date'),
            'create_date'=>date('Y-m-d H:i:s'),
            'create_by'=>$this->session->userdata('id')	
						];
                $tmp_production_dispatch_id=  $this->Production_model->create_production_dispatch($postData);
                
            
            foreach($_POST['production_information_id'] as $tmp_production_information_id) 
            {
                //tov_production_dispatch_info
                //tov_production_dispatch
                
                ///$remaining_qty=intval($this->input->post('actual_qty_'.$tmp_production_information_id))-intval($this->input->post('qty_'.$tmp_production_information_id));
                
                $postData2 = [
                    'production_information_id'=>$tmp_production_information_id,
                    'production_dispatch_id'=>$tmp_production_dispatch_id,
                    'remaining_qty'=>0,
                    'qty'=>$this->input->post('qty_'.$tmp_production_information_id),
                    'rate'=>$this->input->post('rate_'.$tmp_production_information_id),
                    'actual_qty'=>$this->input->post('actual_qty_'.$tmp_production_information_id),
                    'create_date'=>date('Y-m-d H:i:s'),
                    'create_by'=>$this->session->userdata('id')	
						];
						
				//print_r($postData2);		
                //exit;
               $tmp_production_dispatch_id=  $this->Production_model->create_production_information_dispatch( $postData2);
               
            }
        }
		
	
		
		//redirect('production_dispatch_list');
		redirect('http://'.$this->session->userdata('production_dispatch_list'));
	}	
		   
    
    public function create_production_dispatch_debit() {
	
	//ini_set('display_startup_errors', 1);
    ////ini_set('display_errors', 1);
    
   
    $this->session->set_userdata('create_production_dispatch_debit', $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
    $data['title']             = 'sample List'; 
    $config["base_url"]        = base_url('create_production_dispatch_debit');
    $config["total_rows"]      = $this->Production_model->count_production_dispatch();
    //echo $this->db->last_query();
    //echo "==============";
    //exit;
    
	$config["per_page"]        = 10;
    $config["uri_segment"]     = 2;
    $config["last_link"]       = "Last"; 
    $config["first_link"]      = "First"; 
    $config['next_link']       = 'Next';
    $config['prev_link']       = 'Prev';  
    $config['full_tag_open']   = "<ul class='pagination col-xs pull-right'>";
    $config['full_tag_close']  = "</ul>";
    $config['num_tag_open']    = '<li>';
    $config['num_tag_close']   = '</li>';
    $config['cur_tag_open']    = "<li class='disabled'><li class='active'><a href='#'>";
    $config['cur_tag_close']   = "<span class='sr-only'></span></a></li>";
    $config['next_tag_open']   = "<li>";
    $config['next_tag_close']  = "</li>";
    $config['prev_tag_open']   = "<li>";
    $config['prev_tagl_close'] = "</li>";
    $config['first_tag_open']  = "<li>";
    $config['first_tagl_close']= "</li>";
    $config['last_tag_open']   = "<li>";
    $config['last_tagl_close'] = "</li>";
	$this->pagination->initialize($config);
    $page                      = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
    $data["productiondispatch_listdata"]           = $this->Production_model->production_dispatch_listdata($config["per_page"], $page);
    
   //echo $this->db->last_query();
    
	
	$data["links"]             = $this->pagination->create_links();
    ///$data['samplelists']          = $this->Sampling_model->sample_order_list();
	
	$data['clients'] = $this->Production_model->allclients(); 			
	$data['brands'] = $this->Production_model->allbrands();
	
	$data['production_dispatch_lists'] = $this->Production_model->production_dispatch_list(); 
	
	

	
	$data['production_lists'] = $this->Production_model->production_list(); 
	$data['production_dispatch_id']=$this->input->get('production_dispatch_id');
	$data['production_id']=$this->input->get('production_id');
	$data['client_id']=$this->input->get('client_id');	
	$data['brand_id']=$this->input->get('brand_id');
	
	
    $data['customer_name']     = '';
    $data['customer_id']       = '';
    $data['address']           ='';
    $data['module']            = "production";      
    $data['page']              = "create_production_dispatch_debit_datalist"; 
	
	
	
    echo Modules::run('template/layout', $data); 
    }
       
  
  
  
  
  function creatarray_production_dispatch_debit()
	{
		

		if(!empty($_POST['production_dispatch_info_id'])) 
		{
    
            
            $postData = [
            'production_dispatch_id'=>$this->input->post('production_dispatch_id'),
            'debit_no'=>$this->input->post('debit_no'),
            'debit_date'=>$this->input->post('dabit_date'),
            'create_date'=>date('Y-m-d H:i:s'),
            'create_by'=>$this->session->userdata('id')	
            ];
            
            $tmp_production_dispatch_debit_id=  $this->Production_model->create_production_dispatch_debit($postData);
                
            
            foreach($_POST['production_dispatch_info_id'] as $tmp_production_dispatch_info_id) 
            {
                //tov_production_dispatch_info
                //tov_production_dispatch
                
                $remaining_dispatch_qty=intval($this->input->post('d_qty_'.$tmp_production_dispatch_info_id))-intval($this->input->post('debit_qry_'.$tmp_production_dispatch_info_id));
                
                $postData2 = [
                   'production_dispatch_debit_id'=>$tmp_production_dispatch_debit_id,
                   'production_dispatch_info_id'=>$tmp_production_dispatch_info_id,
                   'dispatch_qty'=>$this->input->post('d_qty_'.$tmp_production_dispatch_info_id),
                   'remaining_dispatch_qty'=>$remaining_dispatch_qty,
                   'debit_qty'=>$this->input->post('debit_qry_'.$tmp_production_dispatch_info_id),
                   'create_date'=>date('Y-m-d H:i:s'),
                   'create_by'=>$this->session->userdata('id')	
        
				];
						
				//print_r($postData2);		
               // exit;
               $tmp_production_dispatch_id=  $this->Production_model->create_production_information_dispatch_debit( $postData2);
               
            }
        }
		
	
		
		//redirect('create_production_dispatch_debit');
		
		//$this->session->userdata('create_production_dispatch_debit');
		
		redirect('http://'.$this->session->userdata('create_production_dispatch_debit'));
	}	
		   
  
  public function production_approval_list() {
	
	//ini_set('display_startup_errors', 1);
//ini_set('display_errors', 1);


     $this->session->set_userdata('production_approval_list', $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
    $data['title']             = 'sample List'; 
    $config["base_url"]        = base_url('production_dispatch_list');
    $config["total_rows"]      = $this->Production_model->count_production_approval();
	$config["per_page"]        = 10;
    $config["uri_segment"]     = 2;
    $config["last_link"]       = "Last"; 
    $config["first_link"]      = "First"; 
    $config['next_link']       = 'Next';
    $config['prev_link']       = 'Prev';  
    $config['full_tag_open']   = "<ul class='pagination col-xs pull-right'>";
    $config['full_tag_close']  = "</ul>";
    $config['num_tag_open']    = '<li>';
    $config['num_tag_close']   = '</li>';
    $config['cur_tag_open']    = "<li class='disabled'><li class='active'><a href='#'>";
    $config['cur_tag_close']   = "<span class='sr-only'></span></a></li>";
    $config['next_tag_open']   = "<li>";
    $config['next_tag_close']  = "</li>";
    $config['prev_tag_open']   = "<li>";
    $config['prev_tagl_close'] = "</li>";
    $config['first_tag_open']  = "<li>";
    $config['first_tagl_close']= "</li>";
    $config['last_tag_open']   = "<li>";
    $config['last_tagl_close'] = "</li>";
	$this->pagination->initialize($config);
    $page                      = ($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
    $data["productiondispatch_listdata"]           = $this->Production_model->production_approval_datalist($config["per_page"], $page);
    
    //echo $this->db->last_query();
    
	
	$data["links"]             = $this->pagination->create_links();
    //$data['samplelists']          = $this->Sampling_model->sample_order_list();
	
	$data['clients'] = $this->Production_model->allclients(); 			
	$data['brands'] = $this->Production_model->allbrands();
	
	$data['production_lists'] = $this->Production_model->production_list(); 
	
	$data['production_id']=$this->input->get('po_no');
	$data['client_id']=$this->input->get('client_id');	
	$data['brand_id']=$this->input->get('brand_id');
	
	
    $data['customer_name']     = '';
    $data['customer_id']       = '';
    $data['address']           ='';
    $data['module']            = "production";      
    $data['page']              = "production_approvel_listdata"; 
	
	
	
    echo Modules::run('template/layout', $data); 
    }
    
    
    
    
     function production_approved_reject()
	 {
		
			//ini_set('display_startup_errors', 1);
            //ini_set('display_errors', 1);
		
		
		$approvel_reject=0;
		if($_REQUEST['approvel']==1)
		{
		    $approvel_reject=1;
		    
		}
		elseif($_REQUEST['reject']==1)
		{
		    $approvel_reject=0;
		}
		    if(!empty($_POST['production_information_id'])) 
		    {
    		    foreach($_POST['production_information_id'] as $tmp_production_information_id) 
                {
                    //tov_production_dispatch_info
                    //tov_production_dispatch
                    
                    ///$remaining_qty=intval($this->input->post('actual_qty_'.$tmp_production_information_id))-intval($this->input->post('qty_'.$tmp_production_information_id));
                    
                    $postactive = ['status'=>$approvel_reject];
                    
                    	$update =  $this->db->where('production_information_id', $tmp_production_information_id)
			                    ->update("tov_production_information", $postactive);
                }
		    }
		    
		    //redirect('production_dispatch_list');
		    
		    redirect('http://'.$this->session->userdata('production_approval_list'));
		    
	

	 }

   ////////////////////////////////////////////////////////////////////////////////

}

